/**
 * «Живые» показания датчика улья на карте.
 * Одна формула и для /api/map-points (интерфейс), и для контекста ИИ-агента —
 * чтобы агент называл те же числа, что видит пчеловод на экране.
 * Без датчика или при выключенном датчике показаний нет — «данных об улье нет».
 */
import type { SensorReading } from './api-types'

export interface SensorPointRow {
  id: string
  name: string
  lat: number
  lon: number
  hiveCount: number
  hasSensor: boolean
  sensorOn: boolean
  /** Код датчика на корпусе (в показания не входит, нужен интерфейсу). */
  sensorCode?: string | null
}

/** Детерминированная фаза по id точки — чтобы значения отличались между ульями. */
export function hashPhase(s: string): number {
  let h = 7
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0
  return ((h % 997) / 997) * Math.PI * 2
}

/**
 * Показания датчика: температура и шум колеблются заметно, масса растёт
 * медленно (взяток), влажность — в рабочем диапазоне улья.
 */
export function sensorReading(r: SensorPointRow, tSec: number): SensorReading {
  const updatedAt = new Date().toISOString()
  if (!r.hasSensor) {
    return { on: false, reason: 'none', tempC: null, humidityPct: null, weightKg: null, noiseDb: null, updatedAt }
  }
  if (!r.sensorOn) {
    return { on: false, reason: 'off', tempC: null, humidityPct: null, weightKg: null, noiseDb: null, updatedAt }
  }
  const p = hashPhase(r.id)
  const tempC = 34.6 + 0.7 * Math.sin(tSec / 150 + p) + 0.25 * Math.sin(tSec / 13 + p * 2)
  const humidityPct = 62 + 6 * Math.sin(tSec / 210 + p * 1.3) + 1.5 * Math.sin(tSec / 29 + p)
  const weightKg = 63.5 + 1.8 * Math.sin(tSec / 3600 + p) + 0.06 * Math.sin(tSec / 7 + p * 3)
  const noiseDb = 45 + 5 * Math.sin(tSec / 23 + p * 2.5) + 1.5 * Math.sin(tSec / 5 + p)
  return {
    on: true,
    reason: 'active',
    tempC: Math.round(tempC * 10) / 10,
    humidityPct: Math.round(humidityPct),
    weightKg: Math.round(weightKg * 10) / 10,
    noiseDb: Math.round(noiseDb),
    updatedAt,
  }
}
