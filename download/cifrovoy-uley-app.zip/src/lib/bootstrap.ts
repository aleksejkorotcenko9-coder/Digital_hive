/**
 * Первичное наполнение базы при первом запуске (идемпотентно):
 * API-ключ для приёма телеметрии. Пользователи регистрируются сами
 * с подтверждением email; ульи привязываются по кодам датчиков на карте.
 * Вызывается из API-маршрутов и из prisma/seed.ts.
 */
import { randomBytes } from 'node:crypto'
import { db } from './db'

let done = false

export async function ensureSeeded(): Promise<void> {
  if (done) return
  done = true
  try {
    // Старые аккаунты без email (до введения подтверждения почты) помечаем
    // подтверждёнными, чтобы их вход продолжал работать. Новые регистрации
    // с email не затрагиваются.
    await db.user.updateMany({
      where: { email: null, emailVerified: null },
      data: { emailVerified: new Date() },
    })

    // API-ключ для приёма телеметрии от датчиков
    await db.appSetting.upsert({
      where: { key: 'apiKey' },
      update: {},
      create: { key: 'apiKey', value: randomBytes(16).toString('hex') },
    })
  } catch (e) {
    done = false // позволяем повторить при следующем запросе
    throw e
  }
}
