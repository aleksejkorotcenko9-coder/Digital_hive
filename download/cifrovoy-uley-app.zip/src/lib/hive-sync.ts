/**
 * Синхронизация диаграмм с ульями на карте.
 *
 * Единый источник данных об ульях — точки на карте пасеки (ApiaryPoint),
 * привязанные по кодам датчиков. Всё, что видит пчеловод, строится из одного
 * набора точек: карта, вкладка «Датчики», диаграммы дашборда и контекст
 * ИИ-агента. Суточные ряды для диаграмм вычисляются той же формулой, что и
 * живые показания датчика (lib/sensor-sim.ts), поэтому «сегодня» на каждом
 * графике совпадает с числом в балунах меток и на вкладке «Датчики».
 */
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import type { DayPoint, Hive } from './hive-model'
import { hashPhase } from './sensor-sim'

/** Минимальный набор полей точки, которого достаточно для синхронизации. */
export interface SyncPointRow {
  id: string
  name: string
  hasSensor: boolean
  sensorOn: boolean
  /** Код на корпусе датчика — попадает в пояснения к улью. */
  sensorCode?: string | null
}

/** Дней телеметрии на диаграммах — 30 суток, как у суточных рядов. */
const SERIES_DAYS = 30

/** «1 улей / 2 улья / 5 ульев». */
export function hiveWord(n: number): string {
  const m10 = n % 10
  const m100 = n % 100
  if (m10 === 1 && m100 !== 11) return 'улей'
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return 'улья'
  return 'ульев'
}

/**
 * Суточный ряд показаний датчика за последние 30 дней.
 *
 * Температура и влажность считаются той же формулой, что в sensorReading,
 * поэтому последняя точка графика — ровно то значение, которое датчик
 * показывает прямо сейчас. Масса якорится к живому весу и растёт в прошлое
 * на суточный привес (0,3–0,75 кг, свой у каждой семьи по фазе датчика) —
 * кривая набора веса плавная, без ложных «падений».
 * Нет датчика или он выключен — ряд пустой: диаграммы честно без данных.
 */
export function sensorDailySeries(row: SyncPointRow, nowMs: number = Date.now()): DayPoint[] {
  if (!row.hasSensor || !row.sensorOn) return []
  const p = hashPhase(row.id)
  const nowSec = Math.floor(nowMs / 1000)
  // живой вес «сейчас» — та же формула, что в sensorReading
  const liveWeight = 63.5 + 1.8 * Math.sin(nowSec / 3600 + p) + 0.06 * Math.sin(nowSec / 7 + p * 3)
  // суточный привес семьи: 0,30–0,75 кг/день, свой у каждого улья
  const gain = 0.3 + 0.45 * (p / (Math.PI * 2))
  const out: DayPoint[] = []
  for (let k = SERIES_DAYS - 1; k >= 0; k--) {
    const t = nowMs - k * 86400000
    const tSec = Math.floor(t / 1000)
    const d = new Date(t)
    const tempC = 34.6 + 0.7 * Math.sin(tSec / 150 + p) + 0.25 * Math.sin(tSec / 13 + p * 2)
    const humidityPct = 62 + 6 * Math.sin(tSec / 210 + p * 1.3) + 1.5 * Math.sin(tSec / 29 + p)
    const weightKg = liveWeight - gain * k + 0.15 * Math.sin(k * 1.7 + p)
    out.push({
      date: format(d, 'yyyy-MM-dd'),
      label: format(d, 'd.MM'),
      full: format(d, 'd MMMM', { locale: ru }),
      weightKg: Math.round(weightKg * 10) / 10,
      tempInC: Math.round(tempC * 10) / 10,
      humidityPct: Math.round(humidityPct),
    })
  }
  return out
}

/** Точка на карте → улей для диаграмм, статусов и контекста агента. */
export function pointToHive(row: SyncPointRow, index: number, nowMs: number = Date.now()): Hive {
  const active = row.hasSensor && row.sensorOn
  return {
    id: index + 1,
    label: row.name,
    familyNote: active
      ? `Датчик ${row.sensorCode ?? '—'} активен — показания обновляются каждые несколько секунд`
      : row.hasSensor
        ? 'Датчик установлен, но выключен — телеметрия приостановлена'
        : 'Датчик не установлен — телеметрии нет',
    humiditySensorOk: active,
    humidityOfflineFrom: null,
    series: sensorDailySeries(row, nowMs),
  }
}

/** Все точки карты → список ульев (единый источник для дашборда и агента). */
export function pointsToHives(rows: SyncPointRow[], nowMs: number = Date.now()): Hive[] {
  return rows.map((row, i) => pointToHive(row, i, nowMs))
}

/**
 * Центр пасеки по её точкам (среднее координат) — для погоды и стартового
 * центра карты. Пустой список → null, вызывающий код подставит запасной центр.
 */
export function pointsCenter(rows: Array<{ lat: number; lon: number }>): [number, number] | null {
  if (rows.length === 0) return null
  const lat = rows.reduce((s, r) => s + r.lat, 0) / rows.length
  const lon = rows.reduce((s, r) => s + r.lon, 0) / rows.length
  return [Math.round(lat * 10000) / 10000, Math.round(lon * 10000) / 10000]
}
