/**
 * Логика ИИ-агента «Цифровой улей» (правиловая версия).
 *
 * Принципы из кейса:
 *  1. Data Driven — совет опирается на показатели, агент показывает, какие данные использовал.
 *  2. Честность — если данных не хватает, агент прямо об этом говорит.
 *  3. Вероятность и уровень риска, а не 100% прогноз; решение принимает пчеловод.
 *
 * Агент работает через AgentContext: один и тот же набор правил применяется
 * к данным пасеки — с датчиков на карте (точки ApiaryPoint) или из загруженной
 * телеметрии (/api/data). Контекст собирают callers: экран агента и /api/agent.
 */
import {
  fmtNum,
  fmtSigned,
  hiveStatus,
  weightDeltaOver,
  type Hive,
  type MigrationSite,
  type PesticideAlert,
  type WeatherDay,
} from './hive-model'
import type { SensorReading } from './api-types'
import type { AgentWeatherNow } from './weather-days'

/* ------------------------------------------------------------------ */
/* Типы                                                                */
/* ------------------------------------------------------------------ */

export type Urgency = 'act-now' | 'today' | 'this-week' | 'ok'
export type Scenario = 'pesticide' | 'swarm' | 'weather' | 'migration' | 'status' | 'care' | 'offtopic'

export const URGENCY_META: Record<Urgency, { label: string; cls: string }> = {
  'act-now': { label: 'Действовать сейчас', cls: 'bg-red-100 text-red-700 border-red-200' },
  today: { label: 'Сегодня', cls: 'bg-orange-100 text-orange-700 border-orange-200' },
  'this-week': { label: 'В течение недели', cls: 'bg-amber-50 text-amber-700 border-amber-200' },
  ok: { label: 'Наблюдать', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
}

export const SCENARIO_META: Record<Scenario, { label: string }> = {
  pesticide: { label: 'Пестициды' },
  swarm: { label: 'Роение' },
  weather: { label: 'Погода и медосбор' },
  migration: { label: 'Кочёвка' },
  status: { label: 'Состояние улья' },
  care: { label: 'Здоровье и уход' },
  offtopic: { label: 'Не по теме' },
}

export interface AgentMetric {
  label: string
  value: string
}

export interface AgentMessage {
  scenario: Scenario
  text: string
  basis: string[]
  urgency: Urgency
  urgencyNote?: string
  probability?: string
  metrics: AgentMetric[]
  hiveId: number | null
  /** Кто ответил: LLM или встроенный правиловый движок (fallback). Модель не раскрывается. */
  engine?: 'llm' | 'rules'
}

export interface AgentFinding extends AgentMessage {
  id: string
  title: string
  prefill: string
}

/** Точка пасеки на карте (ульи с датчиком) — тот же DTO, что отдаёт /api/map-points. */
export interface AgentPoint {
  id: string
  name: string
  lat: number
  lon: number
  hiveCount: number
  hasSensor: boolean
  sensorOn: boolean
  sensor: SensorReading
}

/** Контекст данных, по которым агент отвечает: телеметрия и точки карты. */
export interface AgentContext {
  hives: Hive[]
  weather: WeatherDay[] | null
  /** Погода «прямо сейчас» (метеосервис); если недоступна — null. */
  weatherNow?: AgentWeatherNow | null
  pesticide: PesticideAlert | null
  sites: MigrationSite[]
  /** Точки пасеки на карте с датчиками (температура, вес, влажность, шум). */
  points?: AgentPoint[]
  apiaryName: string
}

/** Собирает контекст агента: недостающее — честные null/пустые списки. */
export function makeContext(hives_: Hive[], opts?: Partial<Omit<AgentContext, 'hives'>>): AgentContext {
  return {
    hives: hives_,
    weather: opts?.weather ?? null,
    weatherNow: opts?.weatherNow ?? null,
    pesticide: opts?.pesticide ?? null,
    sites: opts?.sites ?? [],
    points: opts?.points,
    apiaryName: opts?.apiaryName ?? 'Моя пасека',
  }
}

/* ------------------------------------------------------------------ */
/* Метрики по рядам (безопасны к пропускам значений)                   */
/* ------------------------------------------------------------------ */

function lastPoint(h: Hive) {
  return h.series[h.series.length - 1] ?? null
}

function lastWeight(h: Hive): number | null {
  return lastPoint(h)?.weightKg ?? null
}

/** Изменение веса за `backDays` календарных дней; null, если точек не хватает.
 *  Календарный поиск с допуском ±1,5 дня — корректен при пропусках дней. */
function weightDelta(h: Hive, backDays: number): number | null {
  const s = h.series
  if (s.length === 0) return null
  const lastPoint = s[s.length - 1]
  if (lastPoint.weightKg === null) return null
  const target = new Date(lastPoint.date).getTime() - backDays * 86400000
  let best: number | null = null
  let bestDiff = Infinity
  for (const p of s) {
    if (p.weightKg === null || p === lastPoint) continue
    const diff = Math.abs(new Date(p.date).getTime() - target)
    if (diff <= 1.5 * 86400000 && diff < bestDiff) {
      bestDiff = diff
      best = p.weightKg
    }
  }
  if (best === null) return null
  return Math.round((lastPoint.weightKg - best) * 10) / 10
}

const delta2d = (h: Hive) => weightDelta(h, 2)
const delta30d = (h: Hive) => weightDelta(h, Math.min(29, Math.max(1, spanDays(h) - 1)))

function maxTempRecent(h: Hive, n = 3): number | null {
  const temps = h.series.slice(-n).map((p) => p.tempInC).filter((t): t is number => t !== null)
  return temps.length ? Math.max(...temps) : null
}

function lastHumidity(h: Hive): number | null {
  return lastPoint(h)?.humidityPct ?? null
}

/** Лидер пасеки по 30-дневному привесу. */
function leaderOf(list: Hive[]): Hive | null {
  const withW = list.filter((x) => delta30d(x) !== null)
  if (!withW.length) return null
  return [...withW].sort((a, b) => (delta30d(b) ?? 0) - (delta30d(a) ?? 0))[0]
}

/** Сколько дней охватывает ряд (для честных подписей «за N дн.»). */
function spanDays(h: Hive): number {
  if (h.series.length < 2) return h.series.length
  const a = new Date(h.series[0].date).getTime()
  const b = new Date(h.series[h.series.length - 1].date).getTime()
  if (Number.isNaN(a) || Number.isNaN(b)) return h.series.length
  return Math.round((b - a) / 86400000) + 1
}

function periodLabel(h: Hive): string {
  const d = spanDays(h)
  if (d >= 25) return 'за месяц'
  if (d === 1) return 'за день'
  if (d === 0) return '—'
  return `за ${d} дн.`
}

/** Порог срабатывания «падения веса» (признак возможного роения). */
const SWARM_DROP = -1.0

function swarmProbability(drop: number): string {
  const p = drop <= -3 ? 80 : drop <= -2 ? 70 : drop <= -1.5 ? 62 : 55
  return `Вероятность подготовки к роению — около ${p} %`
}

/* ------------------------------------------------------------------ */
/* Находки агента (карточки на дашборде)                               */
/* ------------------------------------------------------------------ */

function hiveFinding(h: Hive, ctx: AgentContext): AgentFinding {
  const status = hiveStatus(h, ctx.hives)
  const d2 = delta2d(h)
  const d30 = delta30d(h)
  const t = lastPoint(h)?.tempInC ?? null
  const hum = lastHumidity(h)

  if (h.series.length === 0 || (lastWeight(h) === null && t === null)) {
    return {
      id: `nodata-${h.id}`,
      scenario: 'status',
      hiveId: h.id,
      title: `Улей №${h.id}: пока нет данных`,
      text: `По улью №${h.id} в базе нет измерений. Я не буду гадать: как только появятся показания — загрузите их в разделе «Данные» (CSV, вручную или через API), и я сразу начну следить за весом, температурой и влажностью.`,
      basis: ['База данных платформы', 'Измерения улья №' + h.id],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Оценка невозможна — данных нет',
      metrics: [{ label: 'Измерений', value: String(h.series.length) }],
      prefill: `Что происходит с ульем №${h.id}?`,
    }
  }

  if (status.level === 'risk' && d2 !== null) {
    const peak = Math.max(...h.series.slice(-3).map((p) => p.weightKg ?? -Infinity))
    const now = lastWeight(h) ?? peak
    return {
      id: `swarm-${h.id}`,
      scenario: 'swarm',
      hiveId: h.id,
      title: 'Похоже, семья готовится к роению',
      text: `За последние 2 дня вес улья №${h.id} снизился на ${fmtNum(Math.abs(d2))} кг — с ${fmtNum(peak)} до ${fmtNum(now)} кг, хотя до этого семья стабильно набирала мед.${
        t !== null ? ` Температура внутри поднималась до ${fmtNum(t)} °C (норма около 34,5 °C).` : ''
      }${hum !== null ? ` Влажность держится на отметке ${fmtNum(hum, 0)} % — выше обычной для этого улья.` : ''} Июль — пик сезона роения: часть пчёл с маткой может улететь, и медосбор остановится на 2–3 недели.`,
      basis: [
        `График веса улья №${h.id}`,
        `Вес: ${fmtSigned(d2)} кг за 2 дня`,
        ...(t !== null ? [`Температура: ${fmtNum(t)} °C при норме 34,5 °C`] : []),
        'Сезон: июль — период роения',
      ],
      urgency: 'today',
      urgencyNote: 'Осмотреть улей сегодня до вечера',
      probability: swarmProbability(d2),
      metrics: [
        { label: 'Вес за 2 дня', value: `${fmtSigned(d2)} кг` },
        ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
        ...(hum !== null ? [{ label: 'Влажность', value: `${fmtNum(hum, 0)} %` }] : []),
      ],
      prefill: `Что происходит с ульем №${h.id}?`,
    }
  }

  if (status.level === 'watch' && h.label !== undefined) {
    const leader = leaderOf(ctx.hives)
    const reason = !h.humiditySensorOk && h.humidityOfflineFrom
      ? 'отдельно: датчик влажности не отвечает'
      : 'привес хуже, чем у лидера пасеки'
    return {
      id: `slow-${h.id}`,
      scenario: 'status',
      hiveId: h.id,
      title: 'Слабый набор веса',
      text: `Улей №${h.id} прибавил только ${fmtSigned(d30 ?? 0)} кг ${periodLabel(h)}${
        leader && leader.id !== h.id ? ` — у лидера (улей №${leader.id}) ${fmtSigned(delta30d(leader) ?? 0)} кг` : ''
      }. Температура${t !== null ? ` ${fmtNum(t)} °C` : ''} в норме. Причин может быть две: слабая семья или бедная кормовая база вокруг. ${reason.charAt(0).toUpperCase() + reason.slice(1)}${
        h.humidityOfflineFrom ? ` — молчит с ${h.humidityOfflineFrom}, возможно, сел аккумулятор` : ' — стоит сверить привес с соседними ульями'
      }.`,
      basis: [
        'Сравнение привеса по ульям пасеки',
        `Привес улья №${h.id}: ${fmtSigned(d30 ?? 0)} кг`,
        ...(h.humidityOfflineFrom ? [`Датчик влажности: нет данных с ${h.humidityOfflineFrom}`] : []),
      ],
      urgency: 'this-week',
      urgencyNote: 'Проверить датчик и семью в ближайшие дни',
      probability: 'Диагноз по косвенным признакам — нужна проверка',
      metrics: [
        { label: `Привес ${periodLabel(h)}`, value: `${fmtSigned(d30 ?? 0)} кг` },
        ...(leader && leader.id !== h.id
          ? [{ label: `У лидера (№${leader.id})`, value: `${fmtSigned(delta30d(leader) ?? 0)} кг` }]
          : []),
        ...(hum !== null ? [{ label: 'Влажность', value: `${fmtNum(hum, 0)} %` }] : [{ label: 'Влажность', value: 'нет данных' }]),
      ],
      prefill: `Почему в улье №${h.id} слабый привес?`,
    }
  }

  return {
    id: `ok-${h.id}`,
    scenario: 'status',
    hiveId: h.id,
    title: 'Семья работает штатно',
    text: `Улей №${h.id} развивается штатно: вес ${fmtNum(lastWeight(h) ?? 0)} кг, привес ${fmtSigned(d30 ?? 0)} кг ${periodLabel(h)}, за последние 2 дня ${fmtSigned(d2 ?? 0)} кг.${
      t !== null ? ` Температура ${fmtNum(t)} °C — в норме.` : ''
    } Признаков роения нет: вес растёт ровно, без провалов.`,
    basis: [
      `График веса улья №${h.id}`,
      `Привес: ${fmtSigned(d30 ?? 0)} кг`,
      'Температура в норме семьи',
    ],
    urgency: 'ok',
    urgencyNote: 'Продолжать наблюдение',
    metrics: [
      { label: `Привес ${periodLabel(h)}`, value: `${fmtSigned(d30 ?? 0)} кг` },
      ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
      ...(hum !== null ? [{ label: 'Влажность', value: `${fmtNum(hum, 0)} %` }] : []),
    ],
    prefill: `Что происходит с улье №${h.id}?`,
  }
}

function pesticideFindingOf(ctx: AgentContext): AgentFinding | null {
  const a = ctx.pesticide
  if (!a) return null
  return {
    id: 'pesticide',
    scenario: 'pesticide',
    hiveId: null,
    title: `Обработка поля в ${fmtNum(a.distanceKm)} км — риск для пчёл`,
    text: `${a.dateLabel} поле ${a.crop} ${a.field} (${fmtNum(a.distanceKm)} км от пасеки) обработают химикатом, ${a.windNote}. Радиус продуктивного лёта пчёл — 3–5 км, поле попадает в зону сбора. Летящая на обработанное поле семья может потерять большинство лётных пчёл.`,
    basis: [
      'Координаты пасеки и поля — ГИС',
      `${a.source.charAt(0).toUpperCase() + a.source.slice(1)}: обработка ${a.dateLabel}`,
      `Расстояние ${fmtNum(a.distanceKm)} км — внутри радиуса разлёта`,
      'Прогноз ветра на день обработки',
    ],
    urgency: 'act-now',
    urgencyNote: 'До вечера 19 июля закрыть летки или вывезти пасеку',
    probability: 'Риск для семей — высокий',
    metrics: [
      { label: 'Расстояние', value: `${fmtNum(a.distanceKm)} км` },
      { label: 'Дата обработки', value: a.dateLabel },
      { label: 'Радиус лёта пчёл', value: '3–5 км' },
    ],
    prefill: 'Чем опасна обработка поля рядом и что делать?',
  }
}

function weatherFindingOf(ctx: AgentContext): AgentFinding | null {
  const w = ctx.weather
  if (!w || w.length === 0) return null
  const good = w.filter((d) => d.flight === 'good')
  const bad = w.filter((d) => d.flight === 'bad')
  const tMax = Math.max(...w.map((d) => d.tMax))
  const rainProb = bad.length ? Math.max(...bad.map((d) => d.precipProb)) : 0
  return {
    id: 'weather',
    scenario: 'weather',
    hiveId: null,
    title: good.length
      ? `Окно лёта: ${good.map((d) => `${Number(d.date.slice(8))} ${monthGen(d.date)}`).join(', ').slice(0, 80)}`
      : 'Ближайшие дни — не для лёта',
    text: good.length
      ? `Ближайшие дни с хорошими условиями: ${good.map((d) => d.full).join(', ')} — до ${fmtSigned(tMax, 0)} °C, ветер до ${Math.max(...good.map((d) => d.windMs))} м/с, осадки маловероятны.${
          bad.length ? ` Затем, ${bad.map((d) => d.full).join(' и ')}, — дожди (до ${rainProb} %) и ветер до ${Math.max(...bad.map((d) => d.windMs))} м/с: пчёлы останутся в ульях, привес остановится.` : ''
        }`
      : `По прогнозу на неделю погода не летная: дожди и ветер. Пчёлы останутся в ульях, привес остановится — следите за запасами корма по графику веса.`,
    basis: ['Прогноз погоды платформы', 'Календарь цветения медоносов — ГИС'],
    urgency: 'ok',
    urgencyNote: good.length ? 'Использовать окно лёта' : 'Наблюдать за погодой',
    metrics: [
      { label: 'Максимум', value: `${fmtSigned(tMax, 0)} °C` },
      ...(bad.length ? [{ label: 'Дождь', value: `до ${rainProb} %` }] : []),
      ...(ctx.sites.length
        ? [{ label: 'Кандидатов кочёвки', value: String(ctx.sites.length) }]
        : []),
    ],
    prefill: 'Когда пчёлам лучше летать за взятком?',
  }
}

function monthGen(date: string): string {
  // «2026-07-20» → «июля» (родительный падеж)
  const months = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря']
  const m = Number(date.slice(5, 7))
  return months[m - 1] ?? ''
}

function migrationFindingOf(ctx: AgentContext): AgentFinding | null {
  const sites = [...ctx.sites].sort((a, b) => b.score - a.score)
  if (!sites.length) return null
  const best = sites[0]
  const worst = sites[sites.length - 1]
  return {
    id: 'migration',
    scenario: 'migration',
    hiveId: null,
    title: `Лучшее место для кочёвки — «${best.name}»`,
    text: `Сравнил ${sites.length} ${
      sites.length === 1 ? 'участок' : sites.length < 5 ? 'участка' : 'участков'
    } вокруг пасеки по 4 факторам: медоносы, погода, расстояние и риски. Лучший — «${best.name}»: ${best.honeyPlant.toLowerCase()} цветёт ${best.bloomWindow}, ${fmtNum(best.distanceKm)} км от пасеки, погода: ${best.weatherNote.toLowerCase()}.${
      best.risks ? ` Учтите: ${best.risks.toLowerCase()}.` : ''
    }${sites.length > 1 && worst.verdict === 'avoid' ? ` «${worst.name.replace(/^Донниковое поле \(/, '').replace(/\)$/, '')}» не советую: ${worst.risks.toLowerCase() || 'низкая оценка участка'}.` : ''}`,
    basis: ['ГИС: медоносы и расстояния', 'Прогноз погоды по участкам', 'Реестр обработок полей'],
    urgency: 'this-week',
    urgencyNote: 'Решить до начала цветения',
    metrics: [
      { label: 'Лучший участок', value: `${fmtNum(best.score)} / 10` },
      { label: 'Расстояние', value: `${fmtNum(best.distanceKm)} км` },
      { label: 'Цветение', value: best.bloomWindow },
    ],
    prefill: 'Куда перевезти пасеку?',
  }
}

/** Список находок: по выбранному улью + глобальные сценарии, отсортированы по срочности. */
export function findingsFor(hiveId: number, ctx: AgentContext): AgentFinding[] {
  const hive = ctx.hives.find((x) => x.id === hiveId) ?? ctx.hives[0]
  const list: AgentFinding[] = []
  if (hive) list.push(hiveFinding(hive, ctx))
  const pesticide = pesticideFindingOf(ctx)
  if (pesticide) list.push(pesticide)
  const weatherF = weatherFindingOf(ctx)
  if (weatherF) list.push(weatherF)
  const migrationF = migrationFindingOf(ctx)
  if (migrationF) list.push(migrationF)
  const rank: Record<Urgency, number> = { 'act-now': 0, today: 1, 'this-week': 2, ok: 3 }
  return list.sort((a, b) => rank[a.urgency] - rank[b.urgency])
}

/* ------------------------------------------------------------------ */
/* Ответы на вопросы пчеловода                                         */
/* ------------------------------------------------------------------ */

function norm(s: string): string {
  return s.toLowerCase().replace(/ё/g, 'е')
}

function extractHiveId(q: string, ctx: AgentContext): number | null {
  const m = q.match(/(?:№|улье|улья|улью|улье|hive)\s*№?\s*(\d+)/)
  if (!m) return null
  const id = Number(m[1])
  return ctx.hives.some((h) => h.id === id) ? id : null
}

function swarmAnswer(h: Hive, ctx: AgentContext): AgentMessage {
  const status = hiveStatus(h, ctx.hives)
  const d2 = delta2d(h)
  const t = lastPoint(h)?.tempInC ?? null
  const hum = lastHumidity(h)

  if (h.series.length === 0 || (lastWeight(h) === null && d2 === null)) {
    return {
      scenario: 'swarm',
      hiveId: h.id,
      text: `Честный ответ: по улью №${h.id} нет данных о весе — оценить риск роения я не могу. Загрузите показания в разделе «Данные» (CSV, ручной ввод или API), и я начну следить за привесом: именно резкое падение веса при тёплой погоде выдаёт подготовку к роению.\n\nПока могу напомнить признаки для ручного осмотра: маточники по краям рамок и «борода» из пчёл на летке.`,
      basis: ['База данных платформы', 'Измерения улья №' + h.id],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Оценка невозможна — данных нет',
      metrics: [{ label: 'Данные веса', value: 'нет' }],
    }
  }

  if (status.level === 'risk' && d2 !== null) {
    const peak = Math.max(...h.series.slice(-3).map((p) => p.weightKg ?? -Infinity))
    const now = lastWeight(h) ?? peak
    return {
      scenario: 'swarm',
      hiveId: h.id,
      text: `Да, риск высокий. За последние 2 дня вес улья №${h.id} упал на ${fmtNum(Math.abs(d2))} кг (с ${fmtNum(peak)} до ${fmtNum(now)} кг) при том, что до этого шёл устойчивый привес.${
        t !== null ? ` Внутри стало теплее нормы: ${fmtNum(t)} °C вместо обычных 34,5 °C.` : ''
      }${hum !== null ? ` Влажность выросла до ${fmtNum(hum, 0)} %.` : ''} Июль — пик сезона роения. Похоже, семья готовится делиться.\n\nОсмотрите улей сегодня: признаки роения — маточники по краям рамок и «борода» из пчёл на летке. Если подтверждается, отройте рой вечером или расширьте гнездо вощиной.`,
      basis: [
        `График веса улья №${h.id}`,
        `Вес: ${fmtSigned(d2)} кг за 2 дня`,
        ...(t !== null ? [`Температура: ${fmtNum(t)} °C (норма 34,5 °C)`] : []),
        'Сезон: июль — период роения',
      ],
      urgency: 'today',
      urgencyNote: 'Осмотреть улей сегодня',
      probability: swarmProbability(d2),
      metrics: [
        { label: 'Вес за 2 дня', value: `${fmtSigned(d2)} кг` },
        ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
        ...(hum !== null ? [{ label: 'Влажность', value: `${fmtNum(hum, 0)} %` }] : []),
      ],
    }
  }

  return {
    scenario: 'swarm',
    hiveId: h.id,
    text: `Выраженных признаков роения в улье №${h.id} не вижу: вес растёт ровно (за 2 дня ${fmtSigned(d2 ?? 0)} кг), температура${t !== null ? ` ${fmtNum(t)} °C` : ''} — в норме. Провалов веса, как это бывает перед роением, на графике нет.\n\nЧто делаю: продолжаю сравнивать вес и температуру за каждый день. Если появится резкий привес с последующим падением — сразу предупрежу.`,
    basis: [
      `График веса улья №${h.id}`,
      'Сравнение с признаками роения',
      'Температура в норме семьи',
    ],
    urgency: 'ok',
    urgencyNote: 'Наблюдать, сигнал придёт при изменениях',
    probability: 'Признаков роения сейчас нет',
    metrics: [
      { label: 'Вес за 2 дня', value: `${fmtSigned(d2 ?? 0)} кг` },
      ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
      { label: 'Влажность', value: hum !== null ? `${fmtNum(hum, 0)} %` : 'нет данных' },
    ],
  }
}

function statusAnswer(h: Hive, ctx: AgentContext): AgentMessage {
  const status = hiveStatus(h, ctx.hives)
  const d2 = delta2d(h)
  const d30 = delta30d(h)
  const t = lastPoint(h)?.tempInC ?? null
  const hum = lastHumidity(h)
  const w = lastWeight(h)

  if (h.series.length === 0) {
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `По улью №${h.id} данных в базе пока нет — честно говорю: состояние семьи я оценить не могу. Загрузите телеметрию в разделе «Данные» или внесите показание вручную. Как только появятся измерения, я начну сравнивать привес с другими ульями и следить за климатом.`,
      basis: ['База данных платформы'],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Измерений', value: '0' }],
    }
  }

  if (status.level === 'risk' && d2 !== null) {
    const peak = Math.max(...h.series.slice(-3).map((p) => p.weightKg ?? -Infinity))
    return {
      scenario: 'swarm',
      hiveId: h.id,
      text: `С улеем №${h.id} не всё спокойно. Два дня назад вес достиг пика ${fmtNum(peak)} кг, а сейчас — ${fmtNum(w ?? 0)} кг: падение на ${fmtNum(Math.abs(d2))} кг при том, что остальные ульи продолжают набирать мед.${
        t !== null ? ` Температура внутри выше нормы (${fmtNum(t)} °C).` : ''
      } Сезон — июль, время роения.\n\nРекомендую осмотреть улей сегодня: проверить маточники и «бороду» пчёл на летке. Это вероятностная оценка, окончательное решение за вами.`,
      basis: [
        `График веса улья №${h.id}`,
        `Вес: ${fmtSigned(d2)} кг за 2 дня`,
        ...(t !== null ? ['Температура выше нормы семьи'] : []),
        'Сезон: июль — период роения',
      ],
      urgency: 'today',
      urgencyNote: 'Осмотреть сегодня',
      probability: swarmProbability(d2),
      metrics: [
        { label: 'Вес сейчас', value: `${fmtNum(w ?? 0)} кг` },
        { label: 'Вес за 2 дня', value: `${fmtSigned(d2)} кг` },
        ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
      ],
    }
  }

  if (status.level === 'watch') {
    const leader = leaderOf(ctx.hives)
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `Улей №${h.id} жив, но развивается медленно: привес ${fmtSigned(d30 ?? 0)} кг ${periodLabel(h)}${
        leader && leader.id !== h.id ? ` — хуже, чем у лидера (улей №${leader.id}: ${fmtSigned(delta30d(leader) ?? 0)} кг)` : ''
      }. Температура${t !== null ? ` ${fmtNum(t)} °C` : ''} в норме, резких провалов нет. Похоже на слабую семью или бедную кормовую базу вокруг.\n\n${
        !h.humiditySensorOk && h.humidityOfflineFrom
          ? `Важно и честно: датчик влажности в этом улье не отвечает с ${h.humidityOfflineFrom} — возможно, сел аккумулятор. Проверьте датчик и загляните в улей в ближайшие дни.`
          : 'Загляните в улей в ближайшие дни и сверьте привес с соседними семьями.'
      }`,
      basis: [
        'Сравнение привеса по ульям пасеки',
        ...(h.humidityOfflineFrom ? [`Датчик влажности: нет данных с ${h.humidityOfflineFrom}`] : []),
        'Температура в норме',
      ],
      urgency: 'this-week',
      urgencyNote: 'Проверить семью в ближайшие дни',
      probability: 'Оценка по косвенным признакам',
      metrics: [
        { label: `Привес ${periodLabel(h)}`, value: `${fmtSigned(d30 ?? 0)} кг` },
        ...(leader && leader.id !== h.id
          ? [{ label: `У лидера (№${leader.id})`, value: `${fmtSigned(delta30d(leader) ?? 0)} кг` }]
          : []),
        { label: 'Влажность', value: hum !== null ? `${fmtNum(hum, 0)} %` : 'нет данных' },
      ],
    }
  }

  return {
    scenario: 'status',
    hiveId: h.id,
    text: `С улеем №${h.id} всё в порядке: вес ${fmtNum(w ?? 0)} кг, привес ${fmtSigned(d30 ?? 0)} кг ${periodLabel(h)}, за последние 2 дня ${fmtSigned(d2 ?? 0)} кг. Температура${t !== null ? ` ${fmtNum(t)} °C` : ''} и влажность${hum !== null ? ` ${fmtNum(hum, 0)} %` : ''} в норме. Семья активно работает на медосборе.`,
    basis: [
      `График веса улья №${h.id}`,
      `Привес: ${fmtSigned(d30 ?? 0)} кг`,
      'Температура и влажность в норме',
    ],
    urgency: 'ok',
    urgencyNote: 'Продолжать наблюдение',
    metrics: [
      { label: 'Вес сейчас', value: `${fmtNum(w ?? 0)} кг` },
      { label: 'Привес месяц', value: `${fmtSigned(d30 ?? 0)} кг` },
      ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
    ],
  }
}

function weightAnswer(h: Hive, ctx: AgentContext): AgentMessage {
  const d2 = delta2d(h)
  const d30 = delta30d(h)
  const w = lastWeight(h)
  const risky = d2 !== null && d2 <= SWARM_DROP

  if (h.series.length === 0 || w === null) {
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `По весу улья №${h.id} данных пока нет — не буду называть цифр. Внесите показание вручную в разделе «Данные» или загрузите CSV: после этого я покажу вес, привес за 2 дня и за месяц и сравню с остальными ульями.`,
      basis: ['База данных платформы'],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Вес', value: 'нет данных' }],
    }
  }

  const others = ctx.hives
    .map((x) => ({ x, d: delta30d(x) }))
    .filter((o): o is { x: Hive; d: number } => o.d !== null)
    .map((o) => `№${o.x.id} — ${fmtSigned(o.d)} кг`)
    .join(', ')

  return {
    scenario: 'status',
    hiveId: h.id,
    text: `Вес улья №${h.id} сейчас ${fmtNum(w)} кг. За последние 2 дня ${fmtSigned(d2 ?? 0)} кг, ${periodLabel(h)} ${fmtSigned(d30 ?? 0)} кг.${risky ? ` Настораживает само падение веса при тёплой погоде.` : ''}\n\nДля сравнения по пасеке: ${others || 'весов с данными больше нет'}. Набор веса — главный признак медосбора: резкое падение при растущей температуре часто означает начало роения.`,
    basis: [
      `График веса улья №${h.id}`,
      'Привес всех ульёв пасеки',
      'Правило: привес = интенсивность медосбора',
    ],
    urgency: risky ? 'today' : 'ok',
    urgencyNote: risky ? 'Проверить улей сегодня' : 'Наблюдать',
    probability: risky ? 'Совпадает с признаками роения' : undefined,
    metrics: [
      { label: 'Вес сейчас', value: `${fmtNum(w)} кг` },
      { label: 'За 2 дня', value: `${fmtSigned(d2 ?? 0)} кг` },
      { label: periodLabel(h).charAt(0).toUpperCase() + periodLabel(h).slice(1), value: `${fmtSigned(d30 ?? 0)} кг` },
    ],
  }
}

function humidityAnswer(h: Hive): AgentMessage {
  const hum = lastHumidity(h)
  const offline = !h.humiditySensorOk && h.humidityOfflineFrom

  if (h.series.length === 0) {
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `По улью №${h.id} измерений в базе нет — про влажность ответить честно не могу: данных ноль. Загрузите показания датчика влажности в разделе «Данные», и я оценю, комфортно ли семье (норма для летнего улья — 50–66 %).`,
      basis: ['База данных платформы'],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Влажность', value: 'нет данных' }],
    }
  }

  if (offline || hum === null) {
    const t = lastPoint(h)?.tempInC
    const d30 = delta30d(h)
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `Честный ответ: данных по влажности улья №${h.id} нет — датчик передаёт прочерки${h.humidityOfflineFrom ? ` с ${h.humidityOfflineFrom}` : ''}. Вероятно, сбой питания или разряд аккумулятора. Гадать не буду: совета по влажности дать не могу.\n\nЧто видно по остальным датчикам: привес ${fmtSigned(delta30d(h) ?? 0)} кг ${periodLabel(h)}, температура${t !== null ? ` ${fmtNum(t)} °C` : ''}. Рекомендую проверить датчик, а заодно осмотреть семью.`,
      basis: [
        `Датчик влажности улья №${h.id}: нет данных${h.humidityOfflineFrom ? ` с ${h.humidityOfflineFrom}` : ''}`,
        `Привес: ${fmtSigned(d30 ?? 0)} кг ${periodLabel(h)}`,
      ],
      urgency: 'this-week',
      urgencyNote: 'Проверить датчик',
      probability: 'Данных недостаточно — это честный ответ',
      metrics: [
        { label: 'Влажность', value: 'нет данных' },
        { label: 'Привес месяц', value: `${fmtSigned(d30 ?? 0)} кг` },
        ...(t !== null ? [{ label: 'Темп. внутри', value: `${fmtNum(t)} °C` }] : []),
      ],
    }
  }

  const verdict =
    hum > 70
      ? 'выше комфортной зоны — в улье сыро, стоит улучшить вентиляцию'
      : hum > 64
        ? 'ближе к верхней границе нормы — понаблюдайте при следующем осмотре'
        : 'в комфортной зоне для семьи и созревания мёда'
  return {
    scenario: 'status',
    hiveId: h.id,
    text: `Влажность в улье №${h.id} — ${fmtNum(hum, 0)} %, ${verdict}. Норма для летнего улья — 50–66 %. Показатель считывается датчиком дважды в сутки.`,
    basis: [`Датчик влажности улья №${h.id}`, 'Норма: 50–66 %'],
    urgency: hum > 70 ? 'today' : 'ok',
    urgencyNote: hum > 70 ? 'Улучшить вентиляцию' : 'Наблюдать',
    metrics: [
      { label: 'Влажность', value: `${fmtNum(hum, 0)} %` },
      { label: 'Норма', value: '50–66 %' },
    ],
  }
}

function climateAnswer(h: Hive): AgentMessage {
  const t = lastPoint(h)?.tempInC ?? null
  const risky = hiveStatus(h, hiveStatusArgFallback(h)).level === 'risk'

  if (t === null) {
    return {
      scenario: 'status',
      hiveId: h.id,
      text: `Данных о температуре в улье №${h.id} пока нет — честно: ответить не могу. Добавьте показания датчика температуры в разделе «Данные». Норма для семьи с расплодом — около 34,5 °C: как только появятся измерения, я сравню ваши цифры с нормой.`,
      basis: ['База данных платформы'],
      urgency: 'this-week',
      urgencyNote: 'Загрузить данные',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Темп. внутри', value: 'нет данных' }],
    }
  }

  return {
    scenario: risky ? 'swarm' : 'status',
    hiveId: h.id,
    text: risky
      ? `Температура в улье №${h.id} — ${fmtNum(t)} °C, это на ${fmtNum(t - 34.5)} °C выше нормы семьи (34,5 °C). Само по себе потепление в жару нормально, но вместе с падением веса это похоже на подготовку к роению: пчёлы поднимают температуру, когда готовятся делиться.`
      : `Температура в улье №${h.id} — ${fmtNum(t)} °C, в норме для семьи с расплодом (около 34,5 °C). Датчик пишет значение дважды в сутки, резких скачков за неделю не было.`,
    basis: [
      `Датчик температуры улья №${h.id}`,
      'Норма семьи: около 34,5 °C',
      ...(risky ? ['Совместный анализ: температура + падение веса'] : []),
    ],
    urgency: risky ? 'today' : 'ok',
    urgencyNote: risky ? 'Осмотреть сегодня' : 'Наблюдать',
    probability: risky ? 'Совместный анализ температуры и веса' : undefined,
    metrics: [
      { label: 'Темп. сейчас', value: `${fmtNum(t)} °C` },
      { label: 'Норма', value: '34,5 °C' },
    ],
  }
}

/** Для climateAnswer статус проверяется по одному улью без сравнения с пасекой. */
function hiveStatusArgFallback(h: Hive): Hive[] {
  return [h]
}

function pesticideAnswer(ctx: AgentContext): AgentMessage {
  const a = ctx.pesticide
  if (!a) {
    return {
      scenario: 'pesticide',
      hiveId: null,
      text: `Честный ответ: реестр обработок полей к этой пасеке не подключён, и я не вижу запланированных обработок вокруг. Если вы сами узнали об обработке рядом, напишите дату и расстояние — подскажу протокол защиты семей.\n\nОбщие правила на такой случай: вечером накануне закрыть летки или вывезти пасеку за 7+ км от поля, уточнить препарат у агронома и ждать 24–48 часов, пока он высохнет.`,
      basis: ['Реестр обработок: не подключён'],
      urgency: 'ok',
      urgencyNote: 'Источник данных не подключён',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Реестр обработок', value: 'нет данных' }],
    }
  }
  return {
    scenario: 'pesticide',
    hiveId: null,
    text: `${a.dateLabel} поле ${a.crop} ${a.field} обработают химикатом. Поле в ${fmtNum(a.distanceKm)} км от пасеки — внутри радиуса продуктивного лёта (3–5 км), а ${a.windNote}. Пчёлы могут принести отравленный нектар и погибнуть — под угрозой все семьи.\n\nЧто делать: вечером накануне закрыть летки, если увозить пасеку не вариант, либо вывезти улья за 7+ км от поля. Уточните точное время обработки у агронома хозяйства и дождитесь, пока препарат высохнет, — обычно это 24–48 часов.`,
    basis: [
      'Координаты пасеки и поля — ГИС',
      `${a.source.charAt(0).toUpperCase() + a.source.slice(1)}: обработка ${a.dateLabel}`,
      'Радиус продуктивного лёта пчёл: 3–5 км',
      'Прогноз ветра на день обработки',
    ],
    urgency: 'act-now',
    urgencyNote: `Действовать до ${a.dateShort}`,
    probability: 'Риск для семей — высокий',
    metrics: [
      { label: 'Поле', value: `${a.crop}, ${fmtNum(a.distanceKm)} км` },
      { label: 'Обработка', value: a.dateLabel },
      { label: 'Ветер', value: 'в сторону пасеки' },
    ],
  }
}

function weatherAnswer(ctx: AgentContext): AgentMessage {
  const w = ctx.weather
  if (!w || w.length === 0) {
    return {
      scenario: 'weather',
      hiveId: null,
      text: `Честный ответ: прогноз погоды к пасеке не подключён, поэтому окна лёта я показать не могу. Могу подсказать правило: активный лёт — при +18…+28 °C и ветре до 5–6 м/с, без дождя; в дождь пчёлы сидят в ульях и привес стоит.\n\nОриентируйтесь на график веса: дни с хорошим привесом — и есть «погода для взятка». Если подключите источник погоды — сразу добавлю прогноз в советы.`,
      basis: ['Прогноз погоды: не подключён', 'График веса как косвенный признак'],
      urgency: 'ok',
      urgencyNote: 'Источник данных не подключён',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Прогноз', value: 'нет данных' }],
    }
  }
  const good = w.filter((d) => d.flight === 'good')
  const bad = w.filter((d) => d.flight === 'bad')
  const days = (arr: WeatherDay[]) => arr.map((d) => d.full).join(', ')
  return {
    scenario: 'weather',
    hiveId: null,
    text: good.length
      ? `Лучшие дни для лёта — ${days(good)}: до ${fmtSigned(Math.max(...good.map((d) => d.tMax)), 0)} °C, ветер до ${Math.max(...good.map((d) => d.windMs))} м/с, осадки маловероятны. ${
          bad.length ? `${days(bad)} — дожди (до ${Math.max(...bad.map((d) => d.precipProb))} %) и ветер до ${Math.max(...bad.map((d) => d.windMs))} м/с: лёта почти не будет, привес остановится.` : ''
        }\n\nВ дождевые дни проверьте вентиляцию и не открывайте ульи без нужды. По плечу ли семьям запасы — подскажет привес на графике.`
      : `По прогнозу на неделю погода не летная: дожди и ветер. Пчёлы останутся в ульях, привес остановится — проследите, чтобы у семей был запас корма.`,
    basis: [
      'Прогноз погоды платформы',
      'Календарь цветения медоносов — ГИС',
      'Правило: привес = интенсивность лёта',
    ],
    urgency: 'ok',
    urgencyNote: good.length ? 'Использовать окно лёта' : 'Наблюдать',
    metrics: [
      ...(good.length ? [{ label: 'Окно лёта', value: good[0].full }] : []),
      ...(bad.length ? [{ label: 'Дождь', value: `до ${Math.max(...bad.map((d) => d.precipProb))} %` }] : []),
    ],
  }
}

function migrationAnswer(ctx: AgentContext): AgentMessage {
  const sites = [...ctx.sites].sort((a, b) => b.score - a.score)
  if (!sites.length) {
    return {
      scenario: 'migration',
      hiveId: null,
      text: `Честно: в справочнике пасеки пока нет участков для кочёвки, сравнивать нечего. Добавьте места в разделе «Данные» — медонос, сроки цветения, расстояние и риски. После этого я сравню их по 4 факторам и порекомендую лучший.\n\nКак оцениваю участки: медоносы и сроки цветения (ГИС), погода на дни кочёвки, расстояние и качество дороги, отсутствие обработок полей рядом.`,
      basis: ['Справочник площадок: пуст'],
      urgency: 'this-week',
      urgencyNote: 'Добавить участки в справочник',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Площадок', value: '0' }],
    }
  }
  const best = sites[0]
  const worst = sites[sites.length - 1]
  return {
    scenario: 'migration',
    hiveId: null,
    text: `Сравнил ${sites.length} ${
      sites.length === 1 ? 'участок' : sites.length < 5 ? 'участка' : 'участков'
    } вокруг пасеки по 4 факторам: медоносы, погода, расстояние, риски.\n\nЛучший выбор — «${best.name}»: ${best.honeyPlant.toLowerCase()} цветёт ${best.bloomWindow}, ${fmtNum(best.distanceKm)} км от пасеки, погода: ${best.weatherNote.toLowerCase()}.${
      best.risks ? ` Учтите риск: ${best.risks.toLowerCase()}.` : ''
    }${sites.length > 1 ? `\n\n${sites.slice(1).map((s) => `«${s.name}» — ${fmtNum(s.score)} / 10${s.verdict === 'avoid' ? ', не советую' : ''}`).join('; ')}.` : ''}${
      worst.verdict === 'avoid' && worst.risks ? ` «${worst.name.replace(/^Донниковое поле \(/, '').replace(/\)$/, '')}»: ${worst.risks.toLowerCase()}.` : ''
    }\n\nПеревозку лучше планировать на вечер — семьи спокойнее переносят дорогу.`,
    basis: [
      'ГИС: медоносы и расстояния',
      'Прогноз погоды по участкам',
      'Реестр обработок полей',
    ],
    urgency: 'this-week',
    urgencyNote: 'Решить до начала цветения',
    metrics: [
      { label: 'Лучший участок', value: `«${best.name}»` },
      { label: 'Оценка', value: `${fmtNum(best.score)} / 10` },
      { label: 'Цветение', value: best.bloomWindow },
    ],
  }
}

function greetingAnswer(ctx: AgentContext): AgentMessage {
  const withData = ctx.hives.filter((h) => h.series.length > 0).length
  if (ctx.hives.length === 0 || withData === 0) {
    return {
      scenario: 'status',
      hiveId: null,
      text: `Здравствуйте! Я цифровой помощник пасеки${ctx.apiaryName ? ` «${ctx.apiaryName}»` : ''}. В базе пока нет телеметрии — честно об этом говорю. Загрузите показания в разделе «Данные»: файлом CSV, вручную через форму или автоматически через API-эндпоинт. После этого я начну следить за весом, температурой и влажностью каждого улья, предупреждать о риске роения и плохой погоде.\n\nПринципы у меня такие: показываю, на какие данные опираюсь; если данных не хватает — говорю прямо; даю вероятность и уровень риска, а решение принимает пчеловод.`,
      basis: ['База данных платформы'],
      urgency: 'ok',
      urgencyNote: 'Жду данные',
      metrics: [{ label: 'Ульев с данными', value: `0 из ${ctx.hives.length || 0}` }],
    }
  }
  return {
    scenario: 'status',
    hiveId: null,
    text: `Здравствуйте! Я цифровой помощник пасеки${ctx.apiaryName ? ` «${ctx.apiaryName}»` : ''}. Слежу сразу за ${ctx.hives.length} ${
      ctx.hives.length === 1 ? 'ульем' : 'ульями'
    } — весом, температурой и влажностью, — проверяю датчики на карте и сверяюсь с${ctx.weather ? ' прогнозом погоды,' : ''}${ctx.pesticide ? ' предупреждениями об обработках,' : ''} картой полей и справочником кочёвки. Отвечаю только о погоде и ульях. Спрашивайте обычными словами, например:\n\n• «Как дела на всех ульях?»\n• «Какая сейчас погода?»\n• «Что показывают датчики?»\n• «Есть ли риск роения?»`,
    basis: [
      `Телеметрия: ${withData} из ${ctx.hives.length} ульев`,
      ...(ctx.weather ? ['Прогноз погоды'] : []),
      ...(ctx.pesticide ? ['Реестр обработок'] : []),
      ...(ctx.sites.length ? [`Справочник кочёвки: ${ctx.sites.length} площадок`] : []),
    ],
    urgency: 'ok',
    urgencyNote: 'Готов отвечать',
    metrics: [{ label: 'Ульев с данными', value: `${withData} из ${ctx.hives.length}` }],
  }
}

/** Короткая фраза про активные датчики точек на карте (для общих ответов). */
function pointsSummary(ctx: AgentContext): string | null {
  const pts = (ctx.points ?? []).filter((p) => p.sensor.on && p.sensor.tempC !== null)
  if (!pts.length) return null
  return pts
    .map(
      (p) =>
        `«${p.name}» (${p.hiveCount} улей на точке): +${fmtNum(p.sensor.tempC ?? 0)} °C, влажность ${fmtNum(p.sensor.humidityPct ?? 0, 0)} %, вес ${fmtNum(p.sensor.weightKg ?? 0)} кг, шум ${fmtNum(p.sensor.noiseDb ?? 0, 0)} дБ`,
    )
    .join('; ')
}

/** Сводка сразу по всем ульям — ответ на общий вопрос о пасеке. */
function allHivesAnswer(ctx: AgentContext): AgentMessage {
  const withData = ctx.hives.filter((h) => h.series.length > 0).length
  const lines = ctx.hives.map((h) => {
    const st = hiveStatus(h, ctx.hives)
    const w = lastWeight(h)
    const t = lastPoint(h)?.tempInC ?? null
    const hum = lastHumidity(h)
    const parts = [
      w !== null ? `${fmtNum(w)} кг` : null,
      t !== null ? `${fmtNum(t)} °C внутри` : null,
      hum !== null ? `влажность ${fmtNum(hum, 0)} %` : !h.humiditySensorOk ? 'датчик влажности молчит' : null,
    ].filter(Boolean)
    return `• улей №${h.id} — ${st.label.toLowerCase()}: ${parts.join(', ') || 'данных нет'}`
  })
  const leader = leaderOf(ctx.hives)
  const w0 = ctx.weather?.[0]
  const now = ctx.weatherNow
  const pts = pointsSummary(ctx)
  return {
    scenario: 'status',
    hiveId: null,
    text: `Сводка по всем ${ctx.hives.length} ульям пасеки:\n\n${lines.join('\n')}${
      leader ? `\n\nЛидер медосбора — улей №${leader.id}: ${fmtSigned(delta30d(leader) ?? 0)} кг ${periodLabel(leader)}.` : ''
    }${
      now || w0
        ? `\n\nПогода: ${now ? `${fmtSigned(now.tempC, 0)} °C, ${now.text.toLowerCase()}, ветер ${now.windKmh} км/ч. ` : ''}${
            w0
              ? `Сегодня ${w0.flight === 'good' ? 'хорошее окно лёта' : w0.flight === 'bad' ? 'лёта не будет' : 'условия средние'}: от ${fmtSigned(w0.tMin, 0)} до ${fmtSigned(w0.tMax, 0)} °C, осадки ${w0.precipProb} %.`
              : ''
          }`
        : ''
    }${pts ? `\n\nДатчики на карте: ${pts}.` : ''}`,
    basis: [
      `Телеметрия: ${withData} из ${ctx.hives.length} ульев`,
      ...(ctx.weather ? ['Прогноз погоды'] : []),
      ...(pts ? ['Датчики точек на карте'] : []),
    ],
    urgency: 'ok',
    urgencyNote: 'Сводка по всем ульям',
    metrics: [
      { label: 'Ульев с данными', value: `${withData} из ${ctx.hives.length}` },
      ...(leader ? [{ label: 'Лидер', value: `№${leader.id}: ${fmtSigned(delta30d(leader) ?? 0)} кг` }] : []),
      ...(now ? [{ label: 'Погода сейчас', value: `${fmtSigned(now.tempC, 0)} °C` }] : []),
    ],
  }
}

/** Риск роения сразу по всем ульям. */
function swarmAllAnswer(ctx: AgentContext): AgentMessage {
  const risky = ctx.hives.filter((h) => {
    const d2 = delta2d(h)
    return d2 !== null && d2 <= SWARM_DROP
  })
  if (risky.length) {
    const details = risky.map((h) => {
      const d2 = delta2d(h) ?? 0
      const t = lastPoint(h)?.tempInC ?? null
      return `улей №${h.id}: вес упал на ${fmtNum(Math.abs(d2))} кг за 2 дня${
        t !== null ? `, температура ${fmtNum(t)} °C (норма около 34,5 °C)` : ''
      }`
    })
    return {
      scenario: 'swarm',
      hiveId: null,
      text: `Проверил все ${ctx.hives.length} улья: признаки подготовки к роению вижу в ${
        risky.length === 1 ? 'одном улье' : `${risky.length} ульях`
      } — ${risky.map((h) => `№${h.id}`).join(', ')}.\n\n${details.join('.\n')}.\n\nОсмотрите эти семьи сегодня: маточники по краям рамок и «борода» пчёл на летке — главные признаки. По остальным ульям вес растёт ровно, риска нет.`,
      basis: risky.map((h) => `График веса улья №${h.id}`),
      urgency: 'today',
      urgencyNote: 'Осмотреть ульи сегодня',
      probability: swarmProbability(delta2d(risky[0]) ?? SWARM_DROP),
      metrics: [
        { label: 'Ульев в зоне риска', value: `${risky.length} из ${ctx.hives.length}` },
        { label: 'Падение веса', value: `${fmtNum(Math.abs(delta2d(risky[0]) ?? 0))} кг за 2 дня` },
      ],
    }
  }
  const deltas = ctx.hives.map((h) => `№${h.id} — ${fmtSigned(delta2d(h) ?? 0)} кг`).join(', ')
  return {
    scenario: 'swarm',
    hiveId: null,
    text: `Проверил все ульи: выраженных признаков роения не вижу. Изменение веса за 2 дня: ${deltas}. Провалов веса, как бывает перед роением, нет.\n\nПродолжаю следить за привесом и температурой каждый день: если где-то появится резкое падение веса при тёплой погоде — сразу предупрежу.`,
    basis: ['Сравнение привеса по всем ульям пасеки'],
    urgency: 'ok',
    urgencyNote: 'Наблюдать, сигнал придёт при изменениях',
    probability: 'Признаков роения сейчас нет',
    metrics: [{ label: 'Ульев проверено', value: String(ctx.hives.length) }],
  }
}

/** Температура сразу по всем ульям + погода снаружи. */
function climateAllAnswer(ctx: AgentContext): AgentMessage {
  const lines = ctx.hives.map((h) => {
    const t = lastPoint(h)?.tempInC ?? null
    return `№${h.id} — ${t !== null ? `${fmtNum(t)} °C` : 'данных нет'}`
  })
  const temps = ctx.hives
    .map((h) => lastPoint(h)?.tempInC ?? null)
    .filter((t): t is number => t !== null)
  const maxT = temps.length ? Math.max(...temps) : null
  const overheated = maxT !== null && maxT > 35.7
  const now = ctx.weatherNow
  const w0 = ctx.weather?.[0]
  return {
    scenario: overheated ? 'swarm' : 'status',
    hiveId: null,
    text: `Температура внутри ульев: ${lines.join(', ')}. Норма для семьи с расплодом — около 34,5 °C.${
      overheated && maxT !== null
        ? ` Самый тёплый улей держит ${fmtNum(maxT)} °C — заметно выше нормы; вместе с падением веса это похоже на подготовку к роению, проверьте семью.`
        : ' Заметных отклонений от нормы нет: семьи держат стабильный климат.'
    }${
      now
        ? `\n\nСнаружи сейчас ${fmtSigned(now.tempC, 0)} °C (${now.text.toLowerCase()})${
            w0 ? `, сегодня от ${fmtSigned(w0.tMin, 0)} до ${fmtSigned(w0.tMax, 0)} °C` : ''
          }.`
        : ''
    }`,
    basis: [
      'Датчики температуры всех ульёв',
      ...(now ? ['Актуальный прогноз погоды'] : []),
      ...(overheated ? ['Совместный анализ: температура + вес'] : []),
    ],
    urgency: overheated ? 'today' : 'ok',
    urgencyNote: overheated ? 'Проверить самый тёплый улей' : 'Климат в норме',
    probability: overheated ? 'Совместный анализ температуры и веса' : undefined,
    metrics: [
      { label: 'Макс. внутри', value: maxT !== null ? `${fmtNum(maxT)} °C` : 'нет данных' },
      ...(now ? [{ label: 'Снаружи', value: `${fmtSigned(now.tempC, 0)} °C` }] : []),
      { label: 'Норма семьи', value: '34,5 °C' },
    ],
  }
}

/** Влажность сразу по всем ульям, с честными пропусками по «молчащим» датчикам. */
function humidityAllAnswer(ctx: AgentContext): AgentMessage {
  const lines = ctx.hives.map((h) => {
    const hum = lastHumidity(h)
    if (hum !== null) return `• улей №${h.id} — ${fmtNum(hum, 0)} %`
    if (!h.humiditySensorOk) {
      return `• улей №${h.id} — датчик влажности молчит${h.humidityOfflineFrom ? ` с ${h.humidityOfflineFrom}` : ''}`
    }
    return `• улей №${h.id} — данных нет`
  })
  const wet = ctx.hives.filter((h) => (lastHumidity(h) ?? 0) > 70)
  const pts = (ctx.points ?? []).filter((p) => p.sensor.on && p.sensor.humidityPct !== null)
  return {
    scenario: 'status',
    hiveId: null,
    text: `Влажность по всем ульям (норма для летнего улья — 50–66 %):\n\n${lines.join('\n')}.${
      wet.length
        ? `\n\nВ ${wet.map((h) => `№${h.id}`).join(', ')} влажность выше комфортной зоны — в улье сыро, стоит улучшить вентиляцию.`
        : '\n\nВыше комфортной зоны влажность нигде не поднимается.'
    }${
      pts.length
        ? `\n\nДатчики точек на карте: ${pts.map((p) => `«${p.name}» — ${fmtNum(p.sensor.humidityPct ?? 0, 0)} %`).join(', ')}.`
        : ''
    }`,
    basis: ['Датчики влажности ульёв', 'Норма: 50–66 %', ...(pts.length ? ['Датчики точек на карте'] : [])],
    urgency: wet.length ? 'today' : 'ok',
    urgencyNote: wet.length ? 'Улучшить вентиляцию' : 'Наблюдать',
    metrics: [
      { label: 'Ульев с данными', value: `${ctx.hives.filter((h) => lastHumidity(h) !== null).length} из ${ctx.hives.length}` },
      ...(wet.length ? [{ label: 'Сырые ульи', value: wet.map((h) => `№${h.id}`).join(', ') }] : []),
    ],
  }
}

/** Вес и привес сразу по всем ульям + контрольные датчики на карте. */
function weightAllAnswer(ctx: AgentContext): AgentMessage {
  const rows = ctx.hives.map((h) => {
    const w = lastWeight(h)
    return `• улей №${h.id} — ${w !== null ? `${fmtNum(w)} кг` : 'данных нет'} (${fmtSigned(delta30d(h) ?? 0)} кг ${periodLabel(h)})`
  })
  const leader = leaderOf(ctx.hives)
  const pts = (ctx.points ?? []).filter((p) => p.sensor.on && p.sensor.weightKg !== null)
  return {
    scenario: 'status',
    hiveId: null,
    text: `Вес по всем ульям:\n\n${rows.join('\n')}.${
      leader
        ? `\n\nЛидер медосбора — улей №${leader.id}: ${fmtSigned(delta30d(leader) ?? 0)} кг ${periodLabel(leader)}. Набор веса — главный признак медосбора; резкое падение при тёплой погоде часто означает начало роения.`
        : ''
    }${
      pts.length
        ? `\n\nКонтрольные датчики на карте: ${pts.map((p) => `«${p.name}» — ${fmtNum(p.sensor.weightKg ?? 0)} кг (датчик в контрольном улье точки)`).join(', ')}.`
        : ''
    }`,
    basis: ['Графики веса всех ульёв', ...(pts.length ? ['Датчики точек на карте'] : [])],
    urgency: 'ok',
    urgencyNote: 'Наблюдать за привесом',
    metrics: [
      ...(leader ? [{ label: 'Лидер', value: `№${leader.id}: ${fmtSigned(delta30d(leader) ?? 0)} кг` }] : []),
      { label: 'Ульев с весами', value: `${ctx.hives.filter((h) => lastWeight(h) !== null).length} из ${ctx.hives.length}` },
    ],
  }
}

/** Шум по датчикам точек на карте. Нет датчика или он выключен — данных нет. */
function noiseAnswer(ctx: AgentContext): AgentMessage {
  const pts = (ctx.points ?? []).filter((p) => p.sensor.on && p.sensor.noiseDb !== null)
  if (!pts.length) {
    return {
      scenario: 'status',
      hiveId: null,
      text: 'Шум внутри улья измеряют датчики, которые стоят в точках на карте. Среди ваших точек активных датчиков нет (или они выключены), поэтому данных о шуме сейчас нет — говорю честно, цифры выдумывать не буду.\n\nВключите датчик в разделе «Датчики ульев» или на карте — и я начну следить: резкий рост шума обычно означает тревогу семьи.',
      basis: ['Датчики точек на карте: не активны'],
      urgency: 'this-week',
      urgencyNote: 'Включить датчики',
      probability: 'Данных недостаточно',
      metrics: [{ label: 'Активных датчиков', value: '0' }],
    }
  }
  const rows = pts.map((p) => `«${p.name}» — ${fmtNum(p.sensor.noiseDb ?? 0, 0)} дБ`).join(', ')
  const loudest = [...pts].sort((a, b) => (b.sensor.noiseDb ?? 0) - (a.sensor.noiseDb ?? 0))[0]
  const loud = (loudest.sensor.noiseDb ?? 0) > 60
  return {
    scenario: 'status',
    hiveId: null,
    text: `Шум по датчикам на карте: ${rows}. Норма для работающей семьи — 40–55 дБ: ровный монотонный гул.${
      loud
        ? ` В «${loudest.name}» шум повышенный — семья может быть тревожной или началось роение: стоит осмотреть улей.`
        : ' Повышенного шума нет — семьи работают спокойно.'
    }`,
    basis: [`Датчики точек на карте: ${pts.length} шт.`],
    urgency: loud ? 'today' : 'ok',
    urgencyNote: loud ? 'Осмотреть улей с повышенным шумом' : 'Шум в норме',
    metrics: [{ label: 'Макс. шум', value: `${fmtNum(loudest.sensor.noiseDb ?? 0, 0)} дБ` }],
  }
}

/** Обзор датчиков: точки на карте (температура, вес, влажность, шум) и датчики ульев. */
function sensorsAnswer(ctx: AgentContext): AgentMessage {
  const ptLines = (ctx.points ?? []).map((p) =>
    p.sensor.on
      ? `• «${p.name}» (${p.hiveCount} улей на точке) — датчик включён: +${fmtNum(p.sensor.tempC ?? 0)} °C, влажность ${fmtNum(p.sensor.humidityPct ?? 0, 0)} %, вес ${fmtNum(p.sensor.weightKg ?? 0)} кг, шум ${fmtNum(p.sensor.noiseDb ?? 0, 0)} дБ`
      : `• «${p.name}» (${p.hiveCount} улей на точке) — ${p.hasSensor ? 'датчик выключен — данных нет' : 'датчика нет — данных нет'}`,
  )
  const hiveLines = ctx.hives.map((h) =>
    h.humiditySensorOk
      ? `• улей №${h.id} — датчики в штатном режиме`
      : `• улей №${h.id} — датчик влажности не отвечает${h.humidityOfflineFrom ? ` с ${h.humidityOfflineFrom}` : ''}, возможно, сел аккумулятор`,
  )
  return {
    scenario: 'status',
    hiveId: null,
    text: `Датчики пасеки:\n\n${[...ptLines, ...hiveLines].join('\n')}\n\nПравило платформы: если датчика нет или он выключен — данные по улью не показываются и в советы не попадают. Цифры вслепую я не рисую.`,
    basis: ['Датчики точек на карте', 'Датчики ульёв'],
    urgency: 'ok',
    urgencyNote: 'Все датчики под контролем',
    metrics: [
      {
        label: 'Точек с датчиками',
        value: `${(ctx.points ?? []).filter((p) => p.sensor.on).length} из ${(ctx.points ?? []).length}`,
      },
      { label: 'Ульев на контроле', value: String(ctx.hives.length) },
    ],
  }
}

/** Вопрос о самом агенте: модель и устройство не раскрываем. */
function identityAnswer(): AgentMessage {
  return {
    scenario: 'status',
    hiveId: null,
    text: 'Я — ИИ-агент «Цифровой улей», цифровой помощник пасеки. Технические детали своего устройства не обсуждаю — для работы они и не нужны.\n\nЗато охотно отвечу на вопросы о погоде, ульях и датчиках: например, «Как дела на всех ульях?», «Какая сейчас погода?» или «Что показывают датчики?».',
    basis: [],
    urgency: 'ok',
    urgencyNote: 'Готов отвечать',
    metrics: [],
  }
}

function fallbackAnswer(): AgentMessage {
  return {
    scenario: 'offtopic',
    hiveId: null,
    text: 'Этот вопрос — не по моей теме. Я агент пасеки и веду разговоры только о погоде и ульях: вес, температура и влажность внутри улья, датчики, шум, медосбор, роение, кочёвка и обработки полей рядом, а также здоровье пчёл — болезни, лечение и уход.\n\nСпросите, например: «Как дела на всех ульях?», «Что делать, если пчёлы заболели?» или «Какая сейчас погода?».',
    basis: [],
    urgency: 'ok',
    urgencyNote: 'Не по теме',
    metrics: [],
  }
}

/* ------------------------------------------------------------------ */
/* Здоровье пчёл и уход: справочник правилового движка                  */
/* ------------------------------------------------------------------ */

interface CareTopic {
  id: string
  patterns: RegExp[]
  text: string
  urgency: Urgency
  urgencyNote: string
  probability?: string
  metrics: AgentMetric[]
  basis: string[]
}

/** Справочник болезней и сезонного ухода — для ответов без LLM (fallback).
 *  Каждый ответ: признаки → порядок действий → правило о ветслужбе/диагнозе. */
const CARE_TOPICS: CareTopic[] = [
  {
    id: 'foulbrood',
    patterns: [/гнил/, /гнилост/],
    urgency: 'act-now',
    urgencyNote: 'Изолировать улей и сообщить в ветслужбу',
    probability: 'Заразная болезнь расплода — окончательный диагноз ставит ветлаборатория',
    text: 'Гнилец — заразная болезнь расплода, и здесь время решает. Похожие признаки: крышечки ячеек западают и продырявлены, содержимое тягучее и гниющее с запахом клея или кислятины, высохшая масса прилипает чешуйкой к стенке ячейки.\n\nЧто делать:\n• прекратите кочёвку и лишние осмотры соседних ульев — инфекция переносится инструментом и пчёлами;\n• сообщите в ветеринарную службу: на заразные болезни расплода объявляют карантин, это требование правил ветконтроля;\n• точный диагноз ставит ветлаборатория — не начинайте лечение вслепую;\n• поражённые рамки и мусор с дна изымаются и перетапливаются с утилизацией по правилам, семьи пересаживают в чистые продезинфицированные ульи.\n\nЛечение назначает ветврач: американский гнилец лечится плохо — семьи обычно уничтожают, европейский поддаётся терапии.',
    metrics: [
      { label: 'Карантин', value: 'обязателен' },
      { label: 'Диагноз', value: 'только ветлаборатория' },
      { label: 'Риск', value: 'заражение всей пасеки' },
    ],
    basis: ['Справочник болезней пчёл', 'Правила ветконтроля пасек'],
  },
  {
    id: 'varroa',
    patterns: [/варроа/, /клещ/, /бипин/, /апивар/, /акара/, /щавелев/, /оксал/, /заклещ/],
    urgency: 'today',
    urgencyNote: 'Оценить заклещёванность и обработать',
    probability: 'Совет по справочнику — дозировки только по инструкции к препарату',
    text: 'Варроатоз — паразитирование клеща варроа на пчёлах и расплоде. Признаки: молодые пчёлы с недоразвитыми крыльями ползают у летка, на дне улья и в трутневом расплоде видны коричневые «семечки» клещей.\n\nЧто делать:\n• оцените заклещёванность — клещи на дне с сеткой или в трутневом расплоде; если больше 2–3 на сот, пора лечить;\n• основные окна обработок: после откачки мёда в конце лета и рано весной, по безрасплодному периоду;\n• средства — общепринятые полоски или обработка щавелевой (оксаловой) кислотой, строго по инструкции к конкретному препарату;\n• помогает подрамочная сетка, вырезание трутневого расплода и сильные семьи.\n\nОдна обработка пасеку не очищает — клещ быстро восстанавливается, поэтому обработки повторяют циклично.',
    metrics: [
      { label: 'Порог', value: 'более 2–3 клещей на сот' },
      { label: 'Окна обработок', value: 'конец лета и весна' },
      { label: 'Норма', value: 'заклещёванность до 2 %' },
    ],
    basis: ['Справочник болезней пчёл', 'Регламент осенних обработок'],
  },
  {
    id: 'nosema',
    patterns: [/нозем/, /понос/, /испачкан/],
    urgency: 'today',
    urgencyNote: 'Переселить семью и провести дезинфекцию',
    text: 'Нозематоз проявляется весной: пятна поноса на летке и прилетковой доске, ослабевшая семья, пчёлы ползают с раздутыми брюшками.\n\nЧто делать:\n• переселите семью в чистый продезинфицированный улей;\n• рамки с признаками поноса отбракуйте: перетопите или продезинфицируйте;\n• замените закисший корм на качественный, поставьте чистую воду;\n• лечение — общепринятые средства от ноземы по инструкции, а лучший способ не допустить болезнь — сильная семья и свежая вощина.\n\nИнструмент после осмотра продезинфицируйте — возбудитель передаётся через корм и соты.',
    metrics: [
      { label: 'Сезон риска', value: 'конец зимы — весна' },
      { label: 'Профилактика', value: 'качественный корм и дезинфекция' },
    ],
    basis: ['Справочник болезней пчёл'],
  },
  {
    id: 'chalkbrood',
    patterns: [/аскосфер/, /известков/, /мумии/, /аспергилл/],
    urgency: 'today',
    urgencyNote: 'Удалить поражённые рамки и осушить гнездо',
    text: 'Аскосфероз («известковый расплод») узнают по белым и серым мумиям — затвердевшим личинкам перед летком и на дне улья. Расцветает в сырых прохладных ульях и в слабых семьях.\n\nЧто делать:\n• удалите поражённые рамки и мусор с дна;\n• сократите и утеплите гнездо, чтобы семья держала норму тепла;\n• усилите вентиляцию и перенесите улей с сырой низины на сухое проветриваемое место;\n• если болезнь повторяется, обратитесь к ветслужбе — лечение назначается официально, как для заразной болезни расплода.\n\nПо датчикам сырость видна заранее: влажность выше 75 % — повод осушить улей ещё до появления мумий.',
    metrics: [
      { label: 'Условие риска', value: 'сырость выше 75 %' },
      { label: 'Профилактика', value: 'сухой вентилируемый улей' },
    ],
    basis: ['Справочник болезней пчёл', 'Телеметрия влажности ульёв'],
  },
  {
    id: 'wax-moth',
    patterns: [/восковая моль/, /(^|[^а-я])моль(?![а-я])/, /воск моль/],
    urgency: 'this-week',
    urgencyNote: 'Проморозить суши и навести порядок в хранении',
    text: 'Восковая моль портит запасные соты: паутина, червячки и ходы в суши на хранении. Пчёлы в живом улье сами выгоняют её, а вот склад — её дом.\n\nЧто делать:\n• поражённые соты проморозьте 1–2 дня на морозе — яйца и гусеницы гибнут;\n• сильно повреждённые рамки перетопите на воск;\n• храните суши в проветриваемых стопках с доступом света, а не в тёплом ящике;\n• при больших запасах используйте общепринятые средства против моли строго по инструкции и вне сезона медосбора.',
    metrics: [
      { label: 'Способ', value: 'проморозка 1–2 дня' },
      { label: 'Хранение', value: 'проветриваемая стопка' },
    ],
    basis: ['Справочник пчеловода: хранение суши'],
  },
  {
    id: 'queenless',
    patterns: [/осирот/, /нет матк/, /безматоч/, /матка пропал/, /матка потерян/, /матка исчез/, /трутовк/],
    urgency: 'today',
    urgencyNote: 'Подсадить матку или рамку с яйцами',
    text: 'Осиротевшая семья шумит «волнами», становится злой и суетливой, а главный признак — в гнезде нет свежего засева. Через несколько недель появляются трутовки — трутни в рабочих ячейках, и семья погибает.\n\nЧто делать:\n• проверьте гнездо на матку и свежий засев — осмотр при тёплой погоде;\n• подсадите плодную матку из запаса или дайте рамку с яйцами от сильной семьи — семья выведет свою;\n• приём проверьте через 2–3 дня: спокойное гудение и засев означают успех;\n• семью с трутовками лучше расформировать: усилить соседние семьи или подсадить матку под клеточку.',
    metrics: [
      { label: 'Главный признак', value: 'нет свежего засева' },
      { label: 'Проверка приёма', value: 'через 2–3 дня' },
    ],
    basis: ['Справочник пчеловода: семьи и матки'],
  },
  {
    id: 'wintering',
    patterns: [/зимов/, /к зиме/, /в зиму/, /весной осматр/, /омшаник/],
    urgency: 'this-week',
    urgencyNote: 'Проверить корма и вентиляцию до холодов',
    text: 'Подготовка к зимовке решает больше, чем любое лечение:\n• сильная семья: слабые осенью уже не окрепнут — объедините их или усильте расплодом;\n• корм: 18–25 кг качественного мёда или сиропа на семью, без закисшего и падевого;\n• вентиляция: без неё улей сыреет и семьи болеют;\n• место: тихое тёмное помещение 0…+4 °C или зимовка на воле под снегом;\n• до ухода в клуб — осенняя обработка от клеща варроа.\n\nЗимой ульи не тревожат: слушать семьи можно стетоскопом — ровный тихий гул означает, что всё в порядке.',
    metrics: [
      { label: 'Корм на семью', value: '18–25 кг' },
      { label: 'Температура', value: '0…+4 °C' },
      { label: 'Главная задача', value: 'сильная семья осенью' },
    ],
    basis: ['Справочник пчеловода: зимовка'],
  },
  {
    id: 'feeding',
    patterns: [/подкорм/, /сироп/, /канди/, /сахарн/, /кормушк/],
    urgency: 'ok',
    urgencyNote: 'Подкармливать по сезону',
    text: 'Подкормки по сезону:\n• весной — сахарный сироп 1:1 (1 кг сахара на 1 л воды) для стимуляции развития;\n• осенью — густой 2:1 на запас корма, на семью до 25 кг;\n• зимой и ранней весной — канди или сахарный леденец, кладут над клубом;\n• давать вечером, чтобы не спровоцировать воровство, и не во время медосбора — иначе в мёд попадёт сахарная примесь.\n\nГлавный корм всегда мёд с пергой; сироп — только помощь семье, а не замена.',
    metrics: [
      { label: 'Весенний сироп', value: '1:1' },
      { label: 'Осенний сироп', value: '2:1' },
      { label: 'Зимой', value: 'канди' },
    ],
    basis: ['Справочник пчеловода: корма и подкормки'],
  },
]

/** Общий ответ «пчёлы заболели — что делать», если конкретная болезнь не опознана. */
function sickBeesGeneral(): AgentMessage {
  return {
    scenario: 'care',
    hiveId: null,
    text: 'Если пчёлы выглядят больными, действую как пчеловод по проверенному алгоритму:\n\n1. Изолируйте подозрительный улей — не переставляйте рамки в другие семьи и не осматривайте их тем же инструментом.\n2. Осмотрите улей спокойно: расплод (цвет и крышечки ячеек), дно улья, прилетковая доска, поведение у летка — ползающие пчёлы, пятна, мумии, клещи.\n3. Сравните признаки: тягучая гниющая масса в ячейках — похоже на гнилец; белые мумии — на аскосфероз; пчёлы с рваными крыльями и клещи на расплоде — на варроатоз; пятна поноса — на нозематоз.\n4. При любом подозрении на заразную болезнь расплода сообщите в ветеринарную службу и держите улей под карантином — точный диагноз ставит ветлаборатория.\n5. Лечение — после диагноза и по инструкции к препарату; вслепую лечить нельзя.\n\nПрофилактика всегда одна: сильные семьи, чистые сухие ульи, свежая вощина, вентиляция и осенние обработки. Опишите, что именно видите в улье, — я подскажу конкретнее.',
    basis: ['Справочник болезней пчёл', 'Правила ветконтроля пасек'],
    urgency: 'today',
    urgencyNote: 'Осмотреть улей и изолировать от соседних',
    probability: 'Точный диагноз ставит осмотр и ветлаборатория',
    metrics: [
      { label: 'Первый шаг', value: 'изолировать улей' },
      { label: 'Диагноз', value: 'по признакам и ветлаборатории' },
      { label: 'Профилактика', value: 'сильные семьи и сухие ульи' },
    ],
  }
}

/** Ответы о здоровье пчёл и уходе: болезни, лечение, подкормки, сезонный уход. */
function beeCareAnswer(question: string, ctx: AgentContext): AgentMessage {
  const q = norm(question)
  for (const topic of CARE_TOPICS) {
    if (topic.patterns.some((p) => p.test(q))) {
      return {
        scenario: 'care',
        hiveId: null,
        text: topic.text,
        basis: topic.basis,
        urgency: topic.urgency,
        urgencyNote: topic.urgencyNote,
        probability: topic.probability,
        metrics: topic.metrics,
      }
    }
  }
  void ctx
  return sickBeesGeneral()
}

function thanksAnswer(): AgentMessage {
  return {
    scenario: 'status',
    hiveId: null,
    text: 'Всегда рядом. Напомню главный принцип: я показываю вероятность и уровень риска, а окончательное решение всегда принимает пчеловод.',
    basis: [],
    urgency: 'ok',
    urgencyNote: 'Наблюдать',
    metrics: [],
  }
}

/** Главная функция: вопрос пчеловода → структурированный ответ агента. */
export function askAgent(
  question: string,
  currentHiveId: number,
  ctx: AgentContext,
): AgentMessage {
  const q = norm(question)
  const hiveId = extractHiveId(q, ctx)
  const hive = ctx.hives.find((x) => x.id === (hiveId ?? currentHiveId)) ?? ctx.hives[0]

  const has = (...patterns: RegExp[]) => patterns.some((p) => p.test(q))

  // Приветствие и сервисные фразы
  if (has(/привет|здравств|добрый день|добрый вечер|доброе утро|что ты умеешь|чем ты можешь|помощь|справк/)) {
    return greetingAnswer(ctx)
  }
  // Вопрос о самом агенте: модель и устройство не раскрываем
  if (has(/кто ты|кто такой|как тебя зовут|ты бот|чат ?бот|какая (ты )?модель|какой (ты )?модель|на (чем|чём) ты (работаешь|сделан|написан)|что ты за|нейросет|искусственн|\bllm\b|\bgpt\b/)) {
    return identityAnswer()
  }
  if (has(/спасибо|благодар|класс|супер|отлично/)) {
    return thanksAnswer()
  }

  // Здоровье пчёл и уход: болезни, лечение, профилактика, подкормки, сезонный уход.
  // Ветка стоит ДО пестицидов: «обработать от клеща» — про лечение пчёл, а не про поле.
  if (
    has(
      /боле[етн]|болезн|заболел|недуг|варроа|клещ|нозем|аскосфер|известков|мумии|гнил|восковая моль|(^|[^а-я])моль(?![а-я])|лечен|лечит|вылеч|бипин|апивар|акара|щавелев|оксал|заклещ|полоск|подкорм|сироп|канди|сахарн|кормушк|ветеринар|ветврач|ветстанц|ветслужб|ветлабор|дезинфекц|осирот|нет матк|безматоч|матка пропал|матка потерян|матка исчез|трутовк|понос|испачкан|зим(ов|н)|к зиме|в зиму|омшаник|пчел.{0,14}(умира|погиб|гибнут)/,
    )
  ) {
    return beeCareAnswer(question, ctx)
  }

  // Сценарий пестицидов
  if (has(/пестицид|обработк|хими|опрыск|травят|фунгицид|инсектицид/)) {
    return pesticideAnswer(ctx)
  }

  // Кочёвка
  if (has(/кочев|перевез|перевоз|переех|перемест|новое место|куда (вывезти|ехать|ставить)|где лучше|выбор места|участк/)) {
    return migrationAnswer(ctx)
  }

  // Погода и медосбор (включая температуру ВОЗДЕУХА — не путать с температурой улья)
  if (has(/погод|медосбор|взятк|летат|лёт|лету|дожд|ветер|осадк|цветен|медонос|снег|мороз|когда вывоз|когда летать|температура (воздуха|за окном|на улице|снаружи)/)) {
    return weatherAnswer(ctx)
  }

  if (!hive) {
    return fallbackAnswer()
  }

  // Темы по ульям: если номер улья не назван — отвечаем сразу по ВСЕМ ульям
  if (has(/влажн|сырост|сыро/)) {
    return hiveId ? humidityAnswer(hive) : humidityAllAnswer(ctx)
  }
  if (has(/шум|децибел|гул(?![а-я])/)) {
    return noiseAnswer(ctx)
  }
  if (has(/ро(ение|иться|й|и(?![а-я]))|риск роения|делит|делени/)) {
    return hiveId ? swarmAnswer(hive, ctx) : swarmAllAnswer(ctx)
  }
  if (has(/температ|жар|тепло внутри|градус/)) {
    return hiveId ? climateAnswer(hive) : climateAllAnswer(ctx)
  }
  if (has(/вес|мед(?![а-я])|меда|привес|набор|тяже|лидер/)) {
    return hiveId ? weightAnswer(hive, ctx) : weightAllAnswer(ctx)
  }
  if (has(/датчик|сенсор/)) {
    return sensorsAnswer(ctx)
  }
  if (has(/все.{0,8}уль|всех ульев|всей пасек|пасек|обзор|сводк|итог|общее состояни|как дела|как себя|что происходит|состояни|статус|проверь|проблем|тревог|расскажи|что с улеем|как улей/)) {
    return hiveId ? statusAnswer(hive, ctx) : allHivesAnswer(ctx)
  }

  // Номер улья без распознанной темы — считаем вопросом «что происходит»
  if (hiveId !== null) {
    return statusAnswer(hive, ctx)
  }

  return fallbackAnswer()
}

/** Быстрые вопросы для чата — все про всю пасеку сразу. */
export const QUICK_QUESTIONS = [
  'Как дела на всех ульях?',
  'Какая сейчас погода?',
  'Что делать, если пчёлы заболели?',
  'Есть ли риск роения?',
  'Как подготовить пасеку к зимовке?',
  'Что показывают датчики?',
]
