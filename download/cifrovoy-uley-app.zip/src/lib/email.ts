/**
 * Письмо с кодом подтверждения email через SMTP (nodemailer).
 *
 * Настройки берутся из .env:
 *   EMAIL_SERVER_HOST / EMAIL_SERVER_PORT / EMAIL_SERVER_USER /
 *   EMAIL_SERVER_PASSWORD / EMAIL_FROM
 *
 * Пользователь вводит 6-значный код из письма прямо в приложении — переход
 * по ссылкам не требуется, поэтому домен в письме не нужен.
 * Если SMTP не настроен (пустой EMAIL_SERVER_HOST или EMAIL_FROM) — dev-режим:
 * код печатается в консоль сервера. Регистрация при этом не ломается.
 */
import nodemailer from 'nodemailer'

const APP_NAME = 'Цифровой улей'

function isSmtpConfigured(): boolean {
  return Boolean(process.env.EMAIL_SERVER_HOST && process.env.EMAIL_FROM)
}

/** HTML-письмо на русском: приветствие, пояснение, крупный код, примечания. */
function buildVerificationHtml(name: string, code: string): string {
  const greeting = name ? `Здравствуйте, ${name}!` : 'Здравствуйте!'
  return `<!DOCTYPE html>
<html lang="ru">
  <body style="margin:0; padding:0; background-color:#f4f1ee;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f1ee; padding:32px 16px;">
      <tr>
        <td align="center">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px; background-color:#ffffff; border-radius:16px; padding:40px 36px; font-family:Arial, Helvetica, sans-serif; color:#2a1a12;">
            <tr>
              <td style="font-size:20px; font-weight:bold; padding-bottom:16px;">
                ${APP_NAME}
              </td>
            </tr>
            <tr>
              <td style="font-size:16px; padding-bottom:12px;">
                ${greeting}
              </td>
            </tr>
            <tr>
              <td style="font-size:14px; line-height:1.6; color:#555555; padding-bottom:24px;">
                Чтобы завершить регистрацию, введите этот код подтверждения в приложении:
              </td>
            </tr>
            <tr>
              <td align="center" style="padding-bottom:24px;">
                <div style="font-size:34px; font-weight:bold; letter-spacing:10px; color:#c2410c; background-color:#fff7ed; border:1px solid #fed7aa; border-radius:12px; padding:18px 16px; text-align:center;">${code}</div>
              </td>
            </tr>
            <tr>
              <td style="font-size:13px; line-height:1.6; color:#555555; padding-bottom:20px;">
                Введите код в приложении на экране «Проверьте почту» и нажмите «Подтвердить email».
              </td>
            </tr>
            <tr>
              <td style="font-size:12px; color:#999999; border-top:1px solid #eeeeee; padding-top:16px;">
                Код действителен 30 минут. Если вы не регистрировались в «${APP_NAME}», просто проигнорируйте это письмо.
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`
}

/** Текстовая версия письма (multipart) — улучшает доставляемость и читаемость без HTML. */
function buildVerificationText(name: string, code: string): string {
  const greeting = name ? `Здравствуйте, ${name}!` : 'Здравствуйте!'
  return [
    greeting,
    '',
    'Чтобы завершить регистрацию в «Цифровом улье», введите этот код подтверждения в приложении:',
    '',
    `    ${code}`,
    '',
    'Код действителен 30 минут.',
    'Если вы не регистрировались в «Цифровом улье», просто проигнорируйте это письмо.',
  ].join('\n')
}

export type SendResult = 'sent' | 'dev-logged'

/**
 * Отправляет письмо с кодом подтверждения. Бросает исключение только при
 * настроенном, но неудавшемся SMTP-вызове — вызывающий код решает, как реагировать.
 */
export async function sendVerificationEmail(to: string, name: string, code: string): Promise<SendResult> {
  // SMTP не настроен — dev-fallback: печатаем код в консоль сервера.
  if (!isSmtpConfigured()) {
    console.log(`[email] SMTP не настроен, письмо НЕ отправлено. Код подтверждения для ${to}: ${code}`)
    return 'dev-logged'
  }

  const port = Number(process.env.EMAIL_SERVER_PORT ?? 587)
  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_SERVER_HOST,
    port,
    secure: port === 465, // 465 — implicit TLS, 587 — STARTTLS
    auth: process.env.EMAIL_SERVER_USER
      ? {
          user: process.env.EMAIL_SERVER_USER,
          pass: process.env.EMAIL_SERVER_PASSWORD,
        }
      : undefined,
    // Mail.ru обрывает TLS-рукопожатие без явного минимального TLS 1.2
    tls: { minVersion: 'TLSv1.2' },
  })

  const info = await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to,
    subject: `Код подтверждения — ${APP_NAME}`,
    html: buildVerificationHtml(name, code),
    text: buildVerificationText(name, code),
    // Просим почтовый сервер прислать отчёт при отказе/задержке — придёт в ящик отправителя
    dsn: { notify: ['FAILURE', 'DELAY'], ret: 'HDRS' },
  })
  console.log(`[email] письмо с кодом отправлено на ${to} (${info.messageId}). Код: ${code}`)
  return 'sent'
}
