'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import { AppShell } from '@/components/bee/AppShell'
import { DashboardView } from '@/components/bee/DashboardView'
import { AgentChatView } from '@/components/bee/AgentChat'
import { MigrationView } from '@/components/bee/MigrationView'
import { DataView } from '@/components/bee/DataView'
import { AboutView } from '@/components/bee/AboutView'
import { CalendarRemindersView } from '@/components/bee/CalendarRemindersView'
import { MapPointsView } from '@/components/bee/MapPointsView'
import { SensorsView } from '@/components/bee/SensorsView'
import { HistoryView } from '@/components/bee/HistoryView'
import { AuthView } from '@/components/bee/AuthView'
import { HexLogo } from '@/components/bee/decor'
import { useAppState } from '@/lib/store'

export default function Home() {
  const user = useAppState((s) => s.user)
  const authChecked = useAppState((s) => s.authChecked)
  const view = useAppState((s) => s.view)

  useEffect(() => {
    void useAppState.getState().initAuth()
  }, [])

  // Проверяем сессию — показываем нейтральный сплэш (совпадает с SSR, без гидрационных скачков)
  if (!authChecked) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#FAF6F3]">
        <HexLogo className="h-14 w-14 animate-pulse" />
        <p className="text-sm font-medium text-gray-400">Проверяем вход в систему…</p>
      </div>
    )
  }

  if (!user) {
    return <AuthView />
  }

  return (
    <AppShell>
      {/* Плавный переход между разделами */}
      <motion.div
        key={view}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        {view === 'dashboard' && <DashboardView />}
        {view === 'agent' && <AgentChatView />}
        {view === 'map' && <MapPointsView />}
        {view === 'sensors' && <SensorsView />}
        {view === 'history' && <HistoryView />}
        {view === 'migration' && <MigrationView />}
        {view === 'data' && <DataView />}
        {view === 'reminders' && <CalendarRemindersView />}
        {view === 'about' && <AboutView />}
      </motion.div>
    </AppShell>
  )
}
