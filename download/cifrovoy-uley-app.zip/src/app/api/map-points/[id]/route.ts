import { NextResponse } from 'next/server'
import { requireBeekeeper } from '@/lib/auth'
import { db } from '@/lib/db'

/**
 * Правка и удаление точки пасеки на карте. Только пасечник.
 * PATCH: { sensorOn?, hasSensor?, name?, hiveCount? } — включить/выключить
 * датчик, установить датчик, переименовать точку или изменить число ульев.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireBeekeeper()
  if (!guard.ok) {
    return NextResponse.json({ error: guard.error }, { status: guard.status })
  }
  const { id } = await params
  const item = await db.apiaryPoint.findUnique({ where: { id } })
  if (!item || item.userId !== guard.user.id) {
    return NextResponse.json({ error: 'Точка не найдена' }, { status: 404 })
  }
  const body = (await req.json().catch(() => ({}))) as {
    sensorOn?: boolean
    hasSensor?: boolean
    name?: string
    hiveCount?: number
  }
  const data: { sensorOn?: boolean; hasSensor?: boolean; name?: string; hiveCount?: number } = {}
  if (typeof body.sensorOn === 'boolean') data.sensorOn = body.sensorOn
  if (typeof body.hasSensor === 'boolean') {
    data.hasSensor = body.hasSensor
    // установили датчик — он включён; сняли — значит выключен
    data.sensorOn = body.hasSensor
  }
  if (body.name !== undefined) {
    const name = body.name.trim()
    if (!name || name.length > 60) {
      return NextResponse.json({ error: 'Название точки: от 1 до 60 символов' }, { status: 400 })
    }
    data.name = name
  }
  if (body.hiveCount !== undefined) {
    const hiveCount = Number(body.hiveCount)
    if (!Number.isInteger(hiveCount) || hiveCount < 1 || hiveCount > 999) {
      return NextResponse.json({ error: 'Число ульев: целое от 1 до 999' }, { status: 400 })
    }
    data.hiveCount = hiveCount
  }
  await db.apiaryPoint.update({ where: { id }, data })
  return NextResponse.json({ ok: true })
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const guard = await requireBeekeeper()
  if (!guard.ok) {
    return NextResponse.json({ error: guard.error }, { status: guard.status })
  }
  const { id } = await params
  const item = await db.apiaryPoint.findUnique({ where: { id } })
  if (!item || item.userId !== guard.user.id) {
    return NextResponse.json({ error: 'Точка не найдена' }, { status: 404 })
  }
  await db.apiaryPoint.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
