import { NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/auth'
import { db } from '@/lib/db'
import type { ChatHistoryItem } from '@/lib/api-types'

/** История чата по улью (hiveNumber) или общие вопросы (scope=general). */
export async function GET(req: Request) {
  const user = await getSessionUser()
  if (!user) {
    return NextResponse.json({ error: 'Нужен вход в систему' }, { status: 401 })
  }
  const url = new URL(req.url)
  const scope = url.searchParams.get('scope')
  const hiveNumberRaw = url.searchParams.get('hiveNumber')

  let hiveId: string | null = null
  if (scope !== 'general') {
    const n = Number(hiveNumberRaw)
    const hive = Number.isFinite(n) ? await db.hive.findUnique({ where: { number: n } }) : null
    hiveId = hive?.id ?? null
  }

  const messages = await db.chatMessage.findMany({
    where: { hiveId },
    orderBy: { createdAt: 'asc' },
    take: 100,
  })

  const items: ChatHistoryItem[] = messages.map((m) => ({
    id: m.id,
    role: m.role === 'agent' ? 'agent' : 'user',
    text: m.text,
    agentJson: m.agentJson,
    createdAt: m.createdAt.toISOString(),
  }))

  return NextResponse.json({ items })
}

/** Сохранение обмена: вопрос пчеловода + ответ агента. Доступно обеим ролям. */
export async function POST(req: Request) {
  const user = await getSessionUser()
  if (!user) {
    return NextResponse.json({ error: 'Нужен вход в систему' }, { status: 401 })
  }
  try {
    const body = (await req.json()) as {
      hiveNumber?: number | null
      userText?: string
      agent?: unknown
      agentText?: string
    }
    const userText = (body.userText ?? '').trim()
    if (!userText) {
      return NextResponse.json({ error: 'Пустой вопрос' }, { status: 400 })
    }
    let hiveId: string | null = null
    if (body.hiveNumber != null) {
      const hive = await db.hive.findUnique({ where: { number: Number(body.hiveNumber) } })
      hiveId = hive?.id ?? null
    }
    const agentText = (body.agentText ?? '').trim()
    const agentJson =
      body.agent && typeof body.agent === 'object' ? JSON.stringify(body.agent) : null

    await db.chatMessage.createMany({
      data: [
        { hiveId, role: 'user', text: userText, author: user.name },
        ...(agentText ? [{ hiveId, role: 'agent', text: agentText, agentJson, author: 'agent' }] : []),
      ],
    })
    return NextResponse.json({ ok: true })
  } catch (e) {
    console.error('chat save error', e)
    return NextResponse.json({ error: 'Ошибка сервера' }, { status: 500 })
  }
}
