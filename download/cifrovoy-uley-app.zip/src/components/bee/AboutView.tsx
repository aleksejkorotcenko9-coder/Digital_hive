'use client'

/**
 * Экран «Справка»: четыре сценария агента, словарь проекта,
 * принцип Data Driven и список возможностей приложения.
 */
import { ArrowRight, BookOpen, CloudSun, SprayCan, Split, Truck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAppState } from '@/lib/store'

const SCENARIOS = [
  {
    icon: Split,
    color: 'bg-red-100 text-red-700',
    title: 'Предупреждение о роении',
    text: 'Сравнивает изменение веса и температуры за несколько дней. При подозрительных изменениях предлагает осмотреть семью и проверить, не готовится ли она к роению.',
    example: 'Сигнал приходит, когда вес заметно падает при тёплой погоде — агент предложит осмотреть семью.',
  },
  {
    icon: SprayCan,
    color: 'bg-orange-100 text-orange-700',
    title: 'Защита от пестицидов',
    text: 'Сопоставляет координаты пасеки с предупреждениями об обработке полей. Если рядом планируется обработка, присылает срочное уведомление и предлагает меры защиты.',
    example: 'Когда реестр обработок будет подключён, агент предупредит об обработках рядом с пасекой.',
  },
  {
    icon: CloudSun,
    color: 'bg-sky-100 text-sky-700',
    title: 'Погода и медосбор',
    text: 'Учитывает температуру, осадки, ветер и влажность. Помогает понять, когда условия подходят для лёта пчёл и когда стоит проверить запасы и состояние улья.',
    example: 'Агент подскажет окно лёта пчёл по реальному прогнозу погоды на вашей пасеке.',
  },
  {
    icon: Truck,
    color: 'bg-emerald-100 text-emerald-700',
    title: 'Выбор места для кочёвки',
    text: 'Сравнивает возможные точки: где рядом цветут медоносные растения, какая ожидается погода, насколько далеко ехать и есть ли риски.',
    example: 'Добавьте участки в справочнике «Данные» — агент оценит и сравнит их между собой.',
  },
]

const DICTIONARY = [
  {
    term: 'Телеметрия',
    text: 'Данные, которые датчики автоматически передают с улья: вес, температура, влажность.',
  },
  {
    term: 'ИИ-агент',
    text: 'Программа-помощник, которая анализирует информацию и предлагает действия.',
  },
  {
    term: 'ГИС',
    text: 'Геоинформационная система — электронная карта с данными о местах, дорогах, полях и объектах.',
  },
  {
    term: 'Интернет вещей (IoT)',
    text: 'Устройства с датчиками, которые собирают и передают данные через интернет.',
  },
]

const MVP_CHECKLIST = [
  'Загрузка данных об ульях из таблицы (CSV)',
  'Карта пасеки и привязка ульев по кодам датчиков',
  'Графики веса и температуры, чтобы видеть изменения',
  'Окно диалога: вопрос обычными словами',
  'Рекомендации: риск роения и погода для медосбора',
  'Показ данных-основания, срочности и честность при нехватке данных',
  'Своя база данных SQLite: телеметрия, журнал, справочники, история чата',
  'Регистрация с подтверждением email и ролью: пасечник — полный доступ, помощник — просмотр',
  'Ввод данных тремя способами: CSV-файл, форма вручную, API-эндпоинт для датчиков',
]

export function AboutView() {
  const setView = useAppState((s) => s.setView)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-[#2A1A12] md:text-3xl">Справка: как работает приложение</h1>
        <p className="mt-1 max-w-3xl text-sm leading-relaxed text-gray-500">
          «Цифровой улей» — цифровая экосистема, которая помогает пчеловоду наблюдать за пасекой и управлять ею на основе данных.
          Приложение добавляет к данным «умного советчика»: не просто показать график, а дать понятный совет — что сделать, когда и почему.
        </p>
      </div>

      {/* Четыре сценария */}
      <div>
        <h2 className="mb-3 text-lg font-bold text-[#2A1A12]">Четыре полезных сценария</h2>
        <div className="grid gap-3 md:grid-cols-2">
          {SCENARIOS.map((s) => (
            <Card key={s.title} className="border-red-100 shadow-sm">
              <CardContent className="p-4 md:p-5">
                <div className="flex items-center gap-2.5">
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${s.color}`}>
                    <s.icon className="h-4.5 w-4.5" />
                  </span>
                  <h3 className="font-bold text-gray-900">{s.title}</h3>
                </div>
                <p className="mt-2.5 text-sm leading-relaxed text-gray-600">{s.text}</p>
                <p className="mt-2 rounded-lg bg-red-50/70 px-3 py-2 text-xs font-semibold text-red-700">{s.example}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Словарь */}
        <Card className="border-red-100 shadow-sm">
          <CardContent className="p-4 md:p-5">
            <h2 className="flex items-center gap-2 text-lg font-bold text-[#2A1A12]">
              <BookOpen className="h-5 w-5 text-red-600" /> Словарь проекта
            </h2>
            <dl className="mt-3 space-y-3">
              {DICTIONARY.map((d) => (
                <div key={d.term} className="rounded-xl border border-red-50 bg-red-50/40 p-3">
                  <dt className="text-sm font-bold text-red-800">{d.term}</dt>
                  <dd className="mt-1 text-sm leading-relaxed text-gray-600">{d.text}</dd>
                </div>
              ))}
            </dl>
          </CardContent>
        </Card>

        {/* Принципы и MVP */}
        <div className="space-y-4">
          <Card className="border-red-100 bg-gradient-to-br from-red-600 to-[#5B16C9] text-white shadow-sm">
            <CardContent className="p-4 md:p-5">
              <h2 className="text-lg font-bold">Главный принцип — Data Driven</h2>
              <p className="mt-2 text-sm leading-relaxed text-white/90">
                Решения на основе данных, а не догадок. Агент проходит три шага: получить данные → найти важное → дать рекомендацию
                с конкретным шагом, причиной и срочностью.
              </p>
              <ul className="mt-3 space-y-1.5 text-sm text-white/85">
                <li>• показывает, какие показатели повлияли на совет;</li>
                <li>• честно говорит, если данных недостаточно;</li>
                <li>• показывает вероятность и уровень риска, а не 100 % прогноз;</li>
                <li>• окончательное решение принимает пчеловод.</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-red-100 shadow-sm">
            <CardContent className="p-4 md:p-5">
              <h2 className="text-lg font-bold text-[#2A1A12]">Что уже умеет приложение</h2>
              <ul className="mt-3 space-y-2 text-sm text-gray-600">
                {MVP_CHECKLIST.map((c) => (
                  <li key={c} className="flex items-start gap-2">
                    <span className="mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[10px] font-bold text-emerald-700">
                      ✓
                    </span>
                    {c}
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button className="bg-red-600 hover:bg-red-700" onClick={() => setView('dashboard')}>
                  Открыть дашборд <ArrowRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" className="border-red-200 text-red-700 hover:bg-red-50" onClick={() => setView('agent')}>
                  Спросить агента
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <p className="text-xs leading-relaxed text-gray-400">
        Интерфейс рассчитан на пчеловода без технической подготовки. Данные принадлежат вам: телеметрия, журнал и справочники хранятся в вашей базе.
      </p>
    </div>
  )
}
