'use client'

/**
 * Диалог профиля и настроек (открывается из сайдбара/шапки):
 *  — фото профиля: загрузка с сжатием до 256px JPEG (data-URL в базу);
 *  — отображаемое имя;
 *  — тема: светлая / тёмная / системная (применяется сразу);
 *  — выход из аккаунта.
 */
import { useEffect, useRef, useState } from 'react'
import { Camera, CheckCircle2, LogOut, Monitor, Moon, Sun, Trash2, UserRound } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useToast } from '@/hooks/use-toast'
import { useAppState, applyTheme, type Theme } from '@/lib/store'
import { userLabel, type SafeUser } from '@/lib/api-types'
import { cn } from '@/lib/utils'

const ROLE_LABEL = { BEEKEEPER: 'Пасечник', HELPER: 'Помощник' } as const

const THEMES: Array<{ id: Theme; label: string; icon: typeof Sun }> = [
  { id: 'light', label: 'Светлая', icon: Sun },
  { id: 'dark', label: 'Тёмная', icon: Moon },
  { id: 'system', label: 'Системная', icon: Monitor },
]

/** Сжимает картинку до 256×256 JPEG data-URL (без внешних библиотек). */
function fileToAvatar(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('Не удалось прочитать файл'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('Файл не является изображением'))
      img.onload = () => {
        const size = 256
        const canvas = document.createElement('canvas')
        canvas.width = size
        canvas.height = size
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          reject(new Error('Canvas недоступен'))
          return
        }
        // кроп по центру + масштаб до квадрата
        const minSide = Math.min(img.width, img.height)
        const sx = (img.width - minSide) / 2
        const sy = (img.height - minSide) / 2
        ctx.drawImage(img, sx, sy, minSide, minSide, 0, 0, size, size)
        resolve(canvas.toDataURL('image/jpeg', 0.85))
      }
      img.src = String(reader.result)
    }
    reader.readAsDataURL(file)
  })
}

export function ProfileDialog() {
  const open = useAppState((s) => s.profileOpen)
  const setOpen = useAppState((s) => s.setProfileOpen)
  const user = useAppState((s) => s.user)
  const setUser = useAppState((s) => s.setUser)
  const theme = useAppState((s) => s.theme)
  const setTheme = useAppState((s) => s.setTheme)
  const logout = useAppState((s) => s.logout)
  const { toast } = useToast()

  const [name, setName] = useState('')
  const [savingName, setSavingName] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open && user) setName(userLabel(user))
  }, [open, user])

  if (!user) return null

  const patchProfile = async (payload: { displayName?: string | null; avatar?: string | null }) => {
    const res = await fetch('/api/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const j = (await res.json().catch(() => ({}))) as { user?: SafeUser; error?: string }
    if (!res.ok || !j.user) {
      toast({ title: 'Не сохранено', description: j.error ?? 'Ошибка сервера', variant: 'destructive' })
      return false
    }
    setUser(j.user)
    return true
  }

  const saveName = async () => {
    const trimmed = name.trim()
    if (!trimmed || trimmed === userLabel(user)) return
    setSavingName(true)
    const ok = await patchProfile({ displayName: trimmed })
    setSavingName(false)
    if (ok) toast({ title: 'Профиль сохранён', description: 'Имя обновлено' })
  }

  const onPickFile = async (file: File | undefined) => {
    if (!file) return
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Это не изображение', description: 'Выберите файл JPG или PNG', variant: 'destructive' })
      return
    }
    if (file.size > 15 * 1024 * 1024) {
      toast({ title: 'Файл слишком большой', description: 'До 15 МБ — дальше сожмём сами', variant: 'destructive' })
      return
    }
    setUploading(true)
    try {
      const dataUrl = await fileToAvatar(file)
      const ok = await patchProfile({ avatar: dataUrl })
      if (ok) toast({ title: 'Фото профиля обновлено' })
    } catch (e) {
      toast({
        title: 'Не удалось обработать фото',
        description: e instanceof Error ? e.message : 'Попробуйте другой файл',
        variant: 'destructive',
      })
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const removeAvatar = async () => {
    const ok = await patchProfile({ avatar: null })
    if (ok) toast({ title: 'Фото удалено' })
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-w-md rounded-2xl border-red-100 p-0 overflow-hidden sm:max-w-md">
        <DialogHeader className="border-b border-red-50 bg-red-50/50 px-5 py-4 dark:bg-[#2C211C]">
          <DialogTitle className="text-[#2A1A12]">Профиль и настройки</DialogTitle>
          <DialogDescription>Фото, имя и тема оформления — всё сохраняется в вашем аккаунте.</DialogDescription>
        </DialogHeader>

        <div className="space-y-5 px-5 py-4">
          {/* Фото */}
          <div className="flex items-center gap-4">
            <div className="relative">
              {user.avatar ? (
                 
                <img
                  src={user.avatar}
                  alt="Фото профиля"
                  className="h-16 w-16 rounded-full border-2 border-red-100 object-cover"
                />
              ) : (
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-orange-400 text-xl font-extrabold text-white">
                  {userLabel(user).slice(0, 1).toUpperCase()}
                </span>
              )}
              <button
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                aria-label="Загрузить фото"
                title={uploading ? 'Загружаем…' : 'Загрузить фото'}
                className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-red-600 text-white shadow-md transition-colors hover:bg-red-700 disabled:opacity-60"
              >
                <Camera className="h-3.5 w-3.5" />
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => void onPickFile(e.target.files?.[0])}
              />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-bold text-[#2A1A12]">{userLabel(user)}</p>
              <p className="text-xs text-gray-400">
                логин: {user.name} · {ROLE_LABEL[user.role]}
              </p>
              <div className="mt-1.5 flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-7 gap-1 border-red-200 px-2.5 text-xs text-red-600 hover:bg-red-50 hover:text-red-700"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                >
                  <Camera className="h-3 w-3" /> {uploading ? 'Загружаем…' : 'Заменить'}
                </Button>
                {user.avatar && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 gap-1 px-2.5 text-xs text-gray-500 hover:text-red-600"
                    onClick={() => void removeAvatar()}
                  >
                    <Trash2 className="h-3 w-3" /> Удалить
                  </Button>
                )}
              </div>
            </div>
          </div>

          {/* Имя */}
          <div className="space-y-1.5">
            <Label htmlFor="profile-name" className="text-xs font-semibold text-gray-600">
              Как вас зовут (видно в интерфейсе)
            </Label>
            <div className="flex gap-2">
              <Input
                id="profile-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={() => void saveName()}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') void saveName()
                }}
                placeholder="Иван Иванов"
                maxLength={60}
                className="border-red-100"
              />
              <Button
                size="sm"
                onClick={() => void saveName()}
                disabled={savingName || !name.trim() || name.trim() === userLabel(user)}
                className="shrink-0 gap-1 bg-red-600 hover:bg-red-700"
              >
                <CheckCircle2 className="h-3.5 w-3.5" /> Сохранить
              </Button>
            </div>
          </div>

          {/* Тема */}
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold text-gray-600">Тема оформления</Label>
            <div className="grid grid-cols-3 gap-2" role="group" aria-label="Тема оформления">
              {THEMES.map((t) => {
                const Icon = t.icon
                const active = theme === t.id
                return (
                  <button
                    key={t.id}
                    onClick={() => setTheme(t.id)}
                    aria-pressed={active}
                    className={cn(
                      'flex flex-col items-center gap-1.5 rounded-xl border px-2 py-3 text-xs font-semibold transition-all',
                      active
                        ? 'border-red-400 bg-red-50 text-red-700 shadow-sm dark:bg-[#2C211C]'
                        : 'border-red-100 text-gray-500 hover:border-red-200 hover:bg-red-50/50',
                    )}
                  >
                    <Icon className="h-4.5 w-4.5" />
                    {t.label}
                  </button>
                )
              })}
            </div>
            <p className="text-[11px] leading-relaxed text-gray-400">
              Тёмная тема меняет оформление всего приложения. «Системная» — как в настройках устройства.
            </p>
          </div>

          {/* Выход */}
          <div className="flex items-center justify-between rounded-xl border border-red-100 bg-red-50/40 px-3.5 py-3 dark:bg-[#2C211C]">
            <div>
              <p className="text-sm font-bold text-[#2A1A12]">Аккаунт</p>
              <p className="text-xs text-gray-400">Завершить сеанс на этом устройстве</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 border-red-200 text-red-600 hover:bg-red-50 hover:text-red-700"
              onClick={() => {
                setOpen(false)
                void logout()
              }}
            >
              <LogOut className="h-3.5 w-3.5" /> Выйти
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/** Аватар пользователя: фото или инициал на градиенте. */
export function UserAvatar({ user, className }: { user: SafeUser; className?: string }) {
  if (user.avatar) {
     
    return <img src={user.avatar} alt="" className={cn('rounded-full object-cover', className)} />
  }
  return (
    <span
      className={cn(
        'flex items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-orange-400 font-extrabold text-white',
        className,
      )}
    >
      {userLabel(user).slice(0, 1).toUpperCase()}
    </span>
  )
}

export function ProfileTrigger({
  user,
  onClick,
  className,
}: {
  user: SafeUser
  onClick: () => void
  className?: string
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left transition-colors hover:bg-red-50 dark:hover:bg-[#2C211C]',
        className,
      )}
      aria-label="Открыть профиль и настройки"
    >
      <UserAvatar user={user} className="h-9 w-9 text-sm" />
      <span className="min-w-0 flex-1 leading-tight">
        <span className="block truncate text-sm font-bold text-[#2A1A12]">{userLabel(user)}</span>
        <span className="block text-[11px] text-gray-400">{ROLE_LABEL[user.role]}</span>
      </span>
      <UserRound className="h-4 w-4 shrink-0 text-gray-300" />
    </button>
  )
}

export { applyTheme }
