'use client'

/**
 * Экран «Кочёвка»: площадки из справочника SQLite; если их нет —
 * агент честно говорит, что сравнивать нечего. Добавить площадки можно
 * в разделе «Данные».
 */
import { MapPin, Plus, TriangleAlert, Wind, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useAppState } from '@/lib/store'
import { cn } from '@/lib/utils'
import { fmtNum, type MigrationSite } from '@/lib/hive-model'
import { siteDtoToSite, useRealData } from '@/lib/real-data'

const VERDICT_META = {
  recommend: { label: 'Рекомендую', cls: 'bg-emerald-100 text-emerald-700', ring: 'border-emerald-300', bar: 'bg-emerald-500' },
  backup: { label: 'Запасной вариант', cls: 'bg-amber-100 text-amber-700', ring: 'border-amber-300', bar: 'bg-amber-500' },
  avoid: { label: 'Не рекомендую', cls: 'bg-red-100 text-red-700', ring: 'border-red-200', bar: 'bg-red-400' },
} as const

export function MigrationView() {
  const { status, data } = useRealData()

  if (status === 'idle' || status === 'loading') {
    return <div className="h-64 animate-pulse rounded-2xl bg-red-100/50" />
  }
  const sites = (data?.sites ?? []).map(siteDtoToSite)
  return <MigrationContent sites={sites} />
}

function MigrationContent({ sites }: { sites: MigrationSite[] }) {
  const ask = useAppState((s) => s.ask)
  const setView = useAppState((s) => s.setView)
  const best = [...sites].sort((a, b) => b.score - a.score)[0]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight text-[#2A1A12] md:text-3xl">Кочёвка: куда ехать за взятком</h1>
        <p className="mt-1 text-sm text-gray-500">
          Агент сравнивает участки вокруг пасеки по 4 факторам: медоносы, погода, расстояние и риски.
        </p>
      </div>

      {/* Рекомендация */}
      {best ? (
        <div className="rounded-2xl bg-gradient-to-br from-[#2A1A12] to-[#5B16C9] p-5 text-white shadow-lg shadow-red-200 md:p-6">
          <div className="flex flex-wrap items-center gap-2">
            <MapPin className="h-5 w-5 text-emerald-300" />
            <span className="text-xs font-bold uppercase tracking-wider text-white/80">Рекомендация агента</span>
          </div>
          <h2 className="mt-2 text-xl font-extrabold md:text-2xl">
            «{best.name}» — оценка {fmtNum(best.score)} / 10
          </h2>
          <p className="mt-2 max-w-3xl text-sm leading-relaxed text-white/85">
            {best.honeyPlant} цветёт {best.bloomWindow.toLowerCase()}, {fmtNum(best.distanceKm)} км от пасеки, погода: {best.weatherNote.toLowerCase()}.
            {best.risks ? ` Учтите: ${best.risks.toLowerCase()}.` : ''}
            {sites.length > 1
              ? ` Запасной вариант — «${[...sites].sort((a, b) => b.score - a.score)[1].name}».`
              : ' Добавьте ещё участки в справочнике — агент сравнит их между собой.'}
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              className="bg-white font-semibold text-[#5B16C9] hover:bg-red-50"
              onClick={() => ask('Куда перевезти пасеку?')}
            >
              Обсудить с агентом
            </Button>
            <Button
              variant="outline"
              className="border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white"
              onClick={() => ask('Чем опасна обработка поля рядом?')}
            >
              <Wind className="h-4 w-4" /> Проверить риски обработок
            </Button>
          </div>
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-red-300 bg-red-50/40 p-8 text-center">
          <MapPin className="mx-auto h-8 w-8 text-red-300" />
          <h2 className="mt-3 text-lg font-extrabold text-[#2A1A12]">В справочнике пока нет площадок</h2>
          <p className="mx-auto mt-1.5 max-w-md text-sm leading-relaxed text-gray-500">
            Честно: сравнивать нечего. Добавьте участки — медонос, сроки цветения, расстояние и риски,
            и агент оценит их по 4 факторам.
          </p>
          <Button onClick={() => setView('data')} className="mt-4 bg-orange-500 hover:bg-orange-600">
            <Plus className="h-4 w-4" /> Добавить площадку
          </Button>
        </div>
      )}

      {/* Карточки площадок */}
      <div className="space-y-3">
        {sites.map((s) => {
          const v = VERDICT_META[s.verdict]
          return (
            <Card key={s.id} className={cn('shadow-sm', v.ring)}>
              <CardContent className="p-4 md:p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg text-sm font-extrabold text-white', v.bar)}>
                    {s.id.slice(0, 1)}
                  </span>
                  <h3 className="font-bold text-gray-900">{s.name}</h3>
                  <span className={cn('ml-auto rounded-full px-2.5 py-1 text-xs font-bold', v.cls)}>{v.label}</span>
                </div>
                <div className="mt-3 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
                  <p className="text-gray-600"><span className="font-semibold text-gray-800">Медонос:</span> {s.honeyPlant}</p>
                  <p className="text-gray-600"><span className="font-semibold text-gray-800">Цветение:</span> {s.bloomWindow}</p>
                  <p className="text-gray-600"><span className="font-semibold text-gray-800">Расстояние:</span> {fmtNum(s.distanceKm)} км</p>
                  <p className="text-gray-600"><span className="font-semibold text-gray-800">Погода:</span> {s.weatherNote}</p>
                </div>
                {s.risks && (
                  <p className="mt-2 flex items-start gap-1.5 text-sm text-gray-600">
                    {s.verdict === 'avoid' ? (
                      <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                    ) : (
                      <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                    )}
                    <span><span className="font-semibold text-gray-800">Риски:</span> {s.risks}</span>
                  </p>
                )}
                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-gray-500">
                    <span>Оценка агента</span>
                    <span>{fmtNum(s.score)} / 10</span>
                  </div>
                  <div className="mt-1 h-2 rounded-full bg-gray-100">
                    <div
                      className={cn('h-2 rounded-full', v.bar)}
                      style={{ width: `${Math.max(4, Math.min(100, s.score * 10))}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Что проверяет агент */}
      <Card className="border-red-100 bg-red-50/50 shadow-sm">
        <CardContent className="p-4">
          <p className="text-sm font-bold text-[#2A1A12]">Что проверяет агент</p>
          <ul className="mt-2 grid gap-1.5 text-xs leading-relaxed text-gray-600 sm:grid-cols-2">
            <li>• какие медоносы цветут рядом и когда</li>
            <li>• какой будет погода и не сорвёт ли она медосбор</li>
            <li>• сколько ехать и не потревожит ли дорога семьи</li>
            <li>• нет ли рядом полей с запланированной обработкой</li>
          </ul>
        </CardContent>
      </Card>

      <p className="text-xs leading-relaxed text-gray-400">
        Агент показывает вероятность и уровень риска, а не стопроцентный прогноз. Окончательное решение о кочёвке принимает пчеловод.
      </p>
    </div>
  )
}
