'use client'

/**
 * Панель погоды как на референсе: карточка «Погода на пасеке» (текущая
 * температура, описание, ощущается как, ветер/влажность/давление) и список
 * «Погода на 10 дней» (день/ночь, ветер, осадки).
 * Данные — реальный метеосервис из интернета через /api/weather; если сервис
 * недоступен, панель честно помечает прогноз как приблизительный (source:
 * 'offline') — название источника в интерфейсе не показывается.
 * coords/place — координаты своей пасеки (Чишмы или Стерлитамак в зависимости
 * от режима): погода всегда берётся там, где стоят ульи.
 */
import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  Cloudy,
  Droplets,
  Gauge,
  RefreshCcw,
  Wind,
} from 'lucide-react'
import type { WeatherResponse } from '@/lib/api-types'
import { cn } from '@/lib/utils'
import { WeatherGlyph } from './weather-glyph'

export function WeatherPanel({
  compact = false,
  coords,
  place,
}: {
  compact?: boolean
  /** Координаты пасеки: прогноз именно там, где стоят ульи. */
  coords?: [number, number]
  /** Название места для подписи в карточке (например «Стерлитамак»). */
  place?: string
}) {
  const [data, setData] = useState<WeatherResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  const url = useMemo(() => {
    const sp = new URLSearchParams()
    if (coords) {
      sp.set('lat', coords[0].toFixed(4))
      sp.set('lon', coords[1].toFixed(4))
    }
    if (place) sp.set('place', place)
    const qs = sp.toString()
    return '/api/weather' + (qs ? `?${qs}` : '')
  }, [coords?.[0], coords?.[1], place])

  const load = useCallback(async () => {
    setError(null)
    try {
      const res = await fetch(url, { cache: 'no-store' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      setData((await res.json()) as WeatherResponse)
    } catch {
      setError('Не удалось получить погоду. Нажмите «Обновить» и попробуйте ещё раз.')
    }
  }, [url])

  useEffect(() => {
    void load()
    const timer = setInterval(() => void load(), 15 * 60 * 1000)
    return () => clearInterval(timer)
  }, [load])

  if (error) {
    return (
      <div className="rounded-2xl border border-red-100 bg-white p-4 text-sm text-gray-500 shadow-sm dark:bg-[#221814]">
        <p>{error}</p>
        <button
          onClick={() => void load()}
          className="mt-2 inline-flex items-center gap-1.5 font-bold text-red-600 hover:text-red-700"
        >
          <RefreshCcw className="h-3.5 w-3.5" /> Обновить
        </button>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="space-y-3">
        <div className="h-44 animate-pulse rounded-2xl bg-red-50/70" />
        <div className="h-72 animate-pulse rounded-2xl bg-red-50/50" />
      </div>
    )
  }

  const offlineNote =
    data.source === 'offline'
      ? 'метеосервис недоступен — приблизительный прогноз'
      : `обновлено ${new Date(data.updatedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`

  return (
    <div className="space-y-3">
      {/* Текущая погода */}
      <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm md:p-5 dark:bg-[#221814]">
        <h2 className="text-sm font-bold text-[#2A1A12]">Погода на пасеке</h2>
        <div className="mt-3 flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-5xl font-extrabold tracking-tight text-[#2A1A12]">
              {Math.round(data.now.tempC)}°
            </span>
            <div className="text-xs leading-snug text-gray-500">
              <p className="font-semibold text-gray-700">{data.now.text}</p>
              <p>Ощущается как {Math.round(data.now.feelsC)}°</p>
              <p className="mt-1 text-[11px] text-gray-400">{data.place} · {offlineNote}</p>
            </div>
          </div>
          <WeatherGlyph kind={data.now.icon} className="h-10 w-10" />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2.5 rounded-xl bg-red-50 px-3 py-2.5 dark:bg-[#2C211C]">
            <Wind className="h-4.5 w-4.5 text-red-400" />
            <div className="text-xs leading-tight">
              <p className="font-bold text-gray-800">{data.now.windKmh} км/ч</p>
              <p className="text-gray-400">ветер</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-red-50 px-3 py-2.5 dark:bg-[#2C211C]">
            <Droplets className="h-4.5 w-4.5 text-red-400" />
            <div className="text-xs leading-tight">
              <p className="font-bold text-gray-800">{data.now.humidityPct}%</p>
              <p className="text-gray-400">влажность</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-red-50 px-3 py-2.5 dark:bg-[#2C211C]">
            <Gauge className="h-4.5 w-4.5 text-red-400" />
            <div className="text-xs leading-tight">
              <p className="font-bold text-gray-800">{data.now.pressureMm}</p>
              <p className="text-gray-400">мм рт. ст.</p>
            </div>
          </div>
          <div className="flex items-center gap-2.5 rounded-xl bg-red-50 px-3 py-2.5 dark:bg-[#2C211C]">
            <Cloudy className="h-4.5 w-4.5 text-red-400" />
            <div className="text-xs leading-tight">
              <p className="font-bold text-gray-800">{data.days[0]?.precipProb ?? 0}%</p>
              <p className="text-gray-400">осадки сегодня</p>
            </div>
          </div>
        </div>
      </section>

      {/* Прогноз на 10 дней */}
      {!compact && (
        <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm md:p-5 dark:bg-[#221814]">
          <h2 className="text-sm font-bold text-[#2A1A12]">Погода на 10 дней</h2>
          <ul className="mt-2 divide-y divide-red-50">
            {data.days.map((d, i) => (
              <li key={d.date} className="flex items-center gap-3 py-2.5">
                <div className="w-[86px] shrink-0 leading-tight">
                  <p className="text-xs font-bold text-gray-800">{i === 0 ? 'Сегодня' : i === 1 ? 'Завтра' : d.date.slice(8) + ' ' + d.weekday}</p>
                  <p className="text-[11px] text-gray-400">{i > 1 ? d.dayLabel : d.weekday}</p>
                </div>
                <WeatherGlyph kind={d.icon} className="h-5 w-5 shrink-0" />
                {d.precipProb >= 30 ? (
                  <span className="shrink-0 text-[11px] font-semibold text-red-400">{d.precipProb}%</span>
                ) : (
                  <span className="w-[30px] shrink-0" />
                )}
                <span className="ml-auto shrink-0 text-[11px] text-gray-400">
                  день <span className="font-bold text-gray-800">{d.tMax > 0 ? `+${d.tMax}°` : `${d.tMax}°`}</span>
                </span>
                <span className="w-[58px] shrink-0 text-right text-xs text-gray-500">
                  ночь <span className="font-bold text-gray-700">{d.tMin > 0 ? `+${d.tMin}°` : `${d.tMin}°`}</span>
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
