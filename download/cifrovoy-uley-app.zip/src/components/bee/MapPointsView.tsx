'use client'

/**
 * «Карта пасеки» (Яндекс Карты, JS API 2.1 — без ключа, подключение через src/lib/ymaps.ts).
 * — Карта показывает ульи пользователя (точки ApiaryPoint в БД, привязанные
 *   по кодам датчиков).
 * — Клик по карте выбирает точку: карточка погоды в этом месте (реальные данные
 *   через /api/weather?lat&lon: сейчас + 3 дня, влажность, ветер, давление).
 * — Кнопка «Добавить улей»: вводим код датчика с его корпуса — датчик находится
 *   в каталоге (lib/sensor-catalog.ts), его GPS-позиция сразу показывается на
 *   карте (синяя метка-превью), после подтверждения улей привязывается в этой
 *   точке. Лимита на число ульев нет — один датчик ставится в один улей.
 * — Список точек справа: переключение датчика, удаление, перелёт к точке.
 * Анимации: появление карточки погоды, маркеров, превью GPS и пунктов списка.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CircleAlert, CircleCheck, MapPin, MapPinPlus, RefreshCcw, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useToast } from '@/hooks/use-toast'
import { useAppState } from '@/lib/store'
import { cn } from '@/lib/utils'
import { WeatherGlyph } from './weather-glyph'
import type { MapPointDto, WeatherResponse } from '@/lib/api-types'
import { findSensor, normalizeCode, DEFAULT_PLACE, SENSOR_CATALOG } from '@/lib/sensor-catalog'
import { loadYmaps } from '@/lib/ymaps'
import type {
  YmapsApi,
  YmapsCoords,
  YmapsGeoCollection,
  YmapsGeoObject,
  YmapsMap,
} from '@/lib/ymaps'
import type { SensorDevice } from '@/lib/sensor-catalog'

const ease = { duration: 0.3, ease: 'easeOut' as const }

const SENSOR_LABEL = { active: 'активен', off: 'выключен', none: 'не установлен' } as const

/** Подписи зон в подсказке диалога привязки. */
const ZONE_LABEL: Record<SensorDevice['zone'], string> = {
  field: 'Поля в стороне от города',
  city: 'Рядом с городом (Уфа)',
  sterlitamak: 'Поля за Стерлитамаком',
}

/** HTML-макет метки улья для Яндекс Карт: круг с 🐝 + подпись «N ул.» снизу. */
const HIVE_ICON_TPL =
  '<div style="position:relative;width:34px;height:34px;">' +
  '<div style="display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:50%;background:{{ properties.color }};border:3px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.3);font-size:16px;">🐝</div>' +
  '<span style="position:absolute;left:50%;top:37px;transform:translateX(-50%);background:#2A1A12;color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:9999px;white-space:nowrap;">{{ properties.label }}</span>' +
  '</div>'

/** Область клика метки: круг + подпись (пиксели относительно точки привязки). */
const HIVE_ICON_SHAPE = { type: 'Rectangle', coordinates: [[-17, -17], [17, 39]] }

export function MapPointsView() {
  const user = useAppState((s) => s.user)
  const { toast } = useToast()
  const isBeekeeper = user?.role === 'BEEKEEPER'

  // В диалоге привязки показываем весь каталог: датчики полей и города
  const zones: SensorDevice['zone'][] = ['field', 'city', 'sterlitamak']

  const containerRef = useRef<HTMLDivElement | null>(null)
  const mapRef = useRef<YmapsMap | null>(null)
  const ymRef = useRef<YmapsApi | null>(null)
  const pointsColRef = useRef<YmapsGeoCollection | null>(null)
  const selColRef = useRef<YmapsGeoCollection | null>(null)
  const prevColRef = useRef<YmapsGeoCollection | null>(null)
  const markerRefs = useRef<Map<string, YmapsGeoObject>>(new Map())
  const layoutRef = useRef<unknown>(null)
  const clickRef = useRef<(lat: number, lon: number) => void>(() => undefined)
  const [mapReady, setMapReady] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)

  const [points, setPoints] = useState<MapPointDto[] | null>(null)
  const [selected, setSelected] = useState<{ lat: number; lon: number } | null>(null)
  const [weather, setWeather] = useState<WeatherResponse | null>(null)
  const [weatherLoading, setWeatherLoading] = useState(false)

  // диалог привязки улья по коду датчика
  const [dialogOpen, setDialogOpen] = useState(false)
  const [code, setCode] = useState('')
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)

  // Как только введён код из каталога — сразу знаем GPS-позицию датчика
  const found = useMemo(() => findSensor(code), [code])
  const showNotFound = normalizeCode(code).length >= 4 && !found

  /* ---------- карта (Яндекс Карты) ---------- */
  useEffect(() => {
    let disposed = false
    void (async () => {
      let ym: YmapsApi
      try {
        ym = await loadYmaps()
      } catch (err) {
        if (!disposed) {
          setMapError(err instanceof Error ? err.message : 'Не удалось загрузить карту — проверьте соединение')
        }
        return
      }
      if (disposed || !containerRef.current) return

      // controls: переключатель «Схема / Спутник / Гибрид» + масштаб и геолокация;
      // suppressMapOpenBlock — без блока «Открыть в Яндекс Картах»
      const map = new ym.Map(containerRef.current, {
        // стартовый центр — запасной; как только точки загрузятся, перелетаем к пасеке
        center: [...DEFAULT_PLACE.center] as YmapsCoords,
        zoom: 12,
        controls: ['zoomControl', 'typeSelector', 'fullscreenControl', 'geolocationControl', 'rulerControl'],
        suppressMapOpenBlock: true,
      })
      map.behaviors.enable('scrollZoom')

      // События меток всплывают до карты: выбираем точку только по клику «в пустое место»
      map.events.add('click', (e) => {
        if (e.get('target') !== map) return
        const coords = e.get('coords') as YmapsCoords | undefined
        if (!coords) return
        clickRef.current(coords[0], coords[1])
      })

      const pointsCol = new ym.GeoObjectCollection()
      const selCol = new ym.GeoObjectCollection()
      const prevCol = new ym.GeoObjectCollection()
      map.geoObjects.add(pointsCol).add(selCol).add(prevCol)

      // HTML-макет метки улья (круг 🐝 + подпись с числом ульев)
      layoutRef.current = ym.templateLayoutFactory.createClass(HIVE_ICON_TPL)

      ymRef.current = ym
      mapRef.current = map
      pointsColRef.current = pointsCol
      selColRef.current = selCol
      prevColRef.current = prevCol
      setMapReady(true)
    })()
    return () => {
      disposed = true
      mapRef.current?.destroy()
      mapRef.current = null
      pointsColRef.current = null
      selColRef.current = null
      prevColRef.current = null
      markerRefs.current.clear()
      setMapReady(false)
    }
  }, [])

  /* ---------- данные точек ---------- */
  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/map-points', { cache: 'no-store' })
      if (!res.ok) return
      const j = (await res.json()) as { points: MapPointDto[] }
      setPoints(j.points)
    } catch {
      // карта и погода продолжают работать, точки подтянутся при следующем обновлении
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  // Первый успешный приход точек: перелетаем к фактическому центру пасеки.
  // pannedRef — чтобы не дёргать камеру на каждом опросе.
  const pannedRef = useRef(false)
  useEffect(() => {
    if (!mapReady || pannedRef.current) return
    if (!points || points.length === 0) return
    pannedRef.current = true
    const map = mapRef.current
    if (!map) return
    const lat = points.reduce((s, p) => s + p.lat, 0) / points.length
    const lon = points.reduce((s, p) => s + p.lon, 0) / points.length
    map.panTo([lat, lon], { duration: 700, flying: true })
  }, [points, mapReady])

  /* ---------- курсор и клики ---------- */
  const onMapClick = useCallback((lat: number, lon: number) => {
    // Клик по карте — только выбор точки для погоды; улей привязывается
    // по коду датчика в диалоге, вручную координаты не задаются
    setSelected({ lat, lon })
  }, [])

  useEffect(() => {
    clickRef.current = onMapClick
  }, [onMapClick])

  useEffect(() => {
    if (!mapReady) return
    // Стандартный курсор «ладошка»: точки больше не ставятся кликом —
    // улей привязывается по коду датчика в диалоге
    mapRef.current?.cursors.push('grab')
  }, [mapReady])

  /* ---------- маркеры точек ---------- */
  useEffect(() => {
    const ym = ymRef.current
    const col = pointsColRef.current
    const layout = layoutRef.current
    if (!mapReady || !ym || !col || layout === null || !points) return
    col.removeAll()
    markerRefs.current.clear()
    for (const p of points) {
      const active = p.sensor.reason === 'active'
      const color = active ? '#22c55e' : p.hasSensor ? '#f59e0b' : '#94a3b8'
      const readings = active
        ? `<br>🌡 ${p.sensor.tempC} °C · 💧 ${p.sensor.humidityPct} %<br>⚖ ${p.sensor.weightKg} кг · 🔊 ${p.sensor.noiseDb} дБ`
        : `<br><i>Данных об улье нет — датчик ${SENSOR_LABEL[p.sensor.reason]}.</i>`
      const pm = new ym.Placemark(
        [p.lat, p.lon],
        {
          color,
          label: `${p.hiveCount} ул.`,
          balloonContentHeader: p.name,
          balloonContentBody: `Датчик: <b>${p.sensorCode ?? '—'}</b><br>GPS: ${p.lat.toFixed(4)}, ${p.lon.toFixed(4)}<br>Состояние: ${SENSOR_LABEL[p.sensor.reason]}${readings}`,
        },
        {
          iconLayout: layout,
          iconShape: HIVE_ICON_SHAPE,
          iconOffset: [-17, -17],
          hideIconOnBalloonOpen: false,
        },
      )
      col.add(pm)
      markerRefs.current.set(p.id, pm)
    }
  }, [points, mapReady])

  /* ---------- маркер выбранной точки ---------- */
  useEffect(() => {
    const ym = ymRef.current
    const col = selColRef.current
    if (!mapReady || !ym || !col) return
    col.removeAll()
    if (!selected) return
    col.add(
      new ym.Placemark(
        [selected.lat, selected.lon],
        { balloonContentBody: 'Выбранная точка — погода справа' },
        { preset: 'islands#redDotIcon', iconColor: '#ef4444', hideIconOnBalloonOpen: false },
      ),
    )
  }, [selected, mapReady])

  /* ---------- превью GPS-позиции датчика при вводе кода ---------- */
  useEffect(() => {
    const ym = ymRef.current
    const col = prevColRef.current
    const map = mapRef.current
    if (!mapReady || !ym || !col) return
    col.removeAll()
    if (!dialogOpen || !found) return
    // Синяя метка «здесь будет улей»: позиция, которую передаёт датчик
    col.add(
      new ym.Placemark(
        [found.lat, found.lon],
        {
          balloonContentHeader: 'Позиция по GPS датчика',
          balloonContentBody: `Датчик: <b>${found.code}</b> · ${found.model}<br>GPS: ${found.lat.toFixed(4)}, ${found.lon.toFixed(4)}<br>${found.note}`,
        },
        { preset: 'islands#blueCircleDotIcon', iconColor: '#2563eb', hideIconOnBalloonOpen: false },
      ),
    )
    if (map) {
      if (map.getZoom() < 12) map.setZoom(12)
      map.panTo([found.lat, found.lon], { duration: 700, flying: true })
    }
  }, [dialogOpen, found, mapReady])

  /* ---------- погода выбранной точки ---------- */
  useEffect(() => {
    if (!selected) {
      setWeather(null)
      return
    }
    const ctl = new AbortController()
    setWeatherLoading(true)
    setWeather(null)
    fetch(`/api/weather?lat=${selected.lat}&lon=${selected.lon}`, {
      signal: ctl.signal,
      cache: 'no-store',
    })
      .then((r) => r.json() as Promise<WeatherResponse>)
      .then((j) => setWeather(j))
      .catch(() => undefined)
      .finally(() => {
        if (!ctl.signal.aborted) setWeatherLoading(false)
      })
    return () => ctl.abort()
  }, [selected])

  /** Плавный перелёт к точке: зум до 12, полёт Яндекса, затем открываем балун метки. */
  const flyMapTo = (lat: number, lon: number, balloonId?: string) => {
    const map = mapRef.current
    if (!map) return
    if (map.getZoom() < 12) map.setZoom(12)
    map.panTo([lat, lon], { duration: 700, flying: true })
    if (balloonId) {
      setTimeout(() => markerRefs.current.get(balloonId)?.balloon.open(), 750)
    }
  }

  /* ---------- привязать улей по коду датчика ---------- */
  const place = async () => {
    if (!found) return
    setBusy(true)
    try {
      const res = await fetch('/api/map-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sensorCode: found.code, name: name.trim() }),
      })
      const j = (await res.json().catch(() => ({}))) as { point?: MapPointDto; error?: string }
      if (!res.ok || !j.point) {
        toast({ title: 'Не получилось', description: j.error ?? 'Ошибка сервера', variant: 'destructive' })
        return
      }
      setPoints((prev) => [...(prev ?? []), j.point as MapPointDto])
      toast({
        title: 'Улей добавлен',
        description: `Позиция определена по датчику ${j.point.sensorCode}: ${j.point.lat.toFixed(4)}, ${j.point.lon.toFixed(4)}`,
      })
      setDialogOpen(false)
      setCode('')
      setName('')
      flyMapTo(j.point.lat, j.point.lon, j.point.id)
    } finally {
      setBusy(false)
    }
  }

  const patchSensor = async (
    p: MapPointDto,
    body: { sensorOn?: boolean; hasSensor?: boolean },
    okMsg: string,
  ) => {
    const res = await fetch(`/api/map-points/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      toast({ title: 'Не получилось', variant: 'destructive' })
      return
    }
    toast({ title: okMsg })
    // оптимистично правим карточку, серверный ответ уточнит детали
    setPoints((prev) =>
      prev
        ? prev.map((x) => {
            if (x.id !== p.id) return x
            const hasSensor = body.hasSensor ?? x.hasSensor
            const sensorOn = body.sensorOn ?? (body.hasSensor !== undefined ? body.hasSensor : x.sensorOn)
            return { ...x, hasSensor, sensorOn }
          })
        : prev,
    )
    void load()
  }

  const removePoint = async (p: MapPointDto) => {
    const res = await fetch(`/api/map-points/${p.id}`, { method: 'DELETE' })
    if (!res.ok) {
      toast({ title: 'Не удалось удалить точку', variant: 'destructive' })
      return
    }
    setPoints((prev) => prev?.filter((x) => x.id !== p.id) ?? null)
    toast({ title: 'Точка удалена с карты' })
  }

  const flyTo = (p: MapPointDto) => flyMapTo(p.lat, p.lon, p.id)

  const list = points ?? []
  const summary = useMemo(() => {
    const hives = list.reduce((s, p) => s + p.hiveCount, 0)
    const sensors = list.filter((p) => p.hasSensor && p.sensorOn).length
    return { hives, sensors }
  }, [list])

  return (
    <div className="mx-auto max-w-6xl space-y-5">
      {/* Шапка */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-[#2A1A12]">
            Карта пасеки
          </h1>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Кликните по карте — покажу погоду в этой точке. Улей привязывается по коду датчика:
            позицию задаёт GPS самого датчика.
          </p>
        </div>
        {isBeekeeper && (
          <Button
            onClick={() => setDialogOpen(true)}
            className="gap-1.5 bg-gradient-to-r from-red-600 to-orange-500 font-bold active:scale-95"
          >
            <MapPinPlus className="h-4 w-4" />
            Добавить улей
          </Button>
        )}
      </div>

      {/* Карта + правая колонка */}
      <div className="grid gap-4 xl:grid-cols-[1fr_340px]">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={ease}
          className="relative overflow-hidden rounded-2xl border border-red-100 shadow-sm"
        >
          <div ref={containerRef} className="h-[440px] w-full md:h-[520px]" />
          {!mapReady && !mapError && (
            <div className="absolute inset-0 flex items-center justify-center gap-2 bg-red-50/60 text-xs font-semibold text-gray-500">
              <RefreshCcw className="h-4 w-4 animate-spin" /> Загружаем карту…
            </div>
          )}
          {mapError && (
            <div className="absolute inset-0 flex items-center justify-center bg-red-50/90 px-6 text-center text-xs font-semibold text-red-700">
              {mapError}
            </div>
          )}
        </motion.div>

        <div className="space-y-4">
          {/* Погода выбранной точки */}
          <Card className="border-red-100 shadow-sm">
            <CardContent className="p-4">
              <h2 className="flex items-center gap-2 text-sm font-bold text-[#2A1A12]">
                <MapPin className="h-4 w-4 text-red-600" />
                Погода в точке
                {selected && (
                  <span className="ml-auto text-[10px] font-medium tabular-nums text-gray-400">
                    {selected.lat.toFixed(3)}, {selected.lon.toFixed(3)}
                  </span>
                )}
              </h2>

              {!selected && (
                <p className="mt-3 text-xs text-gray-500">
                  Выберите точку на карте — покажу все условия: температуру, ветер, влажность,
                  давление и прогноз на 3 дня.
                </p>
              )}

              <AnimatePresence mode="wait">
                {selected && (
                  <motion.div
                    key={`${selected.lat.toFixed(4)},${selected.lon.toFixed(4)}`}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={ease}
                    className="mt-3"
                  >
                    {weatherLoading || !weather ? (
                      <div className="flex items-center justify-center gap-2 py-8 text-xs text-gray-400">
                        <RefreshCcw className="h-4 w-4 animate-spin" /> Запрашиваем погоду…
                      </div>
                    ) : (
                      <>
                        <div className="flex items-center gap-3">
                          <WeatherGlyph kind={weather.now.icon} className="h-9 w-9" />
                          <div>
                            <p className="text-3xl font-extrabold leading-none text-[#2A1A12]">
                              {Math.round(weather.now.tempC)}°
                            </p>
                            <p className="mt-1 text-xs font-semibold text-gray-500">{weather.now.text}</p>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                          {[
                            ['Ощущается', `${Math.round(weather.now.feelsC)}°`],
                            ['Влажность', `${weather.now.humidityPct} %`],
                            ['Ветер', `${weather.now.windKmh} км/ч`],
                            ['Давление', `${weather.now.pressureMm} мм`],
                          ].map(([k, v], i) => (
                            <motion.div
                              key={k}
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ ...ease, delay: 0.05 * i }}
                              className="flex items-center justify-between rounded-lg border border-red-100 bg-red-50/40 px-2.5 py-1.5 dark:bg-[#2C211C]"
                            >
                              <span className="text-gray-500">{k}</span>
                              <span className="font-bold text-[#2A1A12]">{v}</span>
                            </motion.div>
                          ))}
                        </div>

                        <div className="mt-3 grid grid-cols-3 gap-2">
                          {weather.days.slice(0, 3).map((d) => (
                            <div
                              key={d.date}
                              className="flex flex-col items-center gap-0.5 rounded-lg border border-red-100 px-1 py-2 text-center"
                            >
                              <span className="text-[10px] font-bold uppercase text-gray-400">{d.weekday}</span>
                              <WeatherGlyph kind={d.icon} className="h-4 w-4" />
                              <span className="text-[11px] font-bold text-[#2A1A12]">
                                {d.tMax}° <span className="font-medium text-gray-400">{d.tMin}°</span>
                              </span>
                              <span className="text-[9px] text-sky-500">💧 {d.precipProb} %</span>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>

          {/* Точки с ульями */}
          <Card className="border-red-100 shadow-sm">
            <CardContent className="p-4">
              <h2 className="flex items-center gap-2 text-sm font-bold text-[#2A1A12]">
                🐝 Ульи на карте
                <span className="rounded-full bg-red-50 px-2 py-0.5 text-[11px] font-bold text-red-600 dark:bg-[#2C211C]">
                  {list.length}
                </span>
                <span className="ml-auto text-[10px] font-medium tabular-nums text-gray-400">
                  {summary.hives} ульев · датчиков: {summary.sensors}
                </span>
              </h2>

              {!points ? (
                <div className="mt-3 space-y-2">
                  {[0, 1, 2].map((i) => (
                    <div key={i} className="h-12 animate-pulse rounded-xl bg-red-100/50" />
                  ))}
                </div>
              ) : list.length === 0 ? (
                <p className="mt-3 text-xs text-gray-500">
                  {isBeekeeper
                    ? 'Ульи ещё не привязаны. Нажмите «Добавить улей» и введите код с корпуса датчика — улей сразу появится в точке, которую передаёт его GPS.'
                    : 'Ульи ещё не привязаны: точки на карте добавляет пасечник по коду датчика.'}
                </p>
              ) : (
                <ul className="mt-3 max-h-72 space-y-2 overflow-y-auto pr-1">
                  <AnimatePresence initial={false}>
                    {list.map((p, i) => (
                      <motion.li
                        key={p.id}
                        layout
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ ...ease, delay: Math.min(i * 0.04, 0.2) }}
                        className="rounded-xl border border-red-100 bg-white px-3 py-2.5 dark:bg-[#221814]"
                      >
                        <button onClick={() => flyTo(p)} className="min-w-0 flex-1 text-left" aria-label={`Показать ${p.name} на карте`}>
                          <p className="truncate text-sm font-bold text-[#2A1A12]">{p.name}</p>
                          <p className="mt-0.5 text-[11px] text-gray-400">
                            <span className="font-mono font-bold text-gray-500">{p.sensorCode ?? '—'}</span> ·{' '}
                            {p.lat.toFixed(3)}, {p.lon.toFixed(3)} · датчик{' '}
                            <span
                              className={cn(
                                'font-bold',
                                p.sensor.reason === 'active'
                                  ? 'text-emerald-600'
                                  : p.sensor.reason === 'off'
                                    ? 'text-amber-600'
                                    : 'text-gray-400',
                              )}
                            >
                              {SENSOR_LABEL[p.sensor.reason]}
                            </span>
                          </p>
                        </button>
                        {isBeekeeper && (
                          <div className="mt-2 flex items-center justify-between border-t border-red-50 pt-2">
                            {p.hasSensor ? (
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10px] font-semibold text-gray-400">датчик</span>
                                <Switch
                                  checked={p.sensorOn}
                                  onCheckedChange={(v) =>
                                    void patchSensor(p, { sensorOn: v }, v ? 'Датчик включён' : 'Датчик выключен')
                                  }
                                  aria-label="Датчик включён"
                                />
                              </div>
                            ) : (
                              <button
                                onClick={() => void patchSensor(p, { hasSensor: true }, 'Датчик установлен и включён')}
                                className="text-[10px] font-bold text-red-600 hover:underline"
                              >
                                установить датчик
                              </button>
                            )}
                            <button
                              onClick={() => void removePoint(p)}
                              aria-label="Удалить точку"
                              className="rounded-lg p-1.5 text-gray-300 transition-colors hover:bg-red-50 hover:text-red-500 dark:hover:bg-[#2C211C]"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Диалог привязки улья по коду датчика */}
      <Dialog open={dialogOpen} onOpenChange={(v) => { if (!busy) setDialogOpen(v) }}>
        <DialogContent className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-[#2A1A12]">Добавить улей</DialogTitle>
            <DialogDescription>
              Введите код с корпуса датчика — улей сразу встанет в точку, которую передаёт GPS
              датчика.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-3"
            onSubmit={(e) => {
              e.preventDefault()
              void place()
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="pt-code">Код датчика</Label>
              <Input
                id="pt-code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Например: SN-2518-0147"
                aria-label="Код датчика"
                className="font-mono uppercase"
                maxLength={20}
                autoFocus
              />
            </div>

            <AnimatePresence mode="wait">
              {found ? (
                <motion.div
                  key="found"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={ease}
                  className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-xs dark:bg-[#1C2A20]"
                >
                  <p className="flex items-center gap-1.5 font-bold text-emerald-700">
                    <CircleCheck className="h-4 w-4 shrink-0" /> Датчик найден — {found.model}
                  </p>
                  <p className="mt-1.5 font-semibold text-[#2A1A12]">
                    GPS датчика: {found.lat.toFixed(4)}, {found.lon.toFixed(4)}
                  </p>
                  <p className="mt-0.5 text-gray-500">{found.note}</p>
                </motion.div>
              ) : showNotFound ? (
                <motion.div
                  key="notfound"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={ease}
                  className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs dark:bg-[#2C2416]"
                >
                  <p className="flex items-center gap-1.5 font-bold text-amber-700">
                    <CircleAlert className="h-4 w-4 shrink-0" /> Датчик с таким кодом не найден
                  </p>
                  <p className="mt-1 text-gray-500">Проверьте код — он напечатан на корпусе датчика.</p>
                </motion.div>
              ) : (
                <motion.div
                  key="hint"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={ease}
                  className="text-[11px] leading-relaxed text-gray-400"
                >
                  {zones.map((zone) => (
                    <div key={zone} className="mt-1.5 first:mt-0">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-gray-400">{ZONE_LABEL[zone]}</p>
                      <div className="mt-1 flex flex-wrap gap-1">
                        {SENSOR_CATALOG.filter((s) => s.zone === zone).map((s) => (
                          <button
                            key={s.code}
                            type="button"
                            onClick={() => setCode(s.code)}
                            aria-label={`Подставить код ${s.code}`}
                            className="rounded-md bg-white px-1.5 py-0.5 font-mono text-[10px] font-bold text-gray-600 shadow-sm ring-1 ring-red-100 transition hover:bg-red-50 hover:text-red-700 dark:bg-[#221814] dark:ring-[#2C211C]"
                          >
                            {s.code}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            <div className="space-y-1.5">
              <Label htmlFor="pt-name">
                Название улья <span className="font-normal text-gray-400">(необязательно)</span>
              </Label>
              <Input
                id="pt-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Мой улей"
                aria-label="Название улья"
                maxLength={60}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Отмена
              </Button>
              <Button
                type="submit"
                disabled={!found || busy}
                className="gap-1 bg-gradient-to-r from-red-600 to-orange-500 font-bold"
              >
                <MapPinPlus className="h-4 w-4" /> Привязать улей
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
