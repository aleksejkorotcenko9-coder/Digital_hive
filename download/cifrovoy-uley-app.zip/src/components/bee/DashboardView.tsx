'use client'

/**
 * Экран «Мои пасеки» — дашборд в три колонки:
 *  — слева: погода на пасеке + прогноз на 10 дней (реальный метеосервис,
 *    без указания источника в интерфейсе);
 *  — в центре: состояние пасеки (шкала-индекс, плитки показателей,
 *    графики температуры/влажности/массы выбранного улья);
 *  — справа: предписания ИИ-агента и ближайшие события (напоминания + журнал).
 *
 * Схема пасеки и графики строятся из ОДНОГО набора точек, что на карте
 * (ApiaryPoint по кодам датчиков), показания «живые» (опрос каждые 5 с).
 * Погода берётся по фактическому центру пасеки — средним координат точек.
 */
import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  CalendarDays,
  ChevronDown,
  CloudSun,
  Droplets,
  MapPin,
  MessageSquareText,
  Scale,
  SprayCan,
  Split,
  Sun,
  Thermometer,
  TrendingUp,
  Truck,
  AlarmClock,
  ClipboardList,
} from 'lucide-react'
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { MetricLine, WeightBars, WeightChart, ClimateChart } from './charts'
import { WeatherPanel } from './WeatherPanel'
import { StatusGauge, apiaryGauge } from './StatusGauge'
import { UrgencyBadge } from './decor'
import { useAppState } from '@/lib/store'
import { cn } from '@/lib/utils'
import {
  bestHiveOf,
  fmtNum,
  fmtSigned,
  hiveStatus,
  type Hive,
  type MigrationSite,
  type WeatherDay,
} from '@/lib/hive-model'
import { findingsFor, makeContext, SCENARIO_META, type Scenario } from '@/lib/agent'
import { hiveWord, pointsCenter, pointsToHives } from '@/lib/hive-sync'
import { apiHiveToHive, periodCaption, siteDtoToSite, useRealData, weightDeltaSafe } from '@/lib/real-data'
import { DEFAULT_PLACE } from '@/lib/sensor-catalog'
import { weatherResponseToDays } from '@/lib/weather-days'
import { whenLabelShort } from './reminders-utils'
import type { EventDto, MapPointDto, WeatherResponse } from '@/lib/api-types'

const STATUS_STYLES = {
  risk: { dot: 'bg-red-500', chip: 'bg-red-50 text-red-700 border-red-200' },
  watch: { dot: 'bg-amber-500', chip: 'bg-amber-50 text-amber-700 border-amber-200' },
  ok: { dot: 'bg-emerald-500', chip: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
} as const

function scenarioIcon(scenario: Scenario, className: string) {
  const cls = cn('h-4 w-4', className)
  switch (scenario) {
    case 'swarm':
      return <Split className={cls} />
    case 'pesticide':
      return <SprayCan className={cls} />
    case 'weather':
      return <CloudSun className={cls} />
    case 'migration':
      return <Truck className={cls} />
    default:
      return <Activity className={cls} />
  }
}

const URGENCY_LABEL = {
  'act-now': 'Действовать сейчас',
  today: 'Сегодня',
  'this-week': 'В течение недели',
  ok: 'Наблюдать',
} as const

/* ------------------------------------------------------------------ */
/* Контейнер дашборда                                                  */
/* ------------------------------------------------------------------ */

export function DashboardView() {
  const setView = useAppState((s) => s.setView)
  const hiveId = useAppState((s) => s.hiveId)
  const setHive = useAppState((s) => s.setHive)
  const { status, data, reload } = useRealData()

  // Синхронизация с картой: ульи дашборда = точки на карте, показания — с
  // датчиков. Опрос каждые 5 секунд — числа «живут» вместе с картой.
  const [points, setPoints] = useState<MapPointDto[] | null>(null)
  const [weather, setWeather] = useState<WeatherResponse | null>(null)
  useEffect(() => {
    let alive = true
    const load = async () => {
      try {
        const res = await fetch('/api/map-points', { cache: 'no-store' })
        if (!res.ok) return
        const j = (await res.json()) as { points: MapPointDto[] }
        if (alive) setPoints(j.points)
      } catch {
        // датчики подтянутся на следующем опросе
      }
    }
    void load()
    const timer = setInterval(() => void load(), 5000)
    return () => {
      alive = false
      clearInterval(timer)
    }
  }, [])

  // Погода по фактическому центру пасеки (среднее координат точек).
  // Эффект зависит от ЧИСЕЛ координат: пересчёт центра при каждом опросе
  // точек не вызывает перезапрос погоды, пока координаты не изменились.
  const center = useMemo<[number, number]>(
    () =>
      (points && points.length > 0 ? pointsCenter(points) : null) ?? DEFAULT_PLACE.center,
    [points],
  )
  const [wLat, wLon] = center
  useEffect(() => {
    let alive = true
    const sp = new URLSearchParams({ lat: String(wLat), lon: String(wLon), place: 'Моя пасека' })
    const load = async () => {
      try {
        const res = await fetch(`/api/weather?${sp.toString()}`, { cache: 'no-store' })
        if (!res.ok) return
        const j = (await res.json()) as WeatherResponse
        if (alive) setWeather(j)
      } catch {
        // агент честно скажет, если погоды нет
      }
    }
    void load()
    const timer = setInterval(() => void load(), 10 * 60 * 1000)
    return () => {
      alive = false
      clearInterval(timer)
    }
  }, [wLat, wLon])
  const agentWeather = useMemo(() => (weather ? weatherResponseToDays(weather) : null), [weather])

  const syncedHives = useMemo(() => (points ? pointsToHives(points) : null), [points])

  // выбранный улей всегда существует в синхронизированном наборе
  useEffect(() => {
    if (syncedHives && syncedHives.length > 0 && !syncedHives.some((h) => h.id === hiveId)) {
      setHive(syncedHives[0].id)
    }
  }, [syncedHives, hiveId, setHive])

  if (status === 'idle' || status === 'loading') {
    return <DashboardSkeleton />
  }
  if (status === 'error') {
    return (
      <Card className="mx-auto max-w-lg border-red-100">
        <CardContent className="p-6 text-center">
          <AlertTriangle className="mx-auto h-8 w-8 text-red-400" />
          <h2 className="mt-2 font-bold text-gray-900">Не удалось загрузить данные</h2>
          <p className="mt-1 text-sm text-gray-500">
            Проверьте, что база данных доступна, и попробуйте ещё раз.
          </p>
          <Button onClick={reload} className="mt-4 bg-red-600 hover:bg-red-700">
            Повторить загрузку
          </Button>
        </CardContent>
      </Card>
    )
  }
  // Схема и диаграммы — ТО ЖЕ точки, что на карте пасеки: один набор ульев
  // для карты, вкладки «Датчики» и дашборда. Из базы — журнал и площадки кочёвки.
  if (!points || !data || syncedHives === null) return <DashboardSkeleton />
  if (syncedHives.length === 0) {
    return <EmptyMapState onOpenMap={() => setView('map')} />
  }
  return (
    <DashboardContent
      hives={syncedHives}
      sites={data.sites.map(siteDtoToSite)}
      weather={agentWeather?.days ?? null}
      events={data.events}
      center={center}
    />
  )
}

function DashboardSkeleton() {
  return (
    <div className="grid gap-4 xl:grid-cols-[320px_minmax(0,1fr)_340px]">
      <div className="h-96 animate-pulse rounded-2xl bg-red-50/70" />
      <div className="h-96 animate-pulse rounded-2xl bg-red-50/50" />
      <div className="h-96 animate-pulse rounded-2xl bg-red-50/40" />
      <p className="col-span-full text-center text-sm text-gray-400">Загружаем показания датчиков…</p>
    </div>
  )
}

/** Карта пуста — диаграммам не с чего брать данные: честный экран-подсказка. */
function EmptyMapState({ onOpenMap }: { onOpenMap: () => void }) {
  return (
    <Card className="mx-auto max-w-lg border-dashed border-red-300 bg-red-50/40">
      <CardContent className="p-8 text-center">
        <MapPin className="mx-auto h-8 w-8 text-red-300" />
        <h2 className="mt-3 text-lg font-extrabold text-[#2A1A12]">
          Ульи на карте ещё не привязаны
        </h2>
        <p className="mx-auto mt-1.5 max-w-sm text-sm leading-relaxed text-gray-500">
          Диаграммы дашборда берут данные с датчиков ульев на карте. Откройте карту и введите код с корпуса датчика — улей привяжется в точке GPS, и его показания появятся здесь.
        </p>
        <Button
          onClick={onOpenMap}
          className="mt-5 bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-700 hover:to-orange-600"
        >
          Перейти на карту пасеки
        </Button>
      </CardContent>
    </Card>
  )
}

/* ------------------------------------------------------------------ */
/* Содержимое дашборда                                                 */
/* ------------------------------------------------------------------ */

interface ContentProps {
  hives: Hive[]
  sites: MigrationSite[]
  weather: WeatherDay[] | null
  events: EventDto[]
  /** Центр пасеки (среднее координат точек на карте) — для панели погоды. */
  center: [number, number]
}

function DashboardContent({ hives, sites, weather, events, center }: ContentProps) {
  const hiveId = useAppState((s) => s.hiveId)
  const setHive = useAppState((s) => s.setHive)
  const setView = useAppState((s) => s.setView)
  const ask = useAppState((s) => s.ask)
  const reminders = useAppState((s) => s.reminders)
  const [openFinding, setOpenFinding] = useState<string | null>(null)

  const hive = hives.find((x) => x.id === hiveId) ?? hives[0]
  const status = hiveStatus(hive, hives)
  const ctx = makeContext(hives, { weather, sites, apiaryName: 'Моя пасека' })
  const findings = findingsFor(hive.id, ctx)

  const riskyHive = hives.find((x) => hiveStatus(x, hives).level === 'risk')
  const watchHive = hives.find((x) => hiveStatus(x, hives).level === 'watch' && x.id !== riskyHive?.id)

  const lastPoint = hive.series[hive.series.length - 1]
  const d2 = weightDeltaSafe(hive, 2)
  const lastWeight = lastPoint?.weightKg ?? null
  const lastTemp = lastPoint?.tempInC ?? null
  const lastHum = lastPoint?.humidityPct ?? null
  const period = periodCaption(hive)

  // показатели пасеки целиком
  const withTelemetry = hives.filter((h) => h.series.length > 0 && h.series[h.series.length - 1].weightKg !== null)
  const gauge = apiaryGauge(hives.map((h) => hiveStatus(h, hives).level), hives.length)
  const leader = bestHiveOf(hives)

  const upcomingReminders = reminders
    .filter((r) => !r.done)
    .sort((a, b) => a.remindAt.localeCompare(b.remindAt))
    .slice(0, 4)

  const todayLabel = format(new Date(), 'EEEE, d MMMM yyyy', { locale: ru })

  return (
    <div className="space-y-5">
      {/* Верхний баннер срочности */}
      {riskyHive ? (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#D93E00] to-[#FF5A1F] p-4 text-white shadow-lg shadow-red-100 md:p-5">
          <Split className="absolute -right-3 -top-3 h-28 w-28 rotate-12 text-white/15" />
          <div className="relative flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-6 w-6 shrink-0" />
              <div>
                <p className="text-sm font-bold uppercase tracking-wide text-white/90">
                  Сигнал данных · возможное роение
                </p>
                <p className="mt-1 text-sm leading-snug md:text-base">
                  Улей №{riskyHive.id}: вес снизился на {fmtSigned(weightDeltaSafe(riskyHive, 2) ?? 0)} кг за 2 дня при
                  тёплой погоде — похоже на подготовку семьи к делению.
                </p>
              </div>
            </div>
            <Button
              className="w-fit shrink-0 bg-white font-semibold text-orange-700 hover:bg-orange-50"
              onClick={() => ask(`Что происходит с ульем №${riskyHive.id}?`)}
            >
              Что делать? <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : watchHive ? (
        <div className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-amber-800">
          <AlertTriangle className="h-5 w-5 shrink-0 text-amber-500" />
          <p className="text-sm">
            Улей №{watchHive.id}: {hiveStatus(watchHive, hives).label.toLowerCase()} — проверьте семью в ближайшие дни.
          </p>
        </div>
      ) : (
        <div className="flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-emerald-800">
          <Sun className="h-5 w-5 shrink-0 text-emerald-500" />
          <p className="text-sm">
            По данным датчиков тревожных сигналов нет — все семьи с телеметрией работают штатно.
          </p>
        </div>
      )}

      {/* Заголовок пасеки */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-[#2A1A12] md:text-3xl">
            Моя пасека · данные с датчиков
          </h1>
          <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5 text-red-500" />
              {`${hives.length} ${hiveWord(hives.length)} на карте · данные с датчиков`}
            </span>
            <span className="flex items-center gap-1">
              <CalendarDays className="h-3.5 w-3.5 text-red-500" /> {todayLabel}
            </span>
          </p>
        </div>
      </div>

      {/* Три колонки, как на референсе */}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[320px_minmax(0,1fr)_340px]">
        {/* Колонка 1: погода пасеки (по координатам её точек на карте) */}
        <div className="order-2 xl:order-1">
          <WeatherPanel coords={center} place="Моя пасека" />
        </div>

        {/* Колонка 2: состояние пасеки */}
        <div className="order-1 space-y-4 xl:order-2">
          <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm md:p-5 dark:bg-[#221814]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="flex items-center gap-1.5 text-sm font-bold text-[#2A1A12]">
                <TrendingUp className="h-4 w-4 text-red-500" /> Состояние пасеки
              </h2>
              <span className="text-[11px] text-gray-400">
                {withTelemetry.length} из {hives.length} семей с телеметрией
              </span>
            </div>

            <StatusGauge info={gauge} className="mx-auto mt-2" />

            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
              <Tile icon={<Scale className="h-3.5 w-3.5" />} label="Всего ульев" value={String(hives.length)} />
              <Tile
                icon={<Activity className="h-3.5 w-3.5" />}
                label="С датчиками"
                value={String(withTelemetry.length)}
              />
              <Tile
                icon={<Thermometer className="h-3.5 w-3.5" />}
                label="Темп. внутри"
                value={lastTemp !== null ? `${fmtNum(lastTemp)} °C` : '—'}
                hint={`улей №${hive.id}`}
              />
              <Tile
                icon={<Droplets className="h-3.5 w-3.5" />}
                label="Влажность"
                value={lastHum !== null ? `${fmtNum(lastHum, 0)} %` : '—'}
                hint={`улей №${hive.id}`}
              />
              <Tile
                icon={<Scale className="h-3.5 w-3.5" />}
                label="Масса улья"
                value={lastWeight !== null ? `${fmtNum(lastWeight)} кг` : '—'}
                hint={`улей №${hive.id}`}
              />
              <Tile
                icon={<TrendingUp className="h-3.5 w-3.5" />}
                label={`Привес ${period}`}
                value={`${fmtSigned(weightDeltaSafe(leader, 30) ?? weightTotal(leader))} кг`}
                hint={`лидер — №${leader.id}`}
              />
            </div>

            {/* Выбор улья */}
            <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label="Выбор улья">
              {hives.map((h) => {
                const st = hiveStatus(h, hives)
                const active = h.id === hive.id
                return (
                  <button
                    key={h.id}
                    onClick={() => setHive(h.id)}
                    aria-pressed={active}
                    className={cn(
                      'flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold transition-all',
                      active
                        ? 'border-red-400 bg-red-50 text-red-700 shadow-sm'
                        : 'border-red-100 text-gray-600 hover:border-red-200 hover:bg-red-50/60',
                    )}
                  >
                    <span className={cn('h-2 w-2 rounded-full', STATUS_STYLES[st.level].dot)} />
                    {h.label.replace('Улей №', '№')}
                  </button>
                )
              })}
            </div>
          </section>

          {/* Графики выбранного улья */}
          <div className="grid gap-4 md:grid-cols-2">
            <MiniChartCard
              title="Температура"
              value={lastTemp !== null ? `${fmtNum(lastTemp)} °C` : '—'}
              note="норма семьи ≈ 34,5 °C"
            >
              <MetricLine hive={hive} metric="tempInC" />
            </MiniChartCard>
            <MiniChartCard
              title="Влажность"
              value={lastHum !== null ? `${fmtNum(lastHum, 0)} %` : '—'}
              note={hive.humiditySensorOk ? 'норма 50–66 %' : 'датчик не отвечает'}
            >
              <MetricLine hive={hive} metric="humidityPct" />
            </MiniChartCard>
            <MiniChartCard
              title="Масса улья"
              value={lastWeight !== null ? `${fmtNum(lastWeight)} кг` : '—'}
              note={d2 !== null ? `${fmtSigned(d2)} кг за 2 дня` : 'нет данных о весе'}
              className="md:col-span-2"
            >
              <WeightBars hive={hive} />
            </MiniChartCard>
          </div>

          {/* Развёрнутые графики (как раньше) */}
          <details className="group rounded-2xl border border-red-100 bg-white shadow-sm dark:bg-[#221814]">
            <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3 text-sm font-bold text-[#2A1A12] md:px-5">
              Подробные графики улья №{hive.id}
              <ChevronDown className="h-4 w-4 text-gray-400 transition-transform group-open:rotate-180" />
            </summary>
            <div className="grid gap-4 border-t border-red-50 px-4 pb-5 pt-4 md:grid-cols-2 md:px-5">
              <div>
                <WeightChart hive={hive} risky={status.level === 'risk'} />
              </div>
              <div>
                <ClimateChart hive={hive} />
              </div>
            </div>
          </details>
        </div>

        {/* Колонка 3: предписания и события */}
        <div className="order-3 space-y-4">
          {/* Предписания ИИ-агента */}
          <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm md:p-5 dark:bg-[#221814]">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-1.5 text-sm font-bold text-[#2A1A12]">
                <MessageSquareText className="h-4 w-4 text-red-500" /> Предписания агента
              </h2>
              <span className="text-[11px] text-gray-400">контекст: {hive.label.replace('Улей ', '№')}</span>
            </div>
            <ol className="mt-3 space-y-2">
              {findings.map((f, i) => {
                const open = openFinding === f.id
                return (
                  <li key={f.id} className={cn('rounded-xl border', open ? 'border-red-200 bg-red-50/40' : 'border-red-50', f.urgency === 'act-now' && 'border-red-200')}>
                    <button
                      onClick={() => setOpenFinding(open ? null : f.id)}
                      aria-expanded={open}
                      className="flex w-full items-start gap-2.5 px-3 py-2.5 text-left"
                    >
                      <span className={cn(
                        'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-extrabold',
                        f.urgency === 'act-now' ? 'bg-red-600 text-white' : 'bg-red-100 text-red-700',
                      )}>
                        {i + 1}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[13px] font-bold leading-snug text-gray-800">{f.title}</span>
                        {!open && (
                          <span className="mt-0.5 block text-[11px] text-gray-400">
                            {SCENARIO_META[f.scenario].label} · {f.urgencyNote ?? URGENCY_LABEL[f.urgency]}
                          </span>
                        )}
                      </span>
                      <ChevronDown className={cn('mt-1 h-4 w-4 shrink-0 text-gray-400 transition-transform', open && 'rotate-180')} />
                    </button>
                    {open && (
                      <div className="border-t border-red-100 px-3 pb-3 pt-2">
                        <p className="text-[13px] leading-relaxed text-gray-600">{f.text}</p>
                        {f.basis.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-1">
                            {f.basis.map((b) => (
                              <span key={b} className="rounded-full bg-red-50 px-2 py-0.5 text-[11px] text-red-700">
                                {b}
                              </span>
                            ))}
                          </div>
                        )}
                        <div className="mt-2.5 flex items-center justify-between gap-2">
                          <UrgencyBadge urgency={f.urgency} note={f.urgencyNote ?? URGENCY_LABEL[f.urgency]} />
                          <Button
                            size="sm"
                            variant="ghost"
                            className="gap-1 text-red-600 hover:bg-red-50 hover:text-red-700"
                            onClick={() => ask(f.prefill)}
                          >
                            Обсудить <ArrowRight className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </li>
                )
              })}
            </ol>
            <p className="mt-3 text-[11px] leading-relaxed text-gray-400">
              Агент показывает вероятность и уровень риска — решение принимает пчеловод.
            </p>
          </section>

          {/* Ближайшие события: напоминания + журнал */}
          <section className="rounded-2xl border border-red-100 bg-white p-4 shadow-sm md:p-5 dark:bg-[#221814]">
            <div className="flex items-center justify-between">
              <h2 className="flex items-center gap-1.5 text-sm font-bold text-[#2A1A12]">
                <AlarmClock className="h-4 w-4 text-red-500" /> Ближайшие события
              </h2>
              <button onClick={() => setView('reminders')} className="text-[11px] font-bold text-red-600 hover:text-red-700">
                все напоминания →
              </button>
            </div>

            {upcomingReminders.length === 0 ? (
              <p className="mt-2 text-sm text-gray-400">
                Напоминаний нет — поставьте первое в разделе «Напоминания».
              </p>
            ) : (
              <ul className="mt-2 space-y-1.5">
                {upcomingReminders.map((r) => (
                  <li key={r.id} className="flex items-start gap-2.5 rounded-xl bg-red-50/50 px-3 py-2 dark:bg-[#2C211C]">
                    <AlarmClock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px] font-semibold leading-snug text-gray-800">{r.text}</p>
                      <p className="text-[11px] text-gray-400">{whenLabelShort(r.remindAt)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}

            <h3 className="mt-4 flex items-center gap-1.5 text-xs font-bold text-gray-500">
              <ClipboardList className="h-3.5 w-3.5" /> Журнал пасеки
            </h3>
            {events.length === 0 ? (
              <p className="mt-1.5 text-sm text-gray-400">Журнал пуст — добавьте запись в разделе «Данные».</p>
            ) : (
              <ul className="mt-1.5 space-y-1.5">
                {events.slice(0, 3).map((e) => (
                  <li key={e.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-red-50 px-3 py-2 text-[13px]">
                    <span className="rounded-full bg-red-50 px-2 py-0.5 text-[11px] font-bold text-red-700">{e.type}</span>
                    <span className="font-semibold text-gray-700">{e.hiveName}</span>
                    <span className="text-gray-500">{e.note}</span>
                    <span className="ml-auto text-[11px] text-gray-400">
                      {format(new Date(e.ts), 'd MMM, HH:mm', { locale: ru })}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* Вспомогательные элементы                                            */
/* ------------------------------------------------------------------ */

function Tile({ icon, label, value, hint }: { icon: React.ReactNode; label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-red-50 bg-red-50/40 px-3 py-2.5 dark:bg-[#2C211C]">
      <p className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-500">
        <span className="text-red-400">{icon}</span>
        {label}
      </p>
      <p className="mt-1 text-lg font-extrabold leading-none text-gray-900">{value}</p>
      {hint && <p className="mt-1 text-[10px] text-gray-400">{hint}</p>}
    </div>
  )
}

function MiniChartCard({
  title,
  value,
  note,
  className,
  children,
}: {
  title: string
  value: string
  note?: string
  className?: string
  children: React.ReactNode
}) {
  return (
    <div className={cn('rounded-2xl border border-red-100 bg-white p-4 shadow-sm dark:bg-[#221814]', className)}>
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-bold text-[#2A1A12]">{title}</h3>
        <span className="text-base font-extrabold text-red-600">{value}</span>
      </div>
      <div className="mt-1 h-[150px]">{children}</div>
      {note && <p className="mt-1 text-[11px] text-gray-400">{note}</p>}
    </div>
  )
}

/** Итоговое изменение веса за период наблюдений (для KPI «привес»). */
function weightTotal(h: Hive): number {
  const w = h.series[h.series.length - 1]?.weightKg ?? null
  const first = h.series[0]?.weightKg ?? null
  if (w === null || first === null) return 0
  return Math.round((w - first) * 10) / 10
}
