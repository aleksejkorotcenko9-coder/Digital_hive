'use client'

/**
 * Каркас приложения в стиле референса: белое боковое меню с логотипом,
 * красной кнопкой «+ Новый улей» и профилем внизу; на мобильных — верхняя
 * панель и нижняя навигация. Здесь же смонтированы: диалог профиля,
 * диалог добавления улья, опрос напоминаний (тосты + системные уведомления).
 */
import { useEffect, useMemo, useState } from 'react'
import {
  AlarmClock,
  BellRing,
  BookOpen,
  Database,
  History,
  LayoutDashboard,
  Map,
  MapPinned,
  MessageSquareText,
  Plus,
  RadioTower,
  RefreshCcw,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { useToast } from '@/hooks/use-toast'
import { HoneycombDecor, HexLogo } from './decor'
import { ProfileDialog, ProfileTrigger, UserAvatar } from './ProfileDialog'
import { RemindersBell } from './RemindersBell'
import { useAppState, type View } from '@/lib/store'
import { hiveStatus } from '@/lib/hive-model'
import { hiveWord, pointsToHives } from '@/lib/hive-sync'
import { userLabel } from '@/lib/api-types'
import type { MapPointDto } from '@/lib/api-types'
import { useReminders } from '@/lib/use-reminders'
import { cn } from '@/lib/utils'

const NAV: Array<{ id: View; label: string; icon: typeof LayoutDashboard; short: string }> = [
  { id: 'dashboard', label: 'Мои пасеки', short: 'Пасека', icon: LayoutDashboard },
  { id: 'agent', label: 'ИИ-агент', short: 'Агент', icon: MessageSquareText },
  { id: 'map', label: 'Карта пасеки', short: 'Карта', icon: Map },
  { id: 'sensors', label: 'Датчики ульев', short: 'Датчики', icon: RadioTower },
  { id: 'history', label: 'История событий', short: 'История', icon: History },
  { id: 'migration', label: 'Кочёвка', short: 'Кочёвка', icon: MapPinned },
  { id: 'data', label: 'Данные', short: 'Данные', icon: Database },
  { id: 'reminders', label: 'Напоминания', short: 'Напомин.', icon: AlarmClock },
  { id: 'about', label: 'Справка', short: 'Справка', icon: BookOpen },
]

/** Счётчик активных напоминаний: просроченные + ближайшие 7 дней. */
function useReminderBadge(): number {
  const reminders = useAppState((s) => s.reminders)
  const user = useAppState((s) => s.user)
  return useMemo(() => {
    if (!user) return 0
    const now = Date.now()
    return reminders.filter(
      (r) => !r.done && new Date(r.remindAt).getTime() <= now + 7 * 86400000,
    ).length
  }, [reminders, user])
}

function NewHiveDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [number, setNumber] = useState('')
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState(false)
  const { toast } = useToast()

  const create = async () => {
    const num = Number(number)
    if (!Number.isInteger(num) || num < 1 || num > 999) {
      toast({ title: 'Проверьте номер', description: 'Номер улья — целое число от 1 до 999', variant: 'destructive' })
      return
    }
    setBusy(true)
    try {
      const res = await fetch('/api/hives', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ number: num, familyNote: note.trim() }),
      })
      const j = (await res.json().catch(() => ({}))) as { error?: string }
      if (!res.ok) {
        toast({ title: 'Не получилось', description: j.error ?? 'Ошибка сервера', variant: 'destructive' })
        return
      }
      toast({ title: `Улей №${num} добавлен`, description: 'Загрузите телеметрию в разделе «Данные».' })
      onOpenChange(false)
      setNumber('')
      setNote('')
      const store = useAppState.getState()
      void store.loadReal()
      store.setView('data')
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-[#2A1A12]">Новый улей</DialogTitle>
          <DialogDescription>Добавим улей в справочник базы данных пасеки.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <Input
            type="number"
            min={1}
            max={999}
            value={number}
            onChange={(e) => setNumber(e.target.value)}
            placeholder="Номер улья, например 5"
            aria-label="Номер улья"
          />
          <Input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Пометка о семье (необязательно)"
            aria-label="Пометка о семье"
            maxLength={200}
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button onClick={() => void create()} disabled={busy || !number} className="gap-1 bg-red-600 hover:bg-red-700">
            <Plus className="h-4 w-4" /> Добавить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const view = useAppState((s) => s.view)
  const setView = useAppState((s) => s.setView)
  const user = useAppState((s) => s.user)
  const setProfileOpen = useAppState((s) => s.setProfileOpen)

  // опрос напоминаний + оповещения по наступлении срока
  useReminders()
  const reminderBadge = useReminderBadge()
  const [hiveDialogOpen, setHiveDialogOpen] = useState(false)

  // Синхронизация с картой: число ульев и состояние датчиков — из /api/map-points
  // (те же точки, что на карте, вкладке «Датчики» и в контексте агента).
  const [mapPoints, setMapPoints] = useState<MapPointDto[] | null>(null)
  useEffect(() => {
    let alive = true
    const load = async () => {
      try {
        const res = await fetch('/api/map-points', { cache: 'no-store' })
        if (!res.ok) return
        const j = (await res.json()) as { points: MapPointDto[] }
        if (alive) setMapPoints(j.points)
      } catch {
        // повтор на следующем такте
      }
    }
    void load()
    const timer = setInterval(() => void load(), 10000)
    return () => {
      alive = false
      clearInterval(timer)
    }
  }, [])

  // число срочных сигналов: улья с риском роения по точкам карты
  const urgentCount = useMemo(() => {
    if (!mapPoints) return 0
    const hives = pointsToHives(mapPoints)
    return hives.filter((h) => hiveStatus(h, hives).level === 'risk').length
  }, [mapPoints])

  // системная тема: если выбрана «системная», слушаем смену темы ОС
  const theme = useAppState((s) => s.theme)
  useEffect(() => {
    if (theme !== 'system') return
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const onChange = () => void import('@/lib/store').then((m) => m.applyTheme('system'))
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [theme])

  const role = user?.role === 'HELPER' ? 'Помощник' : 'Пасечник'

  const urgentChip =
    urgentCount > 0 ? (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 dark:bg-[#331B16]">
        <BellRing className="h-3.5 w-3.5" /> срочных сигналов: {urgentCount}
      </span>
    ) : (
      <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:bg-[#16302A]">
        тревожных сигналов нет
      </span>
    )

  const navButton = (item: (typeof NAV)[number], compact = false) => {
    const Icon = item.icon
    const active = view === item.id
    return (
      <button
        key={item.id}
        onClick={() => setView(item.id)}
        aria-current={active ? 'page' : undefined}
        className={cn(
          compact
            ? 'flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-xl px-0.5 py-1.5 text-[10px] font-semibold transition-colors'
            : 'flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-colors',
          active
            ? compact
              ? 'text-red-600'
              : 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-md shadow-red-100'
            : compact
              ? 'text-gray-400 hover:text-gray-600'
              : 'text-gray-600 hover:bg-red-50 hover:text-red-700 dark:hover:bg-[#2C211C]',
        )}
      >
        <span className={cn(compact ? 'flex h-8 w-8 items-center justify-center rounded-lg' : 'relative', active && compact ? 'bg-red-50 dark:bg-[#2C211C]' : '')}>
          <Icon className={cn(compact ? 'h-4 w-4' : 'h-4.5 w-4.5')} />
          {item.id === 'reminders' && reminderBadge > 0 && (
            <span
              className={cn(
                'absolute -right-1.5 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[9px] font-extrabold',
                active ? 'bg-white text-red-600 ring-1 ring-red-200' : 'bg-red-600 text-white',
              )}
            >
              {reminderBadge > 9 ? '9+' : reminderBadge}
            </span>
          )}
        </span>
        {compact ? item.short : item.label}
      </button>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#FAF6F3]">
      {/* Сайдбар (десктоп) */}
      <aside className="sticky top-0 hidden h-screen w-[248px] shrink-0 flex-col bg-white px-3.5 py-4 lg:flex dark:bg-[#221814]">
        <button onClick={() => setView('dashboard')} className="mb-4 flex items-center gap-2.5 px-1.5 text-left" aria-label="Цифровой улей — на главную">
          <HexLogo className="h-9 w-9" />
          <span className="text-base font-extrabold leading-tight tracking-tight text-[#2A1A12]">
            Цифровой улей
          </span>
        </button>

        <nav className="space-y-1" aria-label="Основная навигация">
          {NAV.map((item) =>
            item.id === 'reminders' ? (
              <div key={item.id} className="flex items-center gap-1.5">
                <div className="min-w-0 flex-1">{navButton(item)}</div>
                <RemindersBell />
              </div>
            ) : (
              navButton(item)
            ),
          )}
        </nav>

        {user?.role === 'BEEKEEPER' && (
          <Button
            onClick={() => setHiveDialogOpen(true)}
            className="mt-4 w-full gap-1.5 bg-gradient-to-r from-red-600 to-orange-500 font-bold shadow-md shadow-red-100 hover:from-red-700 hover:to-orange-600"
          >
            <Plus className="h-4 w-4" /> Новый улей
          </Button>
        )}

        <div className="mt-4 px-1">{urgentChip}</div>

        <div className="mt-3 rounded-2xl border border-red-100 bg-red-50/40 p-3 dark:bg-[#2C211C]">
          <p className="text-xs font-bold text-[#2A1A12]">Моя пасека</p>
          <p className="mt-1 text-[11px] leading-relaxed text-gray-400">
            {mapPoints && mapPoints.length > 0 ? (
              <>
                {mapPoints.length} {hiveWord(mapPoints.length)} · позиции — GPS датчиков
              </>
            ) : (
              <>Ульи ещё не привязаны — добавьте первый на карте</>
            )}
          </p>
          {mapPoints && mapPoints.length > 0 && (
            <div className="mt-2.5 flex items-center justify-between rounded-lg bg-white px-2.5 py-2 dark:bg-[#221814]">
              <span className="text-[11px] font-semibold text-red-700">
                {mapPoints.filter((p) => p.hasSensor && p.sensorOn).length} из {mapPoints.length} датчиков активны
              </span>
              <span className="flex gap-1">
                {mapPoints.map((p) => (
                  <span
                    key={p.id}
                    title={p.name}
                    className={cn(
                      'h-2 w-2 rounded-full',
                      p.hasSensor && p.sensorOn
                        ? 'bg-emerald-500'
                        : p.hasSensor
                          ? 'bg-amber-400'
                          : 'bg-gray-300',
                    )}
                  />
                ))}
              </span>
            </div>
          )}
        </div>

        <HoneycombDecor className="mt-auto hidden h-20 w-24 opacity-70" />

        {user && (
          <div className="mt-3 border-t border-red-50 pt-2">
            <ProfileTrigger user={user} onClick={() => setProfileOpen(true)} />
          </div>
        )}
      </aside>

      {/* Основная колонка */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Верхняя панель (мобайл) */}
        <header className="sticky top-0 z-40 border-b border-red-100 bg-white/90 backdrop-blur lg:hidden dark:bg-[#221814]/90">
          <div className="flex h-14 items-center gap-2 px-3">
            <button onClick={() => setView('dashboard')} className="flex items-center gap-2" aria-label="Цифровой улей — на главную">
              <HexLogo className="h-8 w-8" />
              <span className="text-sm font-extrabold tracking-tight text-[#2A1A12]">Цифровой улей</span>
            </button>
            <div className="ml-auto flex items-center gap-2">
              <RemindersBell />
              {user && (
                <button onClick={() => setProfileOpen(true)} aria-label="Профиль">
                  <UserAvatar user={user} className="h-9 w-9 text-sm" />
                </button>
              )}
            </div>
          </div>
        </header>

        <main className="min-w-0 flex-1 px-4 pb-24 pt-5 md:px-6 md:pt-6 lg:pb-8">{children}</main>

        {/* Футер */}
        <footer className="mt-auto border-t border-red-100 bg-white pb-[calc(env(safe-area-inset-bottom)+4.5rem)] px-4 py-4 text-xs text-gray-400 lg:pb-0 dark:bg-[#221814]">
          <div className="flex max-w-[1440px] flex-col gap-1 md:flex-row md:items-center md:justify-between">
            <p>Цифровой улей — умный помощник пчеловода: телеметрия, погода, кочёвка</p>
            <p className="font-medium text-gray-500">
              Агент показывает вероятность и уровень риска — решение принимает пчеловод
            </p>
          </div>
        </footer>
      </div>

      {/* Нижняя навигация (мобайл) */}
      <nav
        aria-label="Навигация"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-red-100 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden dark:bg-[#221814]/95"
      >
        <div className="mx-auto grid max-w-md grid-cols-9 px-0.5 py-1.5">
          {NAV.map((item) => navButton(item, true))}
        </div>
      </nav>

      {/* Диалоги */}
      <ProfileDialog />
      {user?.role === 'BEEKEEPER' && (
        <NewHiveDialog open={hiveDialogOpen} onOpenChange={setHiveDialogOpen} />
      )}
    </div>
  )
}
