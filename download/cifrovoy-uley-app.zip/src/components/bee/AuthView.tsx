'use client'

/**
 * Экран входа и регистрации с подтверждением email.
 *
 * Регистрация: имя + email + пароль + роль (Пасечник — полный доступ,
 * Помощник — только просмотр). Аккаунт создаётся БЕЗ сессии: на почту
 * уходит 6-значный код, который пользователь вводит на экране
 * «Проверьте почту». После подтверждения — обычный вход.
 *
 * Вход в аккаунт с неподтверждённым email (403 needsVerification) тоже
 * открывает экран ввода кода.
 */
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { HexLogo, HoneycombDecor } from './decor'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { useAppState } from '@/lib/store'
import type { SafeUser } from '@/lib/api-types'
import { cn } from '@/lib/utils'
import {
  Eye,
  EyeOff,
  Hexagon,
  LogIn,
  UserPlus,
  UserCog,
  MailCheck,
  MailWarning,
  ShieldCheck,
  RefreshCw,
  ArrowLeft,
} from 'lucide-react'

export type AuthNotice = { kind: 'success' | 'error'; text: string }

type Tab = 'login' | 'register'
type PendingEmail = { email: string; kind: 'registered' | 'unverified' }

const CODE_RE = /^\d{6}$/
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const RESEND_COOLDOWN_SEC = 60

export function AuthView({ notice: initialNotice, standalone }: { notice?: AuthNotice | null; standalone?: boolean }) {
  const router = useRouter()
  const [tab, setTab] = useState<Tab>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<'BEEKEEPER' | 'HELPER'>('BEEKEEPER')
  const [showPw, setShowPw] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<AuthNotice | null>(initialNotice ?? null)

  // Состояния экрана «Проверьте почту»
  const [pendingEmail, setPendingEmail] = useState<PendingEmail | null>(null)
  const [pendingWarning, setPendingWarning] = useState<string | null>(null)
  const [codeInput, setCodeInput] = useState('')
  const [verifying, setVerifying] = useState(false)
  const [resending, setResending] = useState(false)
  const [resendIn, setResendIn] = useState(0)
  const [codeMsg, setCodeMsg] = useState<AuthNotice | null>(null)
  const [verifiedOk, setVerifiedOk] = useState(false)

  // Обратный отсчёт до повторной отправки кода
  useEffect(() => {
    if (resendIn <= 0) return
    const t = setInterval(() => setResendIn((v) => (v > 0 ? v - 1 : 0)), 1000)
    return () => clearInterval(t)
  }, [resendIn])

  /** Открывает экран ввода кода (после регистрации или 403 при входе). */
  const showCodeScreen = (p: PendingEmail, warning?: string | null) => {
    setPendingEmail(p)
    setPendingWarning(warning ?? null)
    setCodeInput('')
    setCodeMsg(null)
    setVerifiedOk(false)
    setResendIn(RESEND_COOLDOWN_SEC) // пауза, чтобы письмо успело дойти
    setError(null)
  }

  const submit = async () => {
    if (busy) return
    if (tab === 'register' && !EMAIL_RE.test(email.trim())) {
      setError('Введите корректный email — на него придёт код подтверждения')
      return
    }
    setBusy(true)
    setError(null)
    try {
      const url = tab === 'login' ? '/api/auth/login' : '/api/auth/register'
      const payload = tab === 'login' ? { name, password } : { name, email, password, role }
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const j = (await res.json()) as {
        user?: SafeUser
        error?: string
        message?: string
        warning?: string
        needsVerification?: boolean
        email?: string
      }

      // Вход в неподтверждённый аккаунт → сразу экран ввода кода
      if (res.status === 403 && j.needsVerification && j.email) {
        showCodeScreen({ email: j.email, kind: 'unverified' })
        return
      }

      if (tab === 'register' && res.ok) {
        // Регистрация прошла: сессии нет, ждём код из письма
        showCodeScreen({ email: email.trim().toLowerCase(), kind: 'registered' }, j.warning ?? null)
        return
      }

      if (!res.ok || !j.user) {
        setError(j.error ?? 'Не удалось войти')
        return
      }
      useAppState.getState().setUser(j.user)
      void useAppState.getState().loadReal()
      // На отдельной странице /login после входа возвращаемся в приложение
      if (standalone) router.replace('/')
    } catch {
      setError('Сервер недоступен — попробуйте ещё раз')
    } finally {
      setBusy(false)
    }
  }

  const submitCode = async () => {
    if (verifying || !pendingEmail) return
    const code = codeInput.replace(/\s+/g, '')
    if (!CODE_RE.test(code)) {
      setCodeMsg({ kind: 'error', text: 'Введите 6-значный код из письма' })
      return
    }
    setVerifying(true)
    setCodeMsg(null)
    try {
      const res = await fetch('/api/auth/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: pendingEmail.email, code }),
      })
      const j = (await res.json()) as { message?: string; error?: string }
      if (!res.ok) {
        setCodeMsg({ kind: 'error', text: j.error ?? 'Не удалось подтвердить код' })
        return
      }
      setVerifiedOk(true) // зелёный экран «Email подтверждён» + кнопка «Войти в систему»
    } catch {
      setCodeMsg({ kind: 'error', text: 'Сервер недоступен — попробуйте ещё раз' })
    } finally {
      setVerifying(false)
    }
  }

  const resendCode = async () => {
    if (resending || resendIn > 0 || !pendingEmail) return
    setResending(true)
    setCodeMsg(null)
    try {
      const res = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: pendingEmail.email }),
      })
      const j = (await res.json()) as { message?: string; warning?: string; error?: string }
      if (!res.ok) {
        setCodeMsg({ kind: 'error', text: j.error ?? 'Не удалось отправить код повторно' })
        return
      }
      setPendingWarning(j.warning ?? null)
      setCodeMsg({ kind: 'success', text: 'Новый код отправлен — проверьте почту' })
      setResendIn(RESEND_COOLDOWN_SEC)
    } catch {
      setCodeMsg({ kind: 'error', text: 'Сервер недоступен — попробуйте ещё раз' })
    } finally {
      setResending(false)
    }
  }

  /** Назад к форме входа (с экрана кода или после подтверждения). */
  const backToAuth = () => {
    setPendingEmail(null)
    setPendingWarning(null)
    setCodeInput('')
    setCodeMsg(null)
    setVerifiedOk(false)
    setTab('login')
    setError(null)
  }

  /* ---------------------------------------------------------------- */
  /* Экран «Проверьте почту» (код) и зелёный экран подтверждения       */
  /* ---------------------------------------------------------------- */
  if (pendingEmail) {
    return (
      <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-[#FAF6F3] via-[#F2EDFA] to-[#EDE4FB] px-4 py-10">
        <HoneycombDecor className="pointer-events-none absolute -left-10 top-8 h-56 w-64 opacity-40" />
        <HoneycombDecor className="pointer-events-none absolute -right-12 bottom-6 h-64 w-72 opacity-30 rotate-180" />

        <div className="relative w-full max-w-md">
          <div className="mb-6 flex flex-col items-center text-center">
            <HexLogo className="h-16 w-16 drop-shadow-md" />
            <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-[#2A1A12]">Цифровой улей</h1>
            <p className="mt-1 text-sm text-gray-500">ИИ-помощник пчеловода · вход в систему пасеки</p>
          </div>

          <div className="rounded-3xl border border-red-100 bg-white p-6 shadow-xl shadow-red-100/60">
            {verifiedOk ? (
              /* Зелёный экран: email подтверждён */
              <div className="flex flex-col items-center py-4 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                  <ShieldCheck className="h-9 w-9 text-green-600" />
                </span>
                <h2 className="mt-4 text-xl font-extrabold text-gray-900">Email подтверждён</h2>
                <p className="mt-2 text-sm leading-relaxed text-gray-500">
                  Аккаунт <span className="font-semibold text-gray-700">{pendingEmail.email}</span> активирован.
                  Теперь вы можете войти в систему.
                </p>
                <Button
                  onClick={backToAuth}
                  className="mt-5 h-11 w-full bg-red-600 text-base font-bold hover:bg-red-700"
                >
                  <LogIn className="h-4.5 w-4.5" /> Войти в систему
                </Button>
              </div>
            ) : (
              /* Ввод кода из письма */
              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault()
                  void submitCode()
                }}
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-orange-100">
                    <MailCheck className="h-6 w-6 text-orange-600" />
                  </span>
                  <div>
                    <h2 className="text-lg font-extrabold text-gray-900">Проверьте почту</h2>
                    <p className="text-xs leading-snug text-gray-500">
                      {pendingEmail.kind === 'registered'
                        ? 'Мы отправили код подтверждения на'
                        : 'Аккаунт не подтверждён — код отправлен на'}{' '}
                      <span className="font-semibold text-gray-700">{pendingEmail.email}</span>
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label htmlFor="auth-code" className="text-sm font-semibold text-gray-700">
                    Код из письма
                  </Label>
                  <Input
                    id="auth-code"
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    autoFocus
                    className="border-red-200 text-center font-mono text-2xl tracking-[0.45em] focus-visible:ring-red-300"
                  />
                  <p className="text-xs text-gray-400">6 цифр, действителен 30 минут</p>
                </div>

                {pendingWarning && (
                  <p className="flex items-start gap-2 rounded-xl border border-orange-200 bg-orange-50 px-3 py-2 text-sm font-medium text-orange-800">
                    <MailWarning className="mt-0.5 h-4 w-4 shrink-0" />
                    {pendingWarning}
                  </p>
                )}

                {codeMsg && (
                  <p
                    role="alert"
                    className={cn(
                      'rounded-xl border px-3 py-2 text-sm font-medium',
                      codeMsg.kind === 'success'
                        ? 'border-green-200 bg-green-50 text-green-700'
                        : 'border-red-200 bg-red-50 text-red-700',
                    )}
                  >
                    {codeMsg.text}
                  </p>
                )}

                <Button
                  type="submit"
                  disabled={verifying || codeInput.length !== 6}
                  className="h-11 w-full bg-orange-500 text-base font-bold text-white hover:bg-orange-600 disabled:opacity-50"
                >
                  <Hexagon className={cn('h-4.5 w-4.5', verifying && 'animate-spin')} />
                  {verifying ? 'Проверяем код…' : 'Подтвердить email'}
                </Button>

                <div className="flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={backToAuth}
                    className="inline-flex items-center gap-1 font-bold text-gray-500 hover:text-gray-700"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" /> Назад ко входу
                  </button>
                  <button
                    type="button"
                    onClick={() => void resendCode()}
                    disabled={resending || resendIn > 0}
                    className="inline-flex items-center gap-1.5 font-bold text-red-700 hover:text-red-900 disabled:cursor-not-allowed disabled:text-gray-400"
                  >
                    <RefreshCw className={cn('h-3.5 w-3.5', resending && 'animate-spin')} />
                    {resendIn > 0 ? `Отправить повторно через ${resendIn} с` : 'Отправить код повторно'}
                  </button>
                </div>
              </form>
            )}
          </div>

          <p className="mt-4 text-center text-xs text-gray-400">
            Письмо могло попасть в папку «Спам» — проверьте её, если код не пришёл.
          </p>
        </div>
      </div>
    )
  }

  /* ---------------------------------------------------------------- */
  /* Обычные формы входа и регистрации                                 */
  /* ---------------------------------------------------------------- */
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-[#FAF6F3] via-[#F2EDFA] to-[#EDE4FB] px-4 py-10">
      <HoneycombDecor className="pointer-events-none absolute -left-10 top-8 h-56 w-64 opacity-40" />
      <HoneycombDecor className="pointer-events-none absolute -right-12 bottom-6 h-64 w-72 opacity-30 rotate-180" />

      <div className="relative w-full max-w-md">
        {/* Логотип */}
        <div className="mb-6 flex flex-col items-center text-center">
          <HexLogo className="h-16 w-16 drop-shadow-md" />
          <h1 className="mt-3 text-2xl font-extrabold tracking-tight text-[#2A1A12]">Цифровой улей</h1>
          <p className="mt-1 text-sm text-gray-500">ИИ-помощник пчеловода · вход в систему пасеки</p>
        </div>

        {notice && (
          <p
            role="status"
            className={cn(
              'mb-4 rounded-2xl border px-4 py-3 text-sm font-medium',
              notice.kind === 'success'
                ? 'border-green-200 bg-green-50 text-green-700'
                : 'border-red-200 bg-red-50 text-red-700',
            )}
          >
            {notice.text}
          </p>
        )}

        <div className="rounded-3xl border border-red-100 bg-white p-6 shadow-xl shadow-red-100/60">
          {/* Переключатель */}
          <div className="mb-5 grid grid-cols-2 gap-1 rounded-2xl bg-red-50 p-1">
            <button
              onClick={() => { setTab('login'); setError(null) }}
              className={cn(
                'flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-sm font-bold transition-colors',
                tab === 'login' ? 'bg-white text-[#2A1A12] shadow-sm' : 'text-gray-500 hover:text-gray-700',
              )}
            >
              <LogIn className="h-4 w-4" /> Вход
            </button>
            <button
              onClick={() => { setTab('register'); setError(null) }}
              className={cn(
                'flex items-center justify-center gap-1.5 rounded-xl px-3 py-2 text-sm font-bold transition-colors',
                tab === 'register' ? 'bg-white text-[#2A1A12] shadow-sm' : 'text-gray-500 hover:text-gray-700',
              )}
            >
              <UserPlus className="h-4 w-4" /> Регистрация
            </button>
          </div>

          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              void submit()
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="auth-name" className="text-sm font-semibold text-gray-700">Имя пользователя</Label>
              <Input
                id="auth-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="например, ivan_petrov"
                autoComplete="username"
                className="border-red-200 focus-visible:ring-red-300"
              />
            </div>

            {/* Email — только при регистрации: на него придёт код подтверждения */}
            {tab === 'register' && (
              <div className="space-y-1.5">
                <Label htmlFor="auth-email" className="text-sm font-semibold text-gray-700">Email</Label>
                <Input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="вы@example.ru"
                  autoComplete="email"
                  className="border-red-200 focus-visible:ring-red-300"
                />
                <p className="text-xs text-gray-400">На этот адрес придёт 6-значный код подтверждения</p>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="auth-password" className="text-sm font-semibold text-gray-700">Пароль</Label>
              <div className="relative">
                <Input
                  id="auth-password"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={tab === 'register' ? 'минимум 4 символа' : '••••••••'}
                  autoComplete={tab === 'register' ? 'new-password' : 'current-password'}
                  className="border-red-200 pr-10 focus-visible:ring-red-300"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  aria-label={showPw ? 'Скрыть пароль' : 'Показать пароль'}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-gray-400 hover:text-gray-600"
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Роль — только при регистрации */}
            {tab === 'register' && (
              <div className="space-y-2 rounded-2xl border border-red-100 bg-red-50/50 p-3.5">
                <p className="flex items-center gap-1.5 text-sm font-semibold text-gray-700">
                  <UserCog className="h-4 w-4 text-red-600" /> Роль в системе
                </p>
                <RadioGroup value={role} onValueChange={(v) => setRole(v as 'BEEKEEPER' | 'HELPER')} className="gap-2">
                  <label
                    className={cn(
                      'flex cursor-pointer items-start gap-2.5 rounded-xl border bg-white p-3 transition-colors',
                      role === 'BEEKEEPER' ? 'border-red-400 ring-2 ring-red-100' : 'border-red-100 hover:border-red-200',
                    )}
                  >
                    <RadioGroupItem value="BEEKEEPER" id="role-beekeeper" className="mt-0.5" />
                    <span>
                      <span className="block text-sm font-bold text-gray-900">Пасечник</span>
                      <span className="block text-xs text-gray-500">Полный доступ: загрузка CSV, измерения, журнал, справочники</span>
                    </span>
                  </label>
                  <label
                    className={cn(
                      'flex cursor-pointer items-start gap-2.5 rounded-xl border bg-white p-3 transition-colors',
                      role === 'HELPER' ? 'border-red-400 ring-2 ring-red-100' : 'border-red-100 hover:border-red-200',
                    )}
                  >
                    <RadioGroupItem value="HELPER" id="role-helper" className="mt-0.5" />
                    <span>
                      <span className="block text-sm font-bold text-gray-900">Помощник</span>
                      <span className="block text-xs text-gray-500">Только просмотр данных и вопросы агенту</span>
                    </span>
                  </label>
                </RadioGroup>
              </div>
            )}

            {error && (
              <p role="alert" className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-700">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={busy || !name.trim() || !password || (tab === 'register' && !email.trim())}
              className="h-11 w-full bg-red-600 text-base font-bold hover:bg-red-700 disabled:opacity-50"
            >
              <Hexagon className={cn('h-4.5 w-4.5', busy && 'animate-spin')} />
              {busy ? 'Подождите…' : tab === 'login' ? 'Войти в систему' : 'Создать аккаунт'}
            </Button>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-gray-400">
          {tab === 'register'
            ? 'Регистрация подтверждается кодом из письма — это защищает пасеку от лишних аккаунтов.'
            : 'Пароли хранятся в базе только в виде scrypt-хеша. Агент показывает вероятность — решение принимает пчеловод.'}
        </p>
      </div>
    </div>
  )
}
